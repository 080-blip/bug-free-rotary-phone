"""
PH-family sites: YouPorn, Tube8, RedTube — yt-dlp info extraction helper.
"""
import asyncio
from io import BytesIO

import yt_dlp as youtube_dl
from yt_dlp.utils import UnsupportedError, DownloadError
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.function import run_in_executor
from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url


class _Silent:
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


_YDL_OPTS: dict = {
    "logger": _Silent(),
    "quiet": True,
    "no_warnings": True,
    "skip_download": True,
    "socket_timeout": 20,
    "extractor_retries": 3,
}


def _fmt_duration(seconds) -> str:
    try:
        s = int(seconds)
        h, rem = divmod(s, 3600)
        mn, sec = divmod(rem, 60)
        return f"{h}:{mn:02d}:{sec:02d}" if h else f"{mn}:{sec:02d}"
    except Exception:
        return ""


def _site_label(url: str) -> str:
    if "youporn" in url:
        return "YouPorn"
    if "tube8" in url:
        return "Tube8"
    if "redtube" in url:
        return "RedTube"
    return "Video"


async def _extract_info(url: str) -> dict | None:
    def _run():
        with youtube_dl.YoutubeDL(_YDL_OPTS) as ydl:
            return ydl.extract_info(url, download=False)
    try:
        return await asyncio.wait_for(run_in_executor(_run), timeout=35)
    except Exception:
        return None


async def show_options(m: Message, url: str) -> None:
    label         = _site_label(url)
    key           = cache_url("phf", url)
    callback_data = f"d_phf_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])
    try:
        info = await _extract_info(url)
        if not info:
            await m.reply_text(f"🎬 {label} video", reply_markup=markup)
            return

        title        = info.get("title") or "Unknown"
        duration_str = _fmt_duration(info.get("duration"))
        thumb_url    = info.get("thumbnail")
        caption      = f"🎬 <b>{title}</b>"
        if duration_str:
            caption += f"\n⏱ <b>Duration:</b> <code>{duration_str}</code>"

        if thumb_url:
            raw = await fetch_bytes(thumb_url)
            if raw:
                clean = await _process_thumb_bytes(raw)
                await m.reply_photo(photo=BytesIO(clean), caption=caption,
                                    reply_markup=markup)
                return
        await m.reply_text(caption, reply_markup=markup)
    except Exception:
        await m.reply_text(f"🎬 {label} video", reply_markup=markup)
