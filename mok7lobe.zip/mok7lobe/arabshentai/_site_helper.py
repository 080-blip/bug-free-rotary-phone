"""
arabshentai.com — chapter image extractor
Madara WordPress theme.

Strategy:
  0. Madara AJAX direct  — JSON endpoint, may be CF-free
  1. curl_cffi           — Chrome TLS fingerprint, fast, no browser overhead
  2. Anti-captcha svc    — Solves CF Turnstile (CapSolver / 2captcha / Anti-Captcha)
  3. ScraperAPI          — Managed proxy with JS rendering (needs SCRAPERAPI_KEY)
  4. nodriver            — Undetected Chrome (better than Playwright for CF)
  5. Playwright          — Real Chromium last-resort fallback

Selectors (keiyoushi/ArabsHentai.kt):
  pages   : .chapter_image img.wp-manga-chapter-img
  img attr: srcset → data-cfsrc → data-src → data-lazy-src → bv-data-src → src

Proxy (optional):
  ARABSHENTAI_PROXY = http://user:pass@host:port

Anti-captcha services (any ONE is enough — tries all that are set):
  CAPSOLVER_API_KEY  = key from capsolver.com   (free credits via Discord)
  TWOCAPTCHA_KEY     = key from 2captcha.com    ($0.50 free trial)
  ANTICAPTCHA_KEY    = key from anti-captcha.com ($1 free trial)

ScraperAPI (optional, premium CF bypass with JS rendering):
  SCRAPERAPI_KEY = your_key_from_scraperapi.com (5000 req/month free)
"""
import os
import re
import json
import asyncio
import logging
import urllib.parse
from io import BytesIO
from pathlib import Path
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from curl_cffi import requests as cffi_requests
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes
from PornHub.plugins.url_cache import cache_url

logger = logging.getLogger(__name__)

# ── Site constants ────────────────────────────────────────────────────────────
BASE_URL    = "https://arabshentai.com"
WP_REST     = f"{BASE_URL}/wp-json/wp/v2"
IMPERSONATE = "chrome131"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
    "Referer": BASE_URL + "/",
}

# ── Environment (from manga_downloader.py) ────────────────────────────────────
CHROME_EXECUTABLE = os.environ.get("REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE", "")
REPLIT_LD         = os.environ.get("REPLIT_LD_LIBRARY_PATH", "")
if REPLIT_LD:
    _cur = os.environ.get("LD_LIBRARY_PATH", "")
    os.environ["LD_LIBRARY_PATH"] = f"{REPLIT_LD}:{_cur}" if _cur else REPLIT_LD

# ── Optional proxy ─────────────────────────────────────────────────────────────
PROXY = os.environ.get("ARABSHENTAI_PROXY", "").strip()

# ── CF wait (seconds) — same as manga_downloader.py ──────────────────────────
CF_WAIT_SEC = 12

_CHAPTER_RE = re.compile(r"arabshentai\.com/manga/([^/]+)/([^/]+)/?", re.I)


# ─────────────────────────────────────────────────────────
#  URL parsing
# ─────────────────────────────────────────────────────────

def parse_url(url: str) -> tuple[str, str] | None:
    m = _CHAPTER_RE.search(url)
    if not m:
        return None
    return urllib.parse.unquote(m.group(1)), urllib.parse.unquote(m.group(2))


# ─────────────────────────────────────────────────────────
#  Image attribute — keiyoushi priority order
# ─────────────────────────────────────────────────────────

def _img_attr(tag) -> str | None:
    srcset = tag.get("srcset", "").strip()
    if srcset and not srcset.startswith("data:"):
        first = srcset.split()[0]
        if first.startswith("http"):
            return first
    for attr in ("data-cfsrc", "data-src", "data-lazy-src", "bv-data-src", "src"):
        val = tag.get(attr, "").strip()
        if val and not val.startswith("data:") and "cloudflare" not in val:
            if not val.startswith("http"):
                val = BASE_URL + val if val.startswith("/") else BASE_URL + "/" + val
            return val
    return None


# ─────────────────────────────────────────────────────────
#  HTML → image list
# ─────────────────────────────────────────────────────────

def _extract_from_soup(soup: BeautifulSoup) -> list[str]:
    for selector in [
        ".chapter_image img.wp-manga-chapter-img",
        ".reading-content img",
        ".page-break img",
        "#readerarea img",
        "img.wp-manga-chapter-img",
        ".chapter-images img",
        "div[class*='reader'] img",
    ]:
        imgs = [_img_attr(t) for t in soup.select(selector)]
        imgs = [u for u in imgs if u]
        if imgs:
            logger.info("soup '%s': %d images", selector, len(imgs))
            return imgs
    return []


def extract_images_from_html(html: str, base_url: str) -> list[str]:
    """
    Multi-strategy extraction — same as manga_downloader.py extract_images_from_html().
    """
    imgs: list[str] = []

    # Strategy 1: ts_reader.run({sources:[{images:[...]}]})
    m = re.search(r'ts_reader\.run\s*\(\s*(\{.*?\})\s*\)\s*;', html, re.DOTALL)
    if m:
        try:
            data = json.loads(m.group(1))
            for src in data.get("sources", []):
                imgs.extend(src.get("images", []))
        except Exception:
            pass

    # Strategy 2: JS vars
    for pat in [
        r'chapter_preloaded_images\s*=\s*(\[.*?\])',
        r'"images"\s*:\s*(\[.*?\])',
        r'var\s+pages\s*=\s*(\[.*?\])',
    ]:
        for mm in re.finditer(pat, html, re.DOTALL):
            try:
                parsed = json.loads(mm.group(1))
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, str) and item.startswith("http"):
                            imgs.append(item)
                        elif isinstance(item, dict):
                            for key in ("src", "url", "image", "img", "page_image"):
                                if key in item and str(item[key]).startswith("http"):
                                    imgs.append(str(item[key]))
            except Exception:
                pass

    # Strategy 3: img tags
    if not imgs:
        for pat in [
            r'<img[^>]+data-src=["\']([^"\']+\.(?:jpg|jpeg|png|webp)[^"\']*)["\']',
            r'<img[^>]+data-lazy-src=["\']([^"\']+\.(?:jpg|jpeg|png|webp)[^"\']*)["\']',
            r'<img[^>]+src=["\']([^"\']+\.(?:jpg|jpeg|png|webp)[^"\']*)["\']',
        ]:
            for mm in re.finditer(pat, html, re.IGNORECASE):
                u = mm.group(1).strip()
                if not u.startswith("data:"):
                    imgs.append(u)

    # Strategy 4: JSON blobs with uploads paths
    if not imgs:
        for mm in re.finditer(
            r'"(https?://[^"]+/(?:uploads|content|wp-content)/[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"',
            html, re.IGNORECASE,
        ):
            imgs.append(mm.group(1))

    # Deduplicate + resolve relative
    seen, result = set(), []
    for url in imgs:
        if not url.startswith("http"):
            url = urljoin(base_url, url)
        if url not in seen and url.startswith("http"):
            seen.add(url)
            result.append(url)
    return result


def _is_cf_blocked(html: str) -> bool:
    return (
        "Just a moment" in html
        or "لحظة" in html
        or "cf-browser-verification" in html
        or "Checking your browser" in html
        or "Enable JavaScript" in html
        or "Attention Required" in html
    )


# ─────────────────────────────────────────────────────────
#  Method 1: curl_cffi (fast, no browser)
# ─────────────────────────────────────────────────────────

def _curl_fetch(chapter_url: str) -> list[str] | None:
    for imp in (IMPERSONATE, "chrome120", "safari18_0"):
        try:
            kwargs: dict = dict(headers=HEADERS, timeout=20, allow_redirects=True, impersonate=imp)
            if PROXY:
                kwargs["proxies"] = {"https": PROXY, "http": PROXY}
            r = cffi_requests.get(chapter_url, **kwargs)
            if r.status_code != 200:
                logger.warning("curl_cffi[%s] HTTP %d", imp, r.status_code)
                continue
            if _is_cf_blocked(r.text):
                logger.info("curl_cffi[%s]: CF challenge detected", imp)
                continue
            imgs = _extract_from_soup(BeautifulSoup(r.text, "html.parser"))
            if not imgs:
                imgs = extract_images_from_html(r.text, chapter_url)
            if imgs:
                logger.info("curl_cffi[%s]: %d images ✓", imp, len(imgs))
                return imgs
        except Exception as exc:
            logger.warning("curl_cffi[%s] error: %s", imp, exc)
    return None


# ─────────────────────────────────────────────────────────
#  Method 2: Playwright (manga_downloader.py approach)
# ─────────────────────────────────────────────────────────

_STEALTH_JS = """
() => {
    // hide webdriver
    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
    // spoof plugins
    Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3,4,5]});
    Object.defineProperty(navigator, 'languages', {get: () => ['en-US','en','ar']});
    // remove automation indicators
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
    // spoof chrome object
    window.chrome = {runtime: {}, loadTimes: function(){}, csi: function(){}, app: {}};
    // fix permissions
    const origQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (p) =>
        p.name === 'notifications'
            ? Promise.resolve({state: Notification.permission})
            : origQuery(p);
}
"""

_DOM_SCAN_JS = """
() => {
    const attrs = ['src','data-src','data-lazy-src','data-cfsrc','data-original',
                   'data-pagespeed-lazy-src','bv-data-src'];
    const selectors = [
        '.chapter_image img.wp-manga-chapter-img',
        '.reading-content img',
        '#readerarea img',
        '.chapter-images img',
        '.page-break img',
        '.text-left img',
        'div[id*="reader"] img',
        'div[class*="reader"] img',
        'div[class*="chapter"] img',
        'article img',
    ];
    const grab = (nodes) => {
        const out = [];
        nodes.forEach(el => {
            for (const a of attrs) {
                const v = el.getAttribute(a) || el[a] || '';
                if (v && !v.startsWith('data:') && v.startsWith('http')) {
                    out.push(v); break;
                }
            }
        });
        return out;
    };
    for (const sel of selectors) {
        const nodes = document.querySelectorAll(sel);
        if (nodes.length > 1) {
            const imgs = grab(nodes);
            if (imgs.length > 0) return [...new Set(imgs)];
        }
    }
    // fallback: all imgs
    return [...new Set(grab(document.querySelectorAll('img')))];
}
"""

def _cf_still_blocking(title: str) -> bool:
    t = title.lower()
    return ("just a moment" in t or "attention required" in t
            or "لحظة" in title or "checking your browser" in t
            or title.strip() == "")


async def _playwright_fetch(chapter_url: str) -> list[str] | None:
    """
    Enhanced Playwright fetch:
      • Full stealth JS injection
      • Polls CF title until clear (up to 90 s)
      • After CF clears: DOM scan + HTML extraction + AJAX fallback
    """
    try:
        from playwright.async_api import async_playwright

        launch_kwargs: dict = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--disable-web-security",
                "--disable-features=IsolateOrigins,site-per-process",
                "--disable-infobars",
                "--window-size=1280,900",
            ],
        }

        # Use system Chromium if available
        import shutil
        system_chromium = shutil.which("chromium") or shutil.which("chromium-browser") or ""
        for candidate in [
            CHROME_EXECUTABLE,
            system_chromium,
        ]:
            if candidate and os.path.exists(candidate):
                launch_kwargs["executable_path"] = candidate
                logger.info("Playwright: using Chrome %s", candidate)
                break

        if PROXY:
            p = urlparse(PROXY)
            pw_proxy: dict = {"server": f"{p.scheme}://{p.hostname}:{p.port}"}
            if p.username:
                pw_proxy["username"] = urllib.parse.unquote(p.username)
            if p.password:
                pw_proxy["password"] = urllib.parse.unquote(p.password)
            launch_kwargs["proxy"] = pw_proxy

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**launch_kwargs)
            ctx = await browser.new_context(
                user_agent=HEADERS["User-Agent"],
                viewport={"width": 1280, "height": 900},
                extra_http_headers={
                    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
                    "Accept": HEADERS["Accept"],
                },
            )
            page = await ctx.new_page()
            await page.add_init_script(_STEALTH_JS)

            await page.goto(chapter_url, wait_until="domcontentloaded", timeout=60_000)

            # ── Poll until CF clears (max 90 s) ──────────────────────────────
            CF_MAX = 90
            elapsed = 0
            while elapsed < CF_MAX:
                await asyncio.sleep(3)
                elapsed += 3
                title = await page.title()
                logger.info("Playwright [%ds] title=%r", elapsed, title)
                if not _cf_still_blocking(title):
                    logger.info("Playwright: CF cleared after %ds ✓", elapsed)
                    break
            else:
                logger.warning("Playwright: CF did NOT clear after %ds — scraping anyway", CF_MAX)

            await asyncio.sleep(2)

            title  = await page.title()
            html   = await page.content()
            cookies = await ctx.cookies()

            # ── DOM scan ─────────────────────────────────────────────────────
            dom_images: list[str] = await page.evaluate(_DOM_SCAN_JS)

            # ── AJAX fallback with CF cookies ─────────────────────────────────
            ajax_images: list[str] = []
            if not dom_images or len(dom_images) <= 2:
                ajax_images = await _ajax_with_cookies(page, cookies, chapter_url)

            await browser.close()

        # ── Result priority ───────────────────────────────────────────────────
        candidates = [
            ("DOM", dom_images),
            ("AJAX", ajax_images),
            ("HTML", extract_images_from_html(html, chapter_url)),
        ]
        for label, imgs in candidates:
            clean = [u for u in imgs if "favicon" not in u and not u.endswith(".ico")]
            if len(clean) > 1:
                logger.info("Playwright %s: %d images ✓", label, len(clean))
                return clean

        logger.warning("Playwright: 0 real images (title=%r) — saving debug HTML", title)
        Path("debug_arabshentai.html").write_text(html, encoding="utf-8")
        return None

    except Exception as exc:
        logger.exception("Playwright failed: %s", exc)
        return None


async def _ajax_with_cookies(page, cookies: list, chapter_url: str) -> list[str]:
    """
    Use CF-cleared cookies + nonce extracted from page to call Madara AJAX.
    Returns image list or [].
    """
    try:
        # Extract wp_manga nonce from page JS
        nonce = await page.evaluate("""
            () => {
                try {
                    return (window.manga_reader_js_extra || window.chapter_js_extra
                            || window.wp_manga_chapter_img_vars || {}).token || '';
                } catch(e) { return ''; }
            }
        """)
        # Also try scanning script tags for nonce
        if not nonce:
            nonce = await page.evaluate("""
                () => {
                    const scripts = [...document.querySelectorAll('script')];
                    for (const s of scripts) {
                        const m = s.textContent.match(/"token"\\s*:\\s*"([a-f0-9]+)"/);
                        if (m) return m[1];
                    }
                    return '';
                }
            """)

        # Build cookie header string
        cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in cookies)

        # Try Madara AJAX image list endpoint
        ajax_url = f"{BASE_URL}/wp-admin/admin-ajax.php"
        parsed   = _CHAPTER_RE.search(chapter_url)
        if not parsed:
            return []
        chapter_slug = urllib.parse.unquote(parsed.group(2))

        payload = urllib.parse.urlencode({
            "action":        "wp_manga_chapter_img_list",
            "manga_reader_chapter_slug": chapter_slug,
            "manga_reader_manga_id": "",
        })
        if nonce:
            payload += f"&token={nonce}"

        result = await page.evaluate(f"""
            async () => {{
                try {{
                    const r = await fetch("{ajax_url}", {{
                        method: "POST",
                        headers: {{
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "X-Requested-With": "XMLHttpRequest",
                        }},
                        body: "{payload}",
                        credentials: "include",
                    }});
                    const text = await r.text();
                    return text;
                }} catch(e) {{ return ""; }}
            }}
        """)

        if result:
            logger.info("AJAX response (len=%d): %s", len(result), result[:200])
            try:
                data = json.loads(result)
                if isinstance(data, dict) and data.get("data"):
                    imgs = []
                    for item in (data["data"] if isinstance(data["data"], list) else [data["data"]]):
                        if isinstance(item, dict):
                            u = item.get("src") or item.get("url") or item.get("img_url") or ""
                            if u and u.startswith("http"):
                                imgs.append(u)
                        elif isinstance(item, str) and item.startswith("http"):
                            imgs.append(item)
                    if imgs:
                        return imgs
            except Exception:
                pass

    except Exception as exc:
        logger.warning("AJAX with cookies failed: %s", exc)

    return []


# ─────────────────────────────────────────────────────────
#  Method 0: Madara AJAX direct (CF-free JSON endpoint)
# ─────────────────────────────────────────────────────────

def _ajax_direct(chapter_url: str, chapter_slug: str) -> list[str] | None:
    """
    Call Madara admin-ajax.php directly without CF cookies.
    The JSON endpoint is often behind a lighter CF rule than the HTML page.
    """
    actions = [
        ("wp_manga_chapter_img_list", {"manga_reader_chapter_slug": chapter_slug, "manga_reader_manga_id": ""}),
        ("manga_get_chapter_files",   {"chapter_slug": chapter_slug, "manga_id": ""}),
    ]
    for action, extra in actions:
        try:
            payload = urllib.parse.urlencode({"action": action, **extra})
            kwargs: dict = dict(
                data=payload,
                headers={
                    **HEADERS,
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "X-Requested-With": "XMLHttpRequest",
                    "Accept": "application/json, text/javascript, */*; q=0.01",
                    "Referer": chapter_url,
                },
                impersonate=IMPERSONATE,
                timeout=15,
            )
            if PROXY:
                kwargs["proxies"] = {"https": PROXY, "http": PROXY}
            r = cffi_requests.post(f"{BASE_URL}/wp-admin/admin-ajax.php", **kwargs)
            if r.status_code != 200:
                continue
            text = r.text.strip()
            if not text or text in ("0", "-1", "false", "null"):
                continue
            try:
                data = r.json()
            except Exception:
                continue
            imgs: list[str] = []
            items = data.get("data") if isinstance(data, dict) else None
            if not items and isinstance(data, list):
                items = data
            if items:
                for item in (items if isinstance(items, list) else [items]):
                    if isinstance(item, dict):
                        u = (item.get("src") or item.get("url") or
                             item.get("img_url") or item.get("image") or "")
                        if u and str(u).startswith("http"):
                            imgs.append(str(u))
                    elif isinstance(item, str) and item.startswith("http"):
                        imgs.append(item)
            if imgs:
                logger.info("ajax_direct[%s]: %d images ✓", action, len(imgs))
                return imgs
        except Exception as exc:
            logger.warning("ajax_direct[%s]: %s", action, exc)
    return None


# ─────────────────────────────────────────────────────────
#  Method 2: Anti-Captcha Services (unified)
#  Supports: CapSolver · 2captcha · Anti-Captcha
#  Set ANY ONE of the env vars to enable this method.
# ─────────────────────────────────────────────────────────

# Fallback sitekey for arabshentai.com CF Turnstile (managed mode)
_CF_SITEKEY_FALLBACK = "0x4AAAAAAADnPIDROrmt1Wwj"

# Service definitions: (env_var, balance_url, create_url, result_url, key_field)
_CAPTCHA_SERVICES = [
    {
        "name": "CapSolver",
        "env": "CAPSOLVER_API_KEY",
        "balance_url": "https://api.capsolver.com/getBalance",
        "create_url": "https://api.capsolver.com/createTask",
        "result_url": "https://api.capsolver.com/getTaskResult",
        "task_type_proxyless": "AntiTurnstileTaskProxyLess",
        "task_type_proxy": "AntiCloudflareTask",
        "task_key": "clientKey",
        "result_key": "solution",
        "token_field": "token",
        "status_field": "status",
        "error_field": "errorId",
        "error_msg_field": "errorDescription",
    },
    {
        "name": "2captcha",
        "env": "TWOCAPTCHA_KEY",
        "balance_url": "https://api.2captcha.com/getBalance",
        "create_url": "https://api.2captcha.com/createTask",
        "result_url": "https://api.2captcha.com/getTaskResult",
        "task_type_proxyless": "TurnstileTaskProxyless",
        "task_type_proxy": "TurnstileTask",
        "task_key": "clientKey",
        "result_key": "solution",
        "token_field": "token",
        "status_field": "status",
        "error_field": "errorId",
        "error_msg_field": "errorDescription",
    },
    {
        "name": "Anti-Captcha",
        "env": "ANTICAPTCHA_KEY",
        "balance_url": "https://api.anti-captcha.com/getBalance",
        "create_url": "https://api.anti-captcha.com/createTask",
        "result_url": "https://api.anti-captcha.com/getTaskResult",
        "task_type_proxyless": "TurnstileTaskProxylessV2",
        "task_type_proxy": "TurnstileTask",
        "task_key": "clientKey",
        "result_key": "solution",
        "token_field": "token",
        "status_field": "status",
        "error_field": "errorId",
        "error_msg_field": "errorDescription",
    },
]


def _get_turnstile_sitekey(page_url: str) -> str:
    """
    Try to extract CF Turnstile sitekey from the challenge page.
    Falls back to known arabshentai.com sitekey.
    """
    try:
        kwargs: dict = dict(headers=HEADERS, impersonate=IMPERSONATE, timeout=15)
        if PROXY:
            kwargs["proxies"] = {"https": PROXY, "http": PROXY}
        r = cffi_requests.get(page_url, **kwargs)
        for pattern in (
            r'data-sitekey=["\']([^"\']{10,})["\']',
            r'"sitekey"\s*:\s*"([^"]{10,})"',
            r"sitekey:\s*['\"]([^'\"]{10,})['\"]",
        ):
            m = re.search(pattern, r.text)
            if m:
                sk = m.group(1)
                logger.info("Turnstile sitekey extracted: %s", sk)
                return sk
    except Exception as exc:
        logger.debug("sitekey extraction error: %s", exc)
    logger.info("Using fallback sitekey: %s", _CF_SITEKEY_FALLBACK)
    return _CF_SITEKEY_FALLBACK


def _fetch_with_solution(chapter_url: str, solution: dict, svc_name: str) -> list[str] | None:
    """
    Use anti-captcha solution (cookies / token) to fetch the chapter page.
    Tries cookie-based auth first, then Turnstile token submission.
    """
    try:
        # ── Cookie-based (AntiCloudflareTask / CapSolver full solution) ──
        raw_cookies: list | dict = solution.get("cookies", [])
        cookie_str = ""
        if isinstance(raw_cookies, list):
            cookie_str = "; ".join(
                f"{c['name']}={c['value']}" for c in raw_cookies if "name" in c
            )
        elif isinstance(raw_cookies, dict):
            cookie_str = "; ".join(f"{k}={v}" for k, v in raw_cookies.items())

        ua = solution.get("userAgent", HEADERS["User-Agent"])

        if cookie_str:
            logger.info("%s: using cookie solution", svc_name)
            headers = {**HEADERS, "User-Agent": ua, "Cookie": cookie_str}
            kwargs: dict = dict(headers=headers, timeout=25, impersonate=IMPERSONATE)
            if PROXY:
                kwargs["proxies"] = {"https": PROXY, "http": PROXY}
            r = cffi_requests.get(chapter_url, **kwargs)
            if r.status_code == 200 and not _is_cf_blocked(r.text):
                imgs = _extract_from_soup(BeautifulSoup(r.text, "html.parser"))
                if not imgs:
                    imgs = extract_images_from_html(r.text, chapter_url)
                if imgs:
                    logger.info("%s: %d images via cookies ✓", svc_name, len(imgs))
                    return imgs

        # ── Token-based (TurnstileTaskProxyless) ──
        token = solution.get("token") or solution.get("gRecaptchaResponse", "")
        if token:
            logger.info("%s: submitting Turnstile token to get cf_clearance", svc_name)
            parsed = urlparse(chapter_url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            # Submit token to CF challenge endpoint to obtain cf_clearance cookie
            session = cffi_requests.Session()
            # 1. GET challenge page to get initial cookies/ray-id
            r0 = session.get(
                chapter_url,
                headers={**HEADERS, "User-Agent": ua},
                impersonate=IMPERSONATE,
                timeout=15,
                **({"proxies": {"https": PROXY, "http": PROXY}} if PROXY else {}),
            )
            # 2. POST the token to CDN challenge endpoint
            for path in [
                "/cdn-cgi/challenge-platform/h/b/cv/result",
                "/cdn-cgi/challenge-platform/h/g/cv/result",
            ]:
                try:
                    r1 = session.post(
                        f"{origin}{path}",
                        data={"cf-turnstile-response": token},
                        headers={
                            **HEADERS,
                            "User-Agent": ua,
                            "Origin": origin,
                            "Referer": chapter_url,
                            "Content-Type": "application/x-www-form-urlencoded",
                        },
                        impersonate=IMPERSONATE,
                        timeout=15,
                        **({"proxies": {"https": PROXY, "http": PROXY}} if PROXY else {}),
                    )
                    logger.debug("%s: challenge POST %s → %d", svc_name, path, r1.status_code)
                    if r1.status_code in (200, 302, 301):
                        break
                except Exception:
                    pass
            # 3. Now try fetching the chapter with accumulated session cookies
            r2 = session.get(
                chapter_url,
                headers={**HEADERS, "User-Agent": ua},
                impersonate=IMPERSONATE,
                timeout=20,
                **({"proxies": {"https": PROXY, "http": PROXY}} if PROXY else {}),
            )
            if r2.status_code == 200 and not _is_cf_blocked(r2.text):
                imgs = _extract_from_soup(BeautifulSoup(r2.text, "html.parser"))
                if not imgs:
                    imgs = extract_images_from_html(r2.text, chapter_url)
                if imgs:
                    logger.info("%s: %d images via token ✓", svc_name, len(imgs))
                    return imgs
            logger.warning("%s: token submission did not clear CF", svc_name)

    except Exception as exc:
        logger.warning("%s fetch error: %s", svc_name, exc)
    return None


async def _solve_turnstile_all_services(page_url: str) -> list[str] | None:
    """
    Try every configured anti-captcha service in order until one succeeds.
    Supported env vars:
      CAPSOLVER_API_KEY  — capsolver.com   (AntiTurnstileTaskProxyLess / AntiCloudflareTask)
      TWOCAPTCHA_KEY     — 2captcha.com    (TurnstileTaskProxyless)
      ANTICAPTCHA_KEY    — anti-captcha.com (TurnstileTaskProxylessV2)
    """
    import aiohttp as _aiohttp

    loop = asyncio.get_event_loop()
    sitekey = await loop.run_in_executor(None, _get_turnstile_sitekey, page_url)

    for svc in _CAPTCHA_SERVICES:
        api_key = os.environ.get(svc["env"], "").strip()
        if not api_key:
            continue

        svc_name = svc["name"]
        logger.info("%s: checking balance…", svc_name)

        # Balance check
        try:
            async with _aiohttp.ClientSession() as _s:
                async with _s.post(
                    svc["balance_url"],
                    json={svc["task_key"]: api_key},
                    timeout=_aiohttp.ClientTimeout(total=10),
                ) as _r:
                    _bal = await _r.json()
            if _bal.get(svc["error_field"], 0) != 0:
                logger.warning(
                    "%s: key invalid — %s. تحقق من حسابك على الموقع.",
                    svc_name, _bal.get(svc["error_msg_field"]),
                )
                continue
            logger.info("%s balance: %s", svc_name, _bal.get("balance", "?"))
        except Exception as exc:
            logger.warning("%s balance check failed: %s", svc_name, exc)
            # Don't skip — balance endpoint might differ, still try solving

        # Task types to try (proxyless first, then proxy-based if proxy set)
        task_defs: list[dict] = [
            {
                "type": svc["task_type_proxyless"],
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        ]
        if PROXY:
            proxy_task: dict = {
                "type": svc["task_type_proxy"],
                "websiteURL": page_url,
                "websiteKey": sitekey,
                "proxy": PROXY,
            }
            # AntiCloudflareTask (CapSolver) doesn't use websiteKey
            if svc["task_type_proxy"] == "AntiCloudflareTask":
                proxy_task.pop("websiteKey", None)
            task_defs.append(proxy_task)

        async with _aiohttp.ClientSession() as session:
            for task_def in task_defs:
                task_type = task_def["type"]
                logger.info("%s: submitting %s task…", svc_name, task_type)
                try:
                    async with session.post(
                        svc["create_url"],
                        json={svc["task_key"]: api_key, "task": task_def},
                        timeout=_aiohttp.ClientTimeout(total=30),
                    ) as resp:
                        created = await resp.json()

                    if created.get(svc["error_field"], 0) != 0:
                        logger.warning(
                            "%s [%s] createTask error: %s",
                            svc_name, task_type, created.get(svc["error_msg_field"]),
                        )
                        continue

                    task_id = created.get("taskId")
                    logger.info("%s [%s]: task_id=%s — polling…", svc_name, task_type, task_id)

                    # Poll up to 120 s
                    for _ in range(60):
                        await asyncio.sleep(2)
                        async with session.post(
                            svc["result_url"],
                            json={svc["task_key"]: api_key, "taskId": task_id},
                            timeout=_aiohttp.ClientTimeout(total=15),
                        ) as resp:
                            result = await resp.json()

                        status = result.get(svc["status_field"])
                        if status == "ready":
                            solution = result.get(svc["result_key"], {})
                            logger.info("%s [%s]: solved ✓", svc_name, task_type)
                            imgs = await loop.run_in_executor(
                                None, _fetch_with_solution, page_url, solution, svc_name
                            )
                            if imgs:
                                return imgs
                            break
                        if status in ("failed", "error"):
                            logger.warning(
                                "%s [%s]: task failed — %s",
                                svc_name, task_type, result.get(svc["error_msg_field"]),
                            )
                            break
                    else:
                        logger.warning("%s [%s]: timeout (120 s)", svc_name, task_type)

                except Exception as exc:
                    logger.warning("%s [%s] error: %s", svc_name, task_type, exc)

    return None


# ─────────────────────────────────────────────────────────
#  Method 3: ScraperAPI — managed proxy + JS rendering
# ─────────────────────────────────────────────────────────

def _scraperapi_fetch(chapter_url: str) -> list[str] | None:
    """
    Use ScraperAPI premium proxy with JavaScript rendering to bypass CF Turnstile.
    Requires SCRAPERAPI_KEY env var.
    Sign up free at https://www.scraperapi.com (5000 credits/month free).
    """
    api_key = os.environ.get("SCRAPERAPI_KEY", "").strip()
    if not api_key:
        return None

    import urllib.parse as _up

    logger.info("ScraperAPI: fetching %s", chapter_url)
    api_url = (
        "http://api.scraperapi.com?"
        + _up.urlencode({
            "api_key": api_key,
            "url": chapter_url,
            "render": "true",
            "premium": "true",
            "country_code": "us",
            "keep_headers": "false",
        })
    )

    try:
        # ScraperAPI may take up to 60s with render=true
        r = cffi_requests.get(
            api_url,
            headers={"Accept": "text/html"},
            timeout=90,
            impersonate=IMPERSONATE,
        )
        if r.status_code not in (200, 203):
            logger.warning("ScraperAPI: HTTP %d", r.status_code)
            return None
        if _is_cf_blocked(r.text):
            logger.warning("ScraperAPI: CF still blocking")
            return None

        soup = BeautifulSoup(r.text, "html.parser")
        imgs = _extract_from_soup(soup)
        if not imgs:
            imgs = extract_images_from_html(r.text, chapter_url)
        if imgs:
            logger.info("ScraperAPI: %d images ✓", len(imgs))
        return imgs or None

    except Exception as exc:
        logger.warning("ScraperAPI error: %s", exc)
        return None


# ─────────────────────────────────────────────────────────
#  REST API helpers (CF-free — JSON endpoints)
# ─────────────────────────────────────────────────────────

async def _rest_get(endpoint: str) -> dict | list | None:
    loop = asyncio.get_event_loop()
    def _sync():
        try:
            r = cffi_requests.get(
                f"{WP_REST}{endpoint}",
                impersonate=IMPERSONATE,
                headers={**HEADERS, "Accept": "application/json"},
                timeout=15,
            )
            if r.status_code == 200:
                return r.json()
        except Exception as exc:
            logger.warning("REST GET %s: %s", endpoint, exc)
        return None
    return await loop.run_in_executor(None, _sync)


async def get_manga_info(manga_slug: str) -> dict | None:
    slug_enc = urllib.parse.quote(manga_slug, safe="")
    data = await _rest_get(f"/wp-manga?slug={slug_enc}&_embed=1")
    if not data or not isinstance(data, list):
        return None
    post = data[0]
    desc = re.sub(r"<[^>]+>", "", post.get("content", {}).get("rendered", "")).strip()[:500]
    cover_url = None
    featured = post.get("_embedded", {}).get("wp:featuredmedia", [])
    if featured:
        cover_url = featured[0].get("source_url")
    if not cover_url:
        media = await _rest_get(f"/media/{post.get('featured_media', '')}")
        if media and isinstance(media, dict):
            cover_url = media.get("source_url")
    return {
        "id":          post.get("id"),
        "title":       post.get("title", {}).get("rendered", manga_slug),
        "description": desc,
        "cover_url":   cover_url,
        "link":        post.get("link", f"{BASE_URL}/manga/{manga_slug}/"),
    }


# ─────────────────────────────────────────────────────────
#  Method 4: nodriver — undetected Chrome (better CF bypass)
# ─────────────────────────────────────────────────────────

async def _nodriver_fetch(chapter_url: str) -> list[str] | None:
    """
    Use nodriver (undetected Chrome) to bypass CF Turnstile.
    nodriver patches the Chrome binary to avoid WebDriver detection.
    Falls back gracefully if nodriver is not installed.
    """
    try:
        import nodriver as uc  # type: ignore
    except ImportError:
        logger.info("nodriver not installed — skipping")
        return None

    import shutil
    chrome = shutil.which("chromium") or CHROME_EXECUTABLE or None
    args = [
        "--no-sandbox",
        "--disable-dev-shm-usage",
        "--disable-blink-features=AutomationControlled",
        "--window-size=1280,900",
        "--disable-extensions",
    ]
    if PROXY:
        args.append(f"--proxy-server={PROXY}")

    logger.info("nodriver: launching undetected Chrome for %s", chapter_url)
    browser = None
    try:
        browser = await uc.start(
            headless=True,
            browser_executable_path=chrome,
            browser_args=args,
            no_sandbox=True,
        )
        page = await browser.get(chapter_url)
        if page is None:
            logger.warning("nodriver: page is None — browser may have crashed")
            return None

        # Wait up to 30 s for CF to clear
        for elapsed in range(0, 31, 3):
            await asyncio.sleep(3)
            try:
                title = await page.evaluate("document.title")
            except Exception:
                title = ""
            logger.info("nodriver [%ds] title=%r", elapsed + 3, title)
            if not _cf_still_blocking(title):
                break

        html = await page.get_content()
        imgs = _extract_from_soup(BeautifulSoup(html, "html.parser"))
        if not imgs:
            imgs = extract_images_from_html(html, chapter_url)
        if imgs:
            logger.info("nodriver: %d images ✓", len(imgs))
            return imgs
        logger.warning("nodriver: 0 images found (CF may still be blocking)")
        return None

    except Exception as exc:
        logger.warning("nodriver error: %s", exc)
        return None
    finally:
        if browser:
            try:
                await browser.stop()
            except Exception:
                pass


# ─────────────────────────────────────────────────────────
#  Public entry point
# ─────────────────────────────────────────────────────────

async def get_chapter_images(
    chapter_url: str,
    *,
    manga_id: int | None = None,
    chapter_slug: str | None = None,
    status_cb=None,
) -> list[str] | None:
    """
    0. Madara AJAX direct        — CF-free JSON endpoint (no browser)
    1. curl_cffi                 — Chrome TLS fingerprint
    2. Anti-Captcha services     — CapSolver / 2captcha / Anti-Captcha
    3. ScraperAPI                — Managed proxy + JS rendering
    4. nodriver                  — Undetected Chrome (CF bypass)
    5. Playwright                — Real Chromium last-resort
    """
    loop = asyncio.get_event_loop()

    # ── Method 0: Madara AJAX direct ──
    parsed = parse_url(chapter_url)
    if parsed:
        _, ch_slug = parsed
        chapter_slug = chapter_slug or ch_slug
        if status_cb:
            await status_cb("⚡ <b>جاري جلب صور الفصل...</b>\n📡 الطريقة 0: AJAX مباشر")
        imgs = await loop.run_in_executor(None, _ajax_direct, chapter_url, ch_slug)
        if imgs:
            return imgs

    # ── Method 1: curl_cffi ──
    if status_cb:
        await status_cb("⚡ <b>جاري جلب صور الفصل...</b>\n📡 الطريقة 1: جلب مباشر (Chrome TLS)")
    imgs = await loop.run_in_executor(None, _curl_fetch, chapter_url)
    if imgs:
        return imgs

    # ── Method 2: Anti-Captcha services (CapSolver / 2captcha / Anti-Captcha) ──
    _has_captcha_key = any(
        os.environ.get(s["env"]) for s in _CAPTCHA_SERVICES
    )
    if _has_captcha_key:
        if status_cb:
            _active = next(
                s["name"] for s in _CAPTCHA_SERVICES if os.environ.get(s["env"])
            )
            await status_cb(
                f"🔐 <b>جاري حل تحقق Cloudflare Turnstile...</b>\n"
                f"⏳ {_active} يعمل (قد يستغرق 30-120 ثانية)"
            )
        imgs = await _solve_turnstile_all_services(chapter_url)
        if imgs:
            return imgs
    else:
        logger.info(
            "Anti-captcha skipped — set CAPSOLVER_API_KEY / TWOCAPTCHA_KEY / ANTICAPTCHA_KEY"
        )

    # ── Method 3: ScraperAPI (managed CF bypass + JS rendering) ──
    if os.environ.get("SCRAPERAPI_KEY"):
        if status_cb:
            await status_cb(
                "🔑 <b>جاري استخدام ScraperAPI لتجاوز Cloudflare...</b>\n"
                "⏳ قد يستغرق 60-90 ثانية (JS rendering)"
            )
        imgs = await loop.run_in_executor(None, _scraperapi_fetch, chapter_url)
        if imgs:
            return imgs
    else:
        logger.info("ScraperAPI skipped — SCRAPERAPI_KEY not set")

    # ── Method 4: nodriver (undetected Chrome) ──
    if status_cb:
        await status_cb(
            "🕵️ <b>جاري المحاولة بمتصفح غير مكتشف...</b>\n"
            "⏳ nodriver يحاول تجاوز Cloudflare (30 ثانية)"
        )
    imgs = await _nodriver_fetch(chapter_url)
    if imgs:
        return imgs

    # ── Method 5: Playwright (real Chromium) ──
    if status_cb:
        await status_cb(
            "🌐 <b>جاري فتح الصفحة بالمتصفح...</b>\n"
            "⏳ انتظار تجاوز Cloudflare (قد يستغرق 90 ثانية)"
        )
    imgs = await _playwright_fetch(chapter_url)
    if imgs:
        return imgs

    logger.warning("get_chapter_images: all 5 methods failed for %s", chapter_url)
    return None


# ─────────────────────────────────────────────────────────
#  Inline keyboard on link detection
# ─────────────────────────────────────────────────────────

async def show_chapter_options(m: Message, url: str) -> None:
    parsed = parse_url(url)
    if not parsed:
        await m.reply_text("❌ الرابط غير صالح — تأكد أنه رابط فصل من arabshentai.com")
        return
    manga_slug, chapter_slug = parsed

    key_cbz = cache_url("ash_cbz", url)
    key_pdf = cache_url("ash_pdf", url)

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📦 CBZ", callback_data=f"d_ash_cbz_{key_cbz}"),
            InlineKeyboardButton("📄 PDF", callback_data=f"d_ash_pdf_{key_pdf}"),
        ],
        [InlineKeyboardButton("🌐 Open Chapter", url=url)],
    ])

    try:
        info = await get_manga_info(manga_slug)
        if info:
            caption = (
                f"📖 <b>{info['title']}</b>\n"
                f"<b>فصل:</b> <code>{chapter_slug}</code>"
                + (f"\n\n{info['description'][:200]}" if info["description"] else "")
            )
            if info.get("cover_url"):
                try:
                    loop = asyncio.get_event_loop()
                    raw = await loop.run_in_executor(
                        None,
                        lambda: cffi_requests.get(
                            info["cover_url"],
                            impersonate=IMPERSONATE,
                            headers=HEADERS,
                            timeout=15,
                        ).content,
                    )
                    if raw:
                        clean = await _process_thumb_bytes(raw)
                        await m.reply_photo(
                            photo=BytesIO(clean),
                            caption=caption,
                            reply_markup=markup,
                        )
                        return
                except Exception:
                    pass
            await m.reply_text(caption, reply_markup=markup)
            return
    except Exception as exc:
        logger.warning("show_chapter_options: %s", exc)

    await m.reply_text("📖 <b>Arabs Hentai</b>", reply_markup=markup)
