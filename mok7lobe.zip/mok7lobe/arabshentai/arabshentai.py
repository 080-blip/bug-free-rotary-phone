"""
arabshentai.com plugin — Pyrogram handlers
Detects chapter URLs and downloads manga pages as CBZ or PDF.
"""
import os
import asyncio
import zipfile
import logging
import tempfile
from io import BytesIO

from curl_cffi import requests as cffi_requests
from PIL import Image as PILImage
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import (
    parse_url, show_chapter_options, get_manga_info,
    get_chapter_images, IMPERSONATE, HEADERS, BASE_URL,
)
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import (
    clean_downloads, safe_edit, remove_file, remove_glob_files,
)
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor

logger = logging.getLogger(__name__)

DOWNLOAD_DIR = "downloads/arabshentai"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────
#  URL detection filter
# ─────────────────────────────────────────────────────────

def _is_chapter(_, __, m: Message) -> bool:
    return bool(
        m.text
        and "arabshentai.com/manga/" in m.text
        and m.text.count("/") >= 5          # has chapter segment
    )


arabshentai_filter = filters.create(_is_chapter, name="arabshentai_filter")


@Client.on_message(arabshentai_filter)
async def arabshentai_options(c: Client, m: Message):
    await show_chapter_options(m, m.text.strip())


# ─────────────────────────────────────────────────────────
#  Shared image downloader
# ─────────────────────────────────────────────────────────

async def _download_images(
    image_urls: list[str],
    title: str,
    page_count: int,
    msg_ref: list,
    c: Client,
    chat_id: int,
) -> dict[int, bytes | None]:
    """Download all chapter images concurrently (4 at a time). Returns {idx: bytes}."""

    async def _dl(session: cffi_requests.AsyncSession, idx: int, url: str):
        for attempt in range(5):
            try:
                r = await session.get(url, headers=HEADERS, timeout=30)
                if r.status_code == 200:
                    return idx, r.content
                if r.status_code == 429:
                    wait = 15 + attempt * 10
                    logger.warning("arabshentai img 429 idx=%d — wait %ds", idx, wait)
                    await asyncio.sleep(wait)
                    continue
                if r.status_code == 404:
                    return idx, None
                await asyncio.sleep(3)
            except Exception as exc:
                logger.warning("arabshentai img dl err idx=%d attempt=%d: %s", idx, attempt + 1, exc)
                await asyncio.sleep(2)
        return idx, None

    results: dict[int, bytes | None] = {}
    downloaded = 0
    sem = asyncio.Semaphore(4)

    async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as session:
        async def _bounded(idx, url):
            async with sem:
                return await _dl(session, idx, url)

        for coro in asyncio.as_completed([_bounded(i, u) for i, u in enumerate(image_urls)]):
            idx, data = await coro
            results[idx] = data
            downloaded += 1
            if downloaded % 5 == 0 or downloaded == page_count:
                pct = downloaded * 100 // page_count
                msg_ref[0] = await safe_edit(
                    msg_ref[0],
                    f"📖 <b>{title}</b>\n⏳ صفحة {downloaded}/{page_count}  ({pct}%)",
                    c=c, chat_id=chat_id,
                )

    return results


# ─────────────────────────────────────────────────────────
#  Build CBZ from results dict
# ─────────────────────────────────────────────────────────

def _build_cbz(cbz_path: str, image_urls: list[str], results: dict[int, bytes | None]) -> int:
    """Write CBZ, return failed count."""
    failed = 0
    with zipfile.ZipFile(cbz_path, "w", compression=zipfile.ZIP_STORED) as zf:
        for idx in sorted(results.keys()):
            data = results[idx]
            if data is None:
                failed += 1
                continue
            url = image_urls[idx]
            ext = url.rsplit(".", 1)[-1].split("?")[0].lower() if "." in url.rsplit("/", 1)[-1] else "jpg"
            zf.writestr(f"{str(idx + 1).zfill(4)}.{ext}", data)
    return failed


# ─────────────────────────────────────────────────────────
#  Build PDF from results dict
# ─────────────────────────────────────────────────────────

def _build_pdf(pdf_path: str, results: dict[int, bytes | None]) -> int:
    """Write PDF, return failed count."""
    failed  = 0
    pages   = []
    first   = None

    for idx in sorted(results.keys()):
        data = results[idx]
        if data is None:
            failed += 1
            continue
        try:
            img = PILImage.open(BytesIO(data)).convert("RGB")
            if first is None:
                first = img
            else:
                pages.append(img)
        except Exception:
            failed += 1

    if first:
        first.save(pdf_path, "PDF", save_all=True, append_images=pages)
    return failed


# ─────────────────────────────────────────────────────────
#  CBZ download callback
# ─────────────────────────────────────────────────────────

@Client.on_callback_query(filters.regex(r"^d_ash_cbz_"), group=-1)
async def ash_cbz(c: Client, q: CallbackQuery):
    page_url = resolve_url(q.data)
    if not page_url:
        await q.answer("⚠️ انتهت الجلسة، أعد إرسال الرابط.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("arabshentai", user_id):
        await q.answer("⚠️ لديك تحميل قيد التشغيل.", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ جاري تحميل الفصل...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ جاري تحميل الفصل...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("arabshentai", user_id)
    clean_downloads()

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    cbz_path = None
    sent_ok  = False

    try:
        parsed = parse_url(page_url)
        if not parsed:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ رابط غير صالح.", c=c, chat_id=chat_id)
            return
        manga_slug, chapter_slug = parsed

        info = await get_manga_info(manga_slug)
        title = (info["title"] if info else manga_slug) or chapter_slug
        manga_id = info["id"] if info else None

        async def _status(text: str):
            nonlocal msg_ref
            msg_ref[0] = await safe_edit(msg_ref[0], text, c=c, chat_id=chat_id)

        await _status("⚡ <b>جاري جلب صور الفصل...</b>\n📡 الطريقة 1: جلب مباشر (بدون browser)")
        image_urls = await get_chapter_images(
            page_url,
            manga_id=manga_id,
            chapter_slug=chapter_slug,
            status_cb=_status,
        )

        if not image_urls:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ <b>تعذّر جلب صور الفصل بجميع الطرق.</b>\n"
                "⚠️ الموقع يستخدم Cloudflare Turnstile — يُعيق الوصول الآلي.\n"
                "💡 جرب مرة أخرى لاحقاً أو افتح الرابط يدوياً.",
                c=c, chat_id=chat_id,
            )
            return
        page_count = len(image_urls)

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📖 <b>{title}</b>\n⏳ تحميل <b>{page_count}</b> صفحة...",
            c=c, chat_id=chat_id,
        )

        results = await _download_images(image_urls, title, page_count, msg_ref, c, chat_id)

        msg_ref[0] = await safe_edit(msg_ref[0], "📦 جاري تجميع CBZ...", c=c, chat_id=chat_id)

        safe_title = "".join(ch for ch in title if ch.isalnum() or ch in " _-()")[:50] or "manga"
        cbz_path = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{chapter_slug}.cbz")
        failed = await run_in_executor(_build_cbz, cbz_path, image_urls, results)

        cbz_size = os.path.getsize(cbz_path)
        if cbz_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ الملف كبير جداً! <code>{humanbytes(cbz_size)}</code>",
                c=c, chat_id=chat_id,
            )
            return

        ok = page_count - failed
        caption = (
            f"📖 <b>{title}</b>\n"
            f"<b>فصل:</b> <code>{chapter_slug}</code>\n"
            f"<b>الصفحات:</b> <code>{ok}</code>"
            + (f"  ⚠️ <i>({failed} فشلت)</i>" if failed else "") + "\n"
            f"<b>الحجم:</b> <code>{humanbytes(cbz_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• Arabs Hentai •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>جاري الرفع...</b>", c=c, chat_id=chat_id)
        await c.send_document(
            chat_id, cbz_path,
            caption=caption,
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=markup,
            file_name=os.path.basename(cbz_path),
        )
        sent_ok = True

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>خطأ:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if cbz_path and os.path.exists(cbz_path):
            remove_file(cbz_path)
        remove_glob_files(f"{DOWNLOAD_DIR}/*")
        clean_downloads()
        if sent_ok:
            try:
                await msg_ref[0].delete()
            except Exception:
                pass
        dl_state.remove_active("arabshentai", user_id)


# ─────────────────────────────────────────────────────────
#  PDF download callback
# ─────────────────────────────────────────────────────────

@Client.on_callback_query(filters.regex(r"^d_ash_pdf_"), group=-1)
async def ash_pdf(c: Client, q: CallbackQuery):
    page_url = resolve_url(q.data)
    if not page_url:
        await q.answer("⚠️ انتهت الجلسة، أعد إرسال الرابط.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("arabshentai", user_id):
        await q.answer("⚠️ لديك تحميل قيد التشغيل.", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ جاري تحميل الفصل...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ جاري تحميل الفصل...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("arabshentai", user_id)
    clean_downloads()

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    pdf_path = None
    sent_ok  = False

    try:
        parsed = parse_url(page_url)
        if not parsed:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ رابط غير صالح.", c=c, chat_id=chat_id)
            return
        manga_slug, chapter_slug = parsed

        info = await get_manga_info(manga_slug)
        title = (info["title"] if info else manga_slug) or chapter_slug
        manga_id = info["id"] if info else None

        async def _status(text: str):
            nonlocal msg_ref
            msg_ref[0] = await safe_edit(msg_ref[0], text, c=c, chat_id=chat_id)

        await _status("⚡ <b>جاري جلب صور الفصل...</b>\n📡 الطريقة 1: جلب مباشر (بدون browser)")
        image_urls = await get_chapter_images(
            page_url,
            manga_id=manga_id,
            chapter_slug=chapter_slug,
            status_cb=_status,
        )

        if not image_urls:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ <b>تعذّر جلب صور الفصل بجميع الطرق.</b>\n"
                "⚠️ الموقع يستخدم Cloudflare Turnstile — يُعيق الوصول الآلي.\n"
                "💡 جرب مرة أخرى لاحقاً أو افتح الرابط يدوياً.",
                c=c, chat_id=chat_id,
            )
            return
        page_count = len(image_urls)

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📖 <b>{title}</b>\n⏳ تحميل <b>{page_count}</b> صفحة...",
            c=c, chat_id=chat_id,
        )

        results = await _download_images(image_urls, title, page_count, msg_ref, c, chat_id)

        msg_ref[0] = await safe_edit(msg_ref[0], "📄 جاري إنشاء PDF...", c=c, chat_id=chat_id)

        safe_title = "".join(ch for ch in title if ch.isalnum() or ch in " _-()")[:50] or "manga"
        pdf_path = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{chapter_slug}.pdf")
        failed = await run_in_executor(_build_pdf, pdf_path, results)

        pdf_size = os.path.getsize(pdf_path)
        if pdf_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ الملف كبير جداً! <code>{humanbytes(pdf_size)}</code>",
                c=c, chat_id=chat_id,
            )
            return

        ok = page_count - failed
        caption = (
            f"📖 <b>{title}</b>\n"
            f"<b>فصل:</b> <code>{chapter_slug}</code>\n"
            f"<b>الصفحات:</b> <code>{ok}</code>"
            + (f"  ⚠️ <i>({failed} فشلت)</i>" if failed else "") + "\n"
            f"<b>الحجم:</b> <code>{humanbytes(pdf_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• Arabs Hentai •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>جاري الرفع...</b>", c=c, chat_id=chat_id)
        await c.send_document(
            chat_id, pdf_path,
            caption=caption,
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=markup,
            file_name=os.path.basename(pdf_path),
        )
        sent_ok = True

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>خطأ:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if pdf_path and os.path.exists(pdf_path):
            remove_file(pdf_path)
        remove_glob_files(f"{DOWNLOAD_DIR}/*")
        clean_downloads()
        if sent_ok:
            try:
                await msg_ref[0].delete()
            except Exception:
                pass
        dl_state.remove_active("arabshentai", user_id)
