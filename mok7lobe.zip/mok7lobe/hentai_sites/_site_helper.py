"""
Hentai/animation video sites — yt-dlp with site-specific HTML scraper fallbacks.

yt-dlp native:   hentai.yoga, cartoonsworld.vip, hentaigem.com
HTML scraper:    xanimu.com
Chain scraper:   xhentai.tv  (page → embed → zmdplayer → XVideos CDN MP4)
                 3dporndude.com (page → flashvars video_alt_url with v-acctoken)
Not feasible:    sakuhentai.net (JS-only embeds), 3hentai.net (image gallery),
                 deviantart.com (403 blocked)
"""
import re
import json
import asyncio
import html as _html
from io import BytesIO

import httpx
import yt_dlp as youtube_dl
from yt_dlp.utils import UnsupportedError, DownloadError

from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.function import run_in_executor
from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_JSONLD_RE      = re.compile(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>', re.S)
_3DPD_ALT_RE    = re.compile(r"video_alt_url\s*:\s*'(https?://3dporndude\.com/get_file/[^']+)'")
_3DPD_URL_RE    = re.compile(r"video_url\s*:\s*'(https?://3dporndude\.com/get_file/[^']+)'")
_XHENTAI_VID_RE = re.compile(r"videoId\s*:\s*['\"]?(\d+)")
_XHENTAI_ZMD_RE = re.compile(r'(https://xhentai\.tv/[^"\'<>\s]*/zmdplayer/[^"\'<>\s]+/)')
_XANIMU_VERIFY_RE = re.compile(
    r'(https?://[^\s"\'<>]*nosofiles\.com/[^\s"\'<>]+_high\.mp4\?verify=[^\s"\'<>]+)',
    re.I
)
_XANIMU_MP4_RE = re.compile(
    r'(https?://[^\s"\'<>]*nosofiles\.com/[^\s"\'<>]+_high\.mp4[^\s"\'<>]*)',
    re.I
)


class _Silent:
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


_YDL_OPTS = {
    "logger":            _Silent(),
    "quiet":             True,
    "no_warnings":       True,
    "skip_download":     True,
    "noplaylist":        True,
    "socket_timeout":    20,
    "extractor_retries": 2,
    "http_headers":      {"User-Agent": _UA},
}


# ── Helpers ──────────────────────────────────────────────────────────────────

def _parse_jsonld(page: str) -> dict:
    for block in _JSONLD_RE.findall(page):
        try:
            d = json.loads(block)
            if d.get("@type") == "VideoObject":
                return d
        except Exception:
            pass
    return {}


def _parse_iso_duration(dur: str) -> int:
    try:
        m = re.match(r'P.*?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', dur or "")
        if m:
            return int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + int(m.group(3) or 0)
    except Exception:
        pass
    return 0


def _fmt_duration(seconds) -> str:
    try:
        s = int(seconds)
        h, rem = divmod(s, 3600)
        mi, sec = divmod(rem, 60)
        return f"{h}:{mi:02d}:{sec:02d}" if h else f"{mi}:{sec:02d}"
    except Exception:
        return ""


def _ld_title(ld: dict, page: str, fallback: str = "Video") -> str:
    title = _html.unescape(re.sub(r"<[^>]+>", "", ld.get("name", ""))).strip()
    if not title:
        m = re.search(r'<title>([^<]+)</title>', page, re.I)
        title = m.group(1).strip() if m else fallback
    return title


def _ld_thumb(ld: dict):
    thumb = ld.get("thumbnailUrl")
    if isinstance(thumb, list):
        return thumb[-1] if thumb else None
    return thumb


async def _fetch_page(url: str, referer: str = "") -> str | None:
    headers = {"User-Agent": _UA}
    if referer:
        headers["Referer"] = referer
    try:
        async with httpx.AsyncClient(
            timeout=20, follow_redirects=True, headers=headers
        ) as c:
            r = await c.get(url)
            if r.status_code == 200:
                return r.text
    except Exception:
        pass
    return None


async def _ydl_extract(url: str) -> dict | None:
    def _run():
        with youtube_dl.YoutubeDL(_YDL_OPTS) as ydl:
            return ydl.extract_info(url, download=False)
    try:
        return await asyncio.wait_for(run_in_executor(_run), timeout=35)
    except (UnsupportedError, DownloadError):
        return None
    except Exception:
        return None


# ── Site-specific scrapers ────────────────────────────────────────────────────

async def get_3dporndude_video_url(page_url: str) -> str | None:
    """
    Re-fetch a fresh video URL from 3dporndude.com.
    Extracts video_alt_url (720p) or video_url (480p) from the flashvars script.
    These URLs include ?v-acctoken= which may expire — always re-scraped at download time.
    """
    page = await _fetch_page(page_url)
    if not page:
        return None
    m = _3DPD_ALT_RE.search(page) or _3DPD_URL_RE.search(page)
    if not m:
        return None
    return m.group(1)


async def _scrape_3dporndude(url: str) -> dict | None:
    """
    3dporndude.com: yt-dlp picks an ad. Real video lives in flashvars
    as video_alt_url / video_url with a ?v-acctoken= parameter.
    We store the page URL so the download handler can re-scrape for a fresh token.
    """
    page = await _fetch_page(url)
    if not page:
        return None
    m = _3DPD_ALT_RE.search(page) or _3DPD_URL_RE.search(page)
    if not m:
        return None
    ld = _parse_jsonld(page)
    return {
        "download_url": url,
        "title":        _ld_title(ld, page, "3D Porn Dude"),
        "thumbnail":    _ld_thumb(ld),
        "duration":     _parse_iso_duration(ld.get("duration", "")),
    }


async def get_xanimu_video_url(page_url: str) -> str | None:
    """
    Re-fetch a fresh video URL from xanimu.com.
    Prefers _high.mp4?verify=... (required, URL without verify returns 403).
    Always re-scraped at download time since verify tokens expire.
    """
    page = await _fetch_page(page_url)
    if not page:
        return None
    m = _XANIMU_VERIFY_RE.search(page) or _XANIMU_MP4_RE.search(page)
    return m.group(1) if m else None


async def _scrape_xanimu(url: str) -> dict | None:
    """
    xanimu.com: URL without ?verify= returns 403.
    We store the page URL and re-scrape a fresh verify token at download time.
    """
    page = await _fetch_page(url)
    if not page:
        return None
    m = _XANIMU_VERIFY_RE.search(page) or _XANIMU_MP4_RE.search(page)
    if not m:
        return None
    ld = _parse_jsonld(page)
    return {
        "download_url": url,
        "title":        _ld_title(ld, page, "XAniMu"),
        "thumbnail":    _ld_thumb(ld),
        "duration":     _parse_iso_duration(ld.get("duration", "")),
    }


async def get_xhentai_video_url(page_url: str) -> str | None:
    """
    Re-fetch a fresh (time-limited) video URL from xhentai.tv.
    Chain: page → embed → zmdplayer → XVideos CDN MP4.
    Called both during show_options (to verify video exists) and during download
    (to get a non-expired URL).
    """
    page = await _fetch_page(page_url)
    if not page:
        return None
    vid_m = _XHENTAI_VID_RE.search(page)
    if not vid_m:
        return None
    embed_url = f"https://xhentai.tv/tr/embed/{vid_m.group(1)}"
    embed = await _fetch_page(embed_url, referer=page_url)
    if not embed:
        return None
    zmd_m = _XHENTAI_ZMD_RE.search(embed)
    if not zmd_m:
        return None
    zmd_page = await _fetch_page(zmd_m.group(1), referer=embed_url)
    if not zmd_page:
        return None
    # Prefer highest resolution MP4 available
    mp4s = re.findall(r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]*)?)', zmd_page, re.I)
    if not mp4s:
        return None
    # Sort: prefer higher-res (1080p > 720p > 480p > 240p)
    def _res(u: str) -> int:
        for res in (1080, 720, 480, 360, 240):
            if f"{res}p" in u:
                return res
        return 0
    return sorted(mp4s, key=_res, reverse=True)[0]


async def _scrape_xhentai(url: str) -> dict | None:
    page = await _fetch_page(url)
    if not page:
        return None
    ld    = _parse_jsonld(page)
    title = _ld_title(ld, page, "XHentai Video")
    thumb = _ld_thumb(ld)
    dur   = _parse_iso_duration(ld.get("duration", ""))
    # Verify video is actually accessible (pre-fetch chain)
    video_url = await get_xhentai_video_url(url)
    if not video_url:
        return None
    # Cache page URL — fresh video URL fetched in download handler (token expires)
    return {
        "download_url": url,
        "title":        title,
        "thumbnail":    thumb,
        "duration":     dur,
    }


# ── Public API ────────────────────────────────────────────────────────────────

async def get_video_info(url: str) -> dict | None:
    domain = url.lower()

    if "3dporndude.com" in domain:
        return await _scrape_3dporndude(url)

    if "xhentai.tv" in domain:
        return await _scrape_xhentai(url)

    if "xanimu.com" in domain:
        return await _scrape_xanimu(url)

    # yt-dlp for natively supported sites
    info = await _ydl_extract(url)
    if info:
        thumb = info.get("thumbnail") or (
            (info.get("thumbnails") or [{}])[-1].get("url")
        )
        return {
            "download_url": url,
            "title":        info.get("title") or "Video",
            "thumbnail":    thumb,
            "duration":     int(info.get("duration") or 0),
        }

    # Generic HTML fallback
    return None


async def show_options(m: Message, url: str) -> None:
    domain = url.lower()

    # Sites with known limitations — give clear error up front
    if "sakuhentai.net" in domain:
        await m.reply_text(
            "⚠️ <b>SakuHentai videos cannot be downloaded.</b>\n\n"
            "The site uses JavaScript-only embed players that are not accessible from the server.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🌐 Watch on web", url=url)
            ]]),
        )
        return

    if "3hentai.net" in domain:
        await m.reply_text(
            "⚠️ <b>3Hentai is an image gallery, not a video site.</b>\n\n"
            "It hosts manga/doujin images. There are no videos to download.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🌐 Open gallery", url=url)
            ]]),
        )
        return

    if "deviantart.com" in domain:
        await m.reply_text(
            "⚠️ <b>DeviantArt is not supported.</b>\n\n"
            "The site blocks access from this server (403).",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🌐 Open on web", url=url)
            ]]),
        )
        return

    info = await get_video_info(url)

    if not info:
        await m.reply_text(
            "⚠️ Could not extract video info from this link.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🌐 Watch on web", url=url)
            ]]),
        )
        return

    key          = cache_url("hs", info["download_url"])
    callback_key = f"d_hs_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_key)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    title    = info["title"]
    duration = info.get("duration", 0)
    caption  = f"🎬 <b>{title}</b>"
    if duration:
        caption += f"\n⏱ <b>Duration:</b> <code>{_fmt_duration(duration)}</code>"

    thumb_url = info.get("thumbnail")
    if thumb_url:
        try:
            raw = await fetch_bytes(str(thumb_url))
            if raw:
                clean = await _process_thumb_bytes(raw)
                await m.reply_photo(photo=BytesIO(clean), caption=caption, reply_markup=markup)
                return
        except Exception:
            pass

    await m.reply_text(caption, reply_markup=markup)
