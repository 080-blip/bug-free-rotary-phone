import os
import re
import glob

import yt_dlp as youtube_dl
from yt_dlp.utils import DownloadError

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import show_options, get_xhentai_video_url, get_3dporndude_video_url, get_xanimu_video_url
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, FFMPEG, _get_best_thumb, remove_file
from PornHub.plugins import dl_state
from PornHub.plugins.function import (
    download_progress_hook, upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor
)

_DOMAINS_RE = re.compile(
    r'(?:hentai\.yoga|cartoonsworld\.vip|3dporndude\.com|hentaigem\.com'
    r'|xanimu\.com|xhentai\.tv'
    r'|3hentai\.net|deviantart\.com)',
    re.I
)


def _check(_, __, m):
    return bool(m.text and _DOMAINS_RE.search(m.text))


hs_filter = filters.create(_check, name="hs_filter")


@Client.on_message(hs_filter)
async def hs_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


class _Silent:
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


@Client.on_callback_query(filters.regex(r"^d_hs_"), group=-1)
async def hs_download(c: Client, q: CallbackQuery):
    full_key = q.data
    url      = resolve_url(full_key)

    if not url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("hentai", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Preparing download...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Preparing download...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("hentai", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    # ── Resolve real download URL for sites needing special handling ──
    extra_headers = {}
    download_url  = url

    if "3dporndude.com" in url:
        msg_ref[0] = await safe_edit(msg_ref[0], "⏳ Fetching fresh video URL from 3dporndude.com...", c=c, chat_id=chat_id)
        fresh = await get_3dporndude_video_url(url)
        if not fresh:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not extract a valid video URL from 3dporndude.com.\n"
                "The page may have changed or the video was removed.",
                c=c, chat_id=chat_id,
            )
            dl_state.remove_active("hentai", user_id)
            return
        download_url  = fresh
        extra_headers = {"Referer": "https://3dporndude.com/"}

    elif "xhentai.tv" in url:
        msg_ref[0] = await safe_edit(msg_ref[0], "⏳ Fetching fresh video URL from xhentai.tv...", c=c, chat_id=chat_id)
        fresh = await get_xhentai_video_url(url)
        if not fresh:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not extract a valid video URL from xhentai.tv.\n"
                "The page may have changed or the video was removed.",
                c=c, chat_id=chat_id,
            )
            dl_state.remove_active("hentai", user_id)
            return
        download_url  = fresh
        extra_headers = {"Referer": "https://xhentai.tv/"}

    elif "xanimu.com" in url:
        msg_ref[0] = await safe_edit(msg_ref[0], "⏳ Fetching fresh video URL from xanimu.com...", c=c, chat_id=chat_id)
        fresh = await get_xanimu_video_url(url)
        if not fresh:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not extract a valid video URL from xanimu.com.\n"
                "The page may have changed or the video was removed.",
                c=c, chat_id=chat_id,
            )
            dl_state.remove_active("hentai", user_id)
            return
        download_url  = fresh
        extra_headers = {"Referer": "https://xanimu.com/"}

    ydl_opts = {
        "outtmpl":                       "downloads/hentai/%(title)s [%(id)s].%(ext)s",
        "format":                        "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "merge_output_format":           "mp4",
        "progress_hooks":                [lambda d: download_progress_hook(d, msg_ref, c, chat_id)],
        "noplaylist":                    True,
        "retries":                       10,
        "fragment_retries":              10,
        "skip_unavailable_fragments":    True,
        "socket_timeout":                30,
        "http_chunk_size":               10485760,
        "concurrent_fragment_downloads": 8,
        "buffersize":                    1024 * 16,
        "noprogress":                    True,
        "quiet":                         True,
        "no_warnings":                   True,
        "ignoreerrors":                  False,
        "logger":                        _Silent(),
        "ffmpeg_location":               FFMPEG,
        "writethumbnail":                True,
        "postprocessors":                [{"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}],
        "http_headers": {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            **extra_headers,
        },
    }

    downloaded_file = None
    try:
        def _do_download():
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(download_url)

        try:
            info = await run_in_executor(_do_download)
        except DownloadError as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Download failed:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return
        except Exception as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return

        if not info:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ Could not extract video info.", c=c, chat_id=chat_id)
            return

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            fname = ydl.prepare_filename(info)
        base, _ = os.path.splitext(fname)
        for ext in [".mp4", ".mkv", ".webm"]:
            if os.path.exists(base + ext):
                downloaded_file = base + ext
                break

        if not downloaded_file:
            for ext in (".mp4", ".mkv", ".webm"):
                matches = glob.glob(f"downloads/hentai/*{ext}")
                if matches:
                    downloaded_file = max(matches, key=os.path.getmtime)
                    break

        if not downloaded_file or not os.path.exists(downloaded_file):
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ File not found after download.", c=c, chat_id=chat_id)
            return

        file_size = os.path.getsize(downloaded_file)
        file_name = os.path.basename(downloaded_file)

        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n\n"
                f"<b>File:</b> <code>{file_name}</code>\n"
                f"<b>Size:</b> <code>{humanbytes(file_size)}</code>\n"
                f"<i>Maximum allowed: 2 GiB.</i>",
                c=c, chat_id=chat_id,
            )
            return

        width    = info.get("width")  or 1280
        height   = info.get("height") or 720
        duration = int(info.get("duration") or 0)

        thumb_path = await _get_best_thumb(downloaded_file, duration, info)

        _match    = re.match(r"^(.*?)\s*\[([^\]]+)\]\..*$", file_name)
        vid_title = _match.group(1).strip() if _match else file_name
        vid_id    = _match.group(2).strip() if _match else ""

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📤 <b>Uploading...</b>\n<code>{vid_title}</code>",
            c=c, chat_id=chat_id,
        )
        await c.send_video(
            chat_id,
            downloaded_file,
            thumb=thumb_path,
            width=width,
            height=height,
            duration=duration,
            supports_streaming=True,
            caption=(
                f"<b>Name:</b> <code>{vid_title}</code>\n"
                + (f"<b>ID:</b>   <code>{vid_id}</code>\n" if vid_id else "")
                + f"<b>Size:</b>  <code>{humanbytes(file_size)}</code>"
            ),
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("• Watch on web •", url=url),
            ]]),
        )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                remove_file(downloaded_file)
            except Exception:
                pass
        if downloaded_file:
            base = os.path.splitext(downloaded_file)[0]
            for ext in (".jpg", ".jpeg", ".webp", ".png", "_thumb.jpg"):
                leftover = base + ext
                if os.path.exists(leftover):
                    try:
                        os.remove(leftover)
                    except Exception:
                        pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("hentai", user_id)
