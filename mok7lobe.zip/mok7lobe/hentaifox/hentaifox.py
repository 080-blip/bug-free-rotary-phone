import os
import re
import asyncio

import httpx
import yt_dlp
from yt_dlp.utils import DownloadError

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import show_options, get_hentaifox_video_url
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, FFMPEG, _get_best_thumb, prepare_video_meta, remove_file
from PornHub.plugins import dl_state
from PornHub.plugins.function import (
    download_progress_hook, upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor
)

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


def _check(_, __, m):
    return bool(m.text and "hentaifox.tv/video/" in m.text)


hentaifox_filter = filters.create(_check, name="hentaifox_filter")


@Client.on_message(hentaifox_filter)
async def hentaifox_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


@Client.on_callback_query(filters.regex(r"^d_hfox_"), group=-1)
async def hentaifox_download(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("hentaifox", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching video from HentaiFox...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching video from HentaiFox...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("hentaifox", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    video_url = await get_hentaifox_video_url(page_url)

    if not video_url:
        msg_ref[0] = await safe_edit(
            msg_ref[0],
            "❌ <b>HentaiFox.tv — Video URL not found</b>\n\n"
            "Could not intercept the video stream from the player.\n"
            "Please watch the video directly on the site.",
            c=c, chat_id=chat_id,
        )
        dl_state.remove_active("hentaifox", user_id)
        return

    os.makedirs("downloads/hentaifox", exist_ok=True)
    downloaded_file = None

    try:
        ydl_opts = {
            "outtmpl":                       "downloads/hentaifox/%(title)s [%(id)s].%(ext)s",
            "format":                        "bestvideo[ext=mp4]+bestaudio/best[ext=mp4]/best",
            "merge_output_format":           "mp4",
            "progress_hooks":                [lambda d: download_progress_hook(d, msg_ref, c, chat_id)],
            "noplaylist":                    True,
            "retries":                       5,
            "fragment_retries":              5,
            "skip_unavailable_fragments":    True,
            "socket_timeout":                30,
            "concurrent_fragment_downloads": 4,
            "noprogress":                    True,
            "quiet":                         True,
            "no_warnings":                   True,
            "ffmpeg_location":               FFMPEG,
            "http_headers":                  {"Referer": page_url, "User-Agent": UA},
        }

        def _do_download():
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(video_url)

        try:
            info = await run_in_executor(_do_download)
        except DownloadError as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Download failed:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return
        except Exception as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return

        import glob
        for ext in (".mp4", ".mkv", ".webm"):
            matches = glob.glob(f"downloads/hentaifox/*{ext}")
            if matches:
                downloaded_file = max(matches, key=os.path.getmtime)
                break

        if not downloaded_file or not os.path.exists(downloaded_file):
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ File not found after download.", c=c, chat_id=chat_id)
            return

        file_size = os.path.getsize(downloaded_file)
        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(msg_ref[0], f"⚠️ File too large: {humanbytes(file_size)}", c=c, chat_id=chat_id)
            return

        duration, width, height = await prepare_video_meta(downloaded_file, info)
        thumb_path = await _get_best_thumb(downloaded_file, duration, info or {})
        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading...</b>", c=c, chat_id=chat_id)

        await c.send_video(
            chat_id, downloaded_file,
            thumb=thumb_path,
            width=width, height=height, duration=duration,
            supports_streaming=True,
            caption=f"<b>Source:</b> HentaiFox\n<b>Size:</b> <code>{humanbytes(file_size)}</code>",
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("• HentaiFox •", url=page_url)]]),
        )
        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                remove_file(downloaded_file)
            except Exception:
                pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("hentaifox", user_id)
