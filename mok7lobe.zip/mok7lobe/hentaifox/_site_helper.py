"""
HentaiFox.tv — Playwright-based scraper.
The embed player loads video sources via JS; we use Playwright to intercept them.
"""
import re
import asyncio
from io import BytesIO

import httpx
from curl_cffi.requests import AsyncSession
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url
from _playwright_helper import get_chromium_path

_TITLE_RE = re.compile(r'<title>([^<]+)</title>', re.I)
_THUMB_RE = re.compile(
    r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)["\']', re.I
)

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


def _slug_from_url(url: str) -> str | None:
    m = re.search(r'hentaifox\.tv/video/([^/?#]+)', url)
    return m.group(1) if m else None


async def get_hentaifox_video_url(page_url: str) -> str | None:
    """Use Playwright to intercept the video URL from the embed player."""
    slug = _slug_from_url(page_url)
    if not slug:
        return None
    embed_url = f"https://hentaifox.tv/embed_new.php?name={slug}"

    chromium = get_chromium_path()
    if not chromium:
        return None

    for attempt in range(2):
        try:
            from playwright.async_api import async_playwright

            video_url: list[str] = []

            async with async_playwright() as p:
                browser = await p.chromium.launch(
                    executable_path=chromium,
                    headless=True,
                    args=["--no-sandbox", "--disable-dev-shm-usage"],
                )
                ctx = await browser.new_context(
                    user_agent=UA,
                    extra_http_headers={"Referer": page_url},
                )
                pg = await ctx.new_page()

                def _on_req(request):
                    u = request.url
                    if (".m3u8" in u or ".mp4" in u) and "hentaifox.tv" not in u:
                        if u not in video_url:
                            video_url.append(u)

                pg.on("request", _on_req)

                try:
                    await pg.goto(embed_url, timeout=25000, wait_until="domcontentloaded")
                    await asyncio.sleep(5)
                except Exception:
                    pass

                if not video_url:
                    try:
                        sources = await pg.query_selector_all("video source, video")
                        for el in sources:
                            src = await el.get_attribute("src")
                            if src and (".m3u8" in src or ".mp4" in src):
                                video_url.append(src)
                    except Exception:
                        pass

                await ctx.close()
                await browser.close()

            if video_url:
                return video_url[0]
        except Exception:
            pass

        if attempt == 0:
            await asyncio.sleep(3)

    return None


async def show_options(m: Message, url: str) -> None:
    key           = cache_url("hfox", url)
    callback_data = f"d_hfox_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    try:
        async with AsyncSession() as s:
            r = await s.get(url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=15)
        body    = r.text
        title_m = _TITLE_RE.search(body)
        thumb_m = _THUMB_RE.search(body)
        title   = title_m.group(1).strip() if title_m else "HentaiFox"
        caption = f"🎬 <b>{title}</b>"

        if thumb_m:
            try:
                async with httpx.AsyncClient(timeout=10, follow_redirects=True) as c:
                    raw = (await c.get(thumb_m.group(1))).content
                if raw:
                    clean = await _process_thumb_bytes(raw)
                    await m.reply_photo(photo=BytesIO(clean), caption=caption,
                                        reply_markup=markup)
                    return
            except Exception:
                pass
        await m.reply_text(caption, reply_markup=markup)
    except Exception:
        await m.reply_text("🎬 HentaiFox video", reply_markup=markup)
