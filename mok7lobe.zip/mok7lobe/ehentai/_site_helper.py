"""
e-hentai.org — gallery image extractor
No Cloudflare, works with direct HTTP + official JSON API.

URL formats:
  https://e-hentai.org/g/{gid}/{token}/
  https://exhentai.org/g/{gid}/{token}/   (requires cookies — not supported)
"""
import re
import json
import time
import asyncio
import logging

from curl_cffi import requests as cffi_requests
from bs4 import BeautifulSoup
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.url_cache import cache_url

logger = logging.getLogger(__name__)

BASE_URL    = "https://e-hentai.org"
API_URL     = "https://api.e-hentai.org/api.php"
IMPERSONATE = "chrome131"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": BASE_URL + "/",
}

_GALLERY_RE = re.compile(
    r"e-?hentai\.org/g/(\d+)/([a-f0-9]+)/?", re.I
)
_PAGE_HASH_RE = re.compile(
    r"e-?hentai\.org/s/([a-f0-9]+)/(\d+)-(\d+)"
)

# Thumbnail domains to exclude when looking for the full-size image
_THUMB_DOMAINS = ("ehgt.org/g/", "ehgt.org/m/", "ehgt.org/t/")


def parse_url(url: str) -> tuple[str, str] | None:
    """Return (gid, token) or None."""
    m = _GALLERY_RE.search(url)
    return (m.group(1), m.group(2)) if m else None


def _get(url: str, **kw) -> cffi_requests.Response:
    return cffi_requests.get(url, headers=HEADERS, impersonate=IMPERSONATE, timeout=20, **kw)


def get_gallery_info(gid: str, token: str) -> dict | None:
    """
    Use e-hentai JSON API to get gallery metadata.
    """
    try:
        payload = json.dumps({
            "method": "gdata",
            "gidlist": [[int(gid), token]],
            "namespace": 1,
        })
        r = cffi_requests.post(
            API_URL,
            data=payload,
            headers={**HEADERS, "Content-Type": "application/json"},
            impersonate=IMPERSONATE,
            timeout=15,
        )
        data = r.json()
        meta = data.get("gmetadata", [{}])[0]
        if meta.get("error"):
            logger.warning("e-hentai API error for %s: %s", gid, meta)
            return None

        return {
            "id":          gid,
            "token":       token,
            "title":       meta.get("title") or meta.get("title_jpn") or f"Gallery {gid}",
            "cover_url":   meta.get("thumb", ""),
            "total_pages": int(meta.get("filecount", 0)),
            "category":    meta.get("category", ""),
            "rating":      meta.get("rating", ""),
            "url":         f"{BASE_URL}/g/{gid}/{token}/",
        }

    except Exception as exc:
        logger.warning("e-hentai get_gallery_info %s: %s", gid, exc)
        return None


def _get_page_hashes_from_gallery(gid: str, token: str, total_pages: int) -> list[tuple[str, int]]:
    """
    Scrape the gallery listing page(s) to collect all (page_hash, page_num) pairs.
    e-hentai shows 40 thumbnails per gallery listing page (p=0, p=1, ...).

    Strategy: keep fetching listing pages until:
      - We got fewer new hashes than 40 on this page (last page reached), OR
      - HTTP error, OR
      - We have >= total_pages hashes already.
    This avoids depending solely on total_pages from the API (which can lag).
    """
    hashes: list[tuple[str, int]] = []
    # Safety cap: never fetch more listing pages than necessary
    max_listing_pages = max((total_pages + 39) // 40, 1) + 2  # +2 buffer

    for gp in range(max_listing_pages):
        url = f"{BASE_URL}/g/{gid}/{token}/"
        if gp > 0:
            url += f"?p={gp}"

        page_hashes: list[tuple[str, int]] = []
        success = False

        for attempt in range(3):
            try:
                r = _get(url)
                if r.status_code == 200:
                    for m in _PAGE_HASH_RE.finditer(r.text):
                        ph     = m.group(1)
                        pg_gid = m.group(2)
                        pg_num = int(m.group(3))
                        if pg_gid == gid:
                            page_hashes.append((ph, pg_num))
                    success = True
                    break
                elif r.status_code in (429, 509):
                    wait = 20 + attempt * 15
                    logger.warning("e-hentai listing p=%d status=%d, retrying in %ds", gp, r.status_code, wait)
                    time.sleep(wait)
                else:
                    logger.warning("e-hentai listing p=%d status=%d — stopping", gp, r.status_code)
                    break
            except Exception as exc:
                logger.warning("e-hentai listing p=%d attempt=%d: %s", gp, attempt + 1, exc)
                time.sleep(3)

        if not success:
            break

        logger.info("e-hentai listing p=%d: found %d hashes", gp, len(page_hashes))
        hashes.extend(page_hashes)

        # Stop if this page returned nothing (past the last listing page)
        if len(page_hashes) == 0:
            break

        # Stop if we already have enough
        if len(hashes) >= total_pages:
            break

    # Remove duplicates, sort by page number
    seen: set[int] = set()
    unique: list[tuple[str, int]] = []
    for ph, pn in sorted(hashes, key=lambda x: x[1]):
        if pn not in seen:
            seen.add(pn)
            unique.append((ph, pn))

    logger.info("e-hentai: total unique hashes=%d (expected %d)", len(unique), total_pages)
    return unique


def _fetch_page_image(page_hash: str, gid: str, page_num: int) -> str | None:
    """Visit /s/{hash}/{gid}-{page} to extract the actual full-size image URL."""
    url = f"{BASE_URL}/s/{page_hash}/{gid}-{page_num}"
    for attempt in range(4):
        try:
            r = _get(url)
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, "html.parser")

                # Primary selector: #img is the full-size viewer image
                for sel in ("#img", "#i3 img", ".sni img", "div#i1 img", "div#i3 a img"):
                    tag = soup.select_one(sel)
                    if tag:
                        src = tag.get("src") or tag.get("data-src") or ""
                        if src and src.startswith("http") and not any(d in src for d in _THUMB_DOMAINS):
                            return src

                # Fallback: find any image URL that looks like a full-size image
                for m in re.finditer(
                    r'(?:src|href)=["\']?(https://[^\s"\'<>]+\.(?:jpg|jpeg|png|webp|gif)(?:\?[^"\'<>\s]*)?)',
                    r.text,
                    re.I,
                ):
                    candidate = m.group(1)
                    if not any(d in candidate for d in _THUMB_DOMAINS):
                        return candidate

                # If we got 200 but found nothing, stop retrying
                logger.warning("e-hentai page %d: could not extract image URL from page", page_num)
                return None

            elif r.status_code in (429, 509):
                wait = 25 + attempt * 20
                logger.warning("e-hentai page %d status=%d, waiting %ds (attempt %d)", page_num, r.status_code, wait, attempt + 1)
                time.sleep(wait)
            elif r.status_code == 404:
                logger.warning("e-hentai page %d: 404", page_num)
                return None
            else:
                wait = 5 + attempt * 5
                logger.warning("e-hentai page %d status=%d, waiting %ds", page_num, r.status_code, wait)
                time.sleep(wait)

        except Exception as exc:
            logger.warning("e-hentai page %d/%s attempt=%d: %s", page_num, page_hash[:8], attempt + 1, exc)
            time.sleep(3 + attempt * 3)

    return None


async def get_gallery_images(
    gid: str,
    token: str,
    total_pages: int,
    status_cb=None,
) -> list[str]:
    """
    Collect all full-size image URLs from an e-hentai gallery.
    Fetches page hashes from gallery listing, then fetches each page concurrently.
    """
    loop = asyncio.get_event_loop()

    if status_cb:
        await status_cb(f"🔍 <b>جاري جلب روابط الصفحات...</b>\n({total_pages} صفحة)")

    hashes = await loop.run_in_executor(
        None, _get_page_hashes_from_gallery, gid, token, total_pages
    )
    if not hashes:
        return []

    if status_cb:
        await status_cb(f"📥 <b>جاري جلب الصور...</b>\n0/{len(hashes)}")

    images: dict[int, str] = {}
    # Semaphore of 3 to avoid 509 bandwidth-exceeded from e-hentai
    sem = asyncio.Semaphore(3)
    fetched = 0

    async def _fetch_one(ph: str, pn: int):
        nonlocal fetched
        async with sem:
            url = await loop.run_in_executor(None, _fetch_page_image, ph, gid, pn)
            fetched += 1
            if status_cb and (fetched % 5 == 0 or fetched == len(hashes)):
                await status_cb(
                    f"📥 <b>جاري جلب الصور...</b>\n{fetched}/{len(hashes)}"
                )
            if url:
                images[pn] = url

    await asyncio.gather(*[_fetch_one(ph, pn) for ph, pn in hashes])

    return [images[pn] for pn in sorted(images.keys()) if pn in images]


async def show_gallery_options(m: Message, url: str) -> None:
    parsed = parse_url(url)
    if not parsed:
        await m.reply_text("❌ الرابط غير صالح — تأكد أنه رابط gallery من e-hentai.org")
        return

    key_cbz = cache_url("eh_cbz", url)
    key_pdf = cache_url("eh_pdf", url)

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📦 CBZ", callback_data=f"d_eh_cbz_{key_cbz}"),
            InlineKeyboardButton("📄 PDF", callback_data=f"d_eh_pdf_{key_pdf}"),
        ],
        [InlineKeyboardButton("🌐 Open Gallery", url=url)],
    ])
    await m.reply_text(
        f"🖼️ <b>E-Hentai</b>\n<code>{url}</code>\n\nاختر صيغة التحميل:",
        reply_markup=markup,
    )
