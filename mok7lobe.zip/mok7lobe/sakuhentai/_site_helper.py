"""
SakuHentai.net — scraper + multi-layer video extractor.

Extraction strategy (in order):
  1. Playwright network interception — catches ALL requests/responses including XHR/fetch.
     Intercepts .m3u8 / .mp4 URLs fired by the JS player after it decodes the source.
  2. DOM scrape after full page load — checks <video src> and <source> tags.
  3. JS evaluate — reads video.src / video.currentSrc directly.
"""
import re
import asyncio
from io import BytesIO
from urllib.parse import urlparse

import httpx
from curl_cffi.requests import AsyncSession
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes
from PornHub.plugins.url_cache import cache_url
from _playwright_helper import get_chromium_path

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_TITLE_RE = re.compile(r'<meta\s+property=["\']og:title["\']\s+content=["\']([^"\']+)["\']', re.I)
_THUMB_RE = re.compile(r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)["\']', re.I)
_EMBED_RE = re.compile(r'data-embed=["\']([^"\']+)["\']', re.I)

_VIDEO_EXTS = ('.m3u8', '.mp4', '.webm', '.mkv')
_SKIP_WORDS = ('thumbnail', 'poster', 'thumb', 'preview', 'ad', 'ads',
               'track', 'subtitle', 'caption', 'font', 'analytics',
               'bigbuckbunny', 'test-video')


def _is_video_url(url: str) -> bool:
    lo = url.lower()
    if not any(ext in lo for ext in _VIDEO_EXTS):
        return False
    if any(w in lo for w in _SKIP_WORDS):
        return False
    return True


async def _fetch_page(url: str) -> str:
    try:
        async with AsyncSession() as s:
            r = await s.get(url, impersonate="chrome124", headers={"User-Agent": UA}, timeout=20)
        return r.text
    except Exception:
        return ""


def _extract_embeds(html: str) -> list[str]:
    return list(dict.fromkeys(m.group(1) for m in _EMBED_RE.finditer(html)))


async def _capture_from_player(player_url: str, chromium: str, page_referer: str) -> str | None:
    """
    Launch Chromium, navigate to player_url, and intercept every network request/response.
    Returns the first video stream URL found, or None.
    """
    try:
        from playwright.async_api import async_playwright

        found: list[str] = []

        async with async_playwright() as p:
            browser = await p.chromium.launch(
                executable_path=chromium,
                headless=True,
                args=[
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-web-security",
                    "--disable-features=IsolateOrigins,site-per-process",
                    "--disable-blink-features=AutomationControlled",
                    "--autoplay-policy=no-user-gesture-required",
                ],
            )

            ctx = await browser.new_context(
                user_agent=UA,
                extra_http_headers={
                    "Referer": page_referer,
                    "Origin": f"{urlparse(page_referer).scheme}://{urlparse(page_referer).netloc}",
                },
                ignore_https_errors=True,
            )

            pg = await ctx.new_page()

            # ── Intercept ALL network requests ────────────────────────────────
            def _on_req(req):
                u = req.url
                if _is_video_url(u) and u not in found:
                    found.append(u)

            async def _on_resp(resp):
                u = resp.url
                if _is_video_url(u) and u not in found:
                    found.append(u)
                # Also check XHR/fetch JSON responses for video URLs
                if resp.request.resource_type in ("xhr", "fetch"):
                    try:
                        body = await resp.text()
                        for match in re.findall(r'https?://[^\s"\'<>]+(?:\.m3u8|\.mp4)[^\s"\'<>]*', body):
                            if _is_video_url(match) and match not in found:
                                found.append(match)
                    except Exception:
                        pass

            pg.on("request", _on_req)
            pg.on("response", _on_resp)

            # ── Navigate to player ────────────────────────────────────────────
            try:
                await pg.goto(player_url, timeout=35000, wait_until="domcontentloaded")
            except Exception:
                pass

            # Wait for initial network activity
            await asyncio.sleep(5)

            # ── Try to trigger playback ───────────────────────────────────────
            if not found:
                play_selectors = [
                    ".vjs-big-play-button",
                    "[data-plyr='play']",
                    ".jw-icon-display",
                    ".jw-display-icon-container",
                    ".jwplayer .jw-display",
                    "button.play",
                    ".play-btn",
                    ".play-button",
                    "video",
                    "div[class*='play']",
                    ".fp-play",
                    "#player",
                ]
                for sel in play_selectors:
                    try:
                        btn = await pg.query_selector(sel)
                        if btn:
                            await btn.click(force=True)
                            await asyncio.sleep(4)
                            if found:
                                break
                    except Exception:
                        pass

            # ── Wait for network to settle ────────────────────────────────────
            if not found:
                try:
                    await pg.wait_for_load_state("networkidle", timeout=15000)
                except Exception:
                    pass
                await asyncio.sleep(3)

            # ── DOM fallback: read <video> / <source> tags ────────────────────
            if not found:
                try:
                    for el in await pg.query_selector_all("video source, video"):
                        for attr in ("src", "data-src"):
                            src = await el.get_attribute(attr)
                            if src and _is_video_url(src) and src not in found:
                                found.append(src)
                except Exception:
                    pass

            # ── JS evaluate fallback ──────────────────────────────────────────
            if not found:
                try:
                    vals = await pg.evaluate("""() => {
                        const results = [];
                        document.querySelectorAll('video').forEach(v => {
                            if (v.src) results.push(v.src);
                            if (v.currentSrc) results.push(v.currentSrc);
                        });
                        // Check jwplayer if present
                        if (window.jwplayer) {
                            try {
                                const p = jwplayer();
                                if (p && p.getPlaylistItem) {
                                    const item = p.getPlaylistItem();
                                    if (item && item.sources) {
                                        item.sources.forEach(s => { if (s.file) results.push(s.file); });
                                    }
                                }
                            } catch(e) {}
                        }
                        return results;
                    }""")
                    for v in (vals or []):
                        if _is_video_url(v) and v not in found:
                            found.append(v)
                except Exception:
                    pass

            await ctx.close()
            await browser.close()

        # Prefer .m3u8 (HLS) over .mp4
        m3u8 = [u for u in found if '.m3u8' in u.lower()]
        mp4   = [u for u in found if '.mp4'  in u.lower()]
        return (m3u8 or mp4 or [None])[0]

    except Exception:
        return None


async def get_saku_video_url(page_url: str) -> str | None:
    """
    Multi-attempt extractor:
    1. Try each embed player with Playwright network interception.
    2. Retry once with longer delay on failure.
    """
    chromium = get_chromium_path()
    if not chromium:
        return None

    html = await _fetch_page(page_url)
    embeds = _extract_embeds(html)

    if not embeds:
        return None

    for embed_url in embeds:
        referer = f"{urlparse(page_url).scheme}://{urlparse(page_url).netloc}/"
        for attempt in range(2):
            result = await _capture_from_player(embed_url, chromium, referer)
            if result:
                return result
            if attempt == 0:
                await asyncio.sleep(3)

    return None


_HTTPX_HEADERS = {
    "User-Agent": UA,
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


async def show_options(m: Message, url: str) -> None:
    key = cache_url("saku", url)
    callback_data = f"d_saku_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    try:
        html = await _fetch_page(url)
        title_m = _TITLE_RE.search(html)
        thumb_m = _THUMB_RE.search(html)
        title = title_m.group(1).strip() if title_m else "SakuHentai"
        # Unescape HTML entities in title
        import html as html_module
        title = html_module.unescape(title)
        caption = f"🎬 <b>{title}</b>"

        if thumb_m:
            thumb_url = thumb_m.group(1)
            _tmp = None
            try:
                hdrs = {**_HTTPX_HEADERS, "Referer": url}
                async with httpx.AsyncClient(
                    timeout=15, follow_redirects=True, headers=hdrs
                ) as client:
                    resp = await client.get(thumb_url)
                    raw = resp.content if resp.status_code == 200 else b""

                if raw and len(raw) > 1024:
                    import os as _os
                    clean = await _process_thumb_bytes(raw)
                    _tmp = f"downloads/_saku_prev_{id(raw) & 0xFFFFFF}.jpg"
                    with open(_tmp, "wb") as _f:
                        _f.write(clean)
                    await m.reply_photo(photo=_tmp, caption=caption, reply_markup=markup)
                    return
            except BaseException as e:
                import logging
                logging.getLogger(__name__).warning(
                    "sakuhentai: thumb error for %s: %s", thumb_url, e
                )
            finally:
                if _tmp:
                    try:
                        import os as _os2; _os2.remove(_tmp)
                    except Exception:
                        pass

        await m.reply_text(caption, reply_markup=markup)

    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("sakuhentai show_options error: %s", e)
        await m.reply_text("🎬 SakuHentai video", reply_markup=markup)
