"""
Rule34.xxx post downloader.
Handles images, GIFs, and videos scraped from post pages.
"""
import os
import re

import httpx
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import show_options, get_r34x_file_url
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, _get_best_thumb, prepare_video_meta
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


def _check(_, __, m):
    return bool(
        m.text
        and "rule34.xxx/" in m.text
        and "page=post" in m.text
        and "s=view" in m.text
    )


r34x_filter = filters.create(_check, name="r34x_filter")


@Client.on_message(r34x_filter)
async def r34x_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


@Client.on_callback_query(filters.regex(r"^d_r34x_"), group=-1)
async def r34x_download(c: Client, q: CallbackQuery):
    full_key = q.data
    url      = resolve_url(full_key)

    if not url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("r34x", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching file...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching file...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("r34x", user_id)
    clean_downloads()

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    tmp_path = None

    try:
        file_url, media_type = await get_r34x_file_url(url)

        if not file_url:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not extract file URL from this post.\n"
                "The post might be an unsupported format.",
                c=c, chat_id=chat_id,
            )
            return

        post_id  = re.search(r'id=(\d+)', url)
        pid      = post_id.group(1) if post_id else "unknown"
        ext      = file_url.rsplit(".", 1)[-1].lower() or "mp4"
        tmp_path = f"downloads/rule34xxx/{pid}.{ext}"
        os.makedirs("downloads/rule34xxx", exist_ok=True)

        msg_ref[0] = await safe_edit(msg_ref[0], "⬇️ Downloading...", c=c, chat_id=chat_id)

        async with httpx.AsyncClient(timeout=120, follow_redirects=True,
                                     headers={"User-Agent": UA, "Referer": "https://rule34.xxx/"}) as hc:
            async with hc.stream("GET", file_url) as resp:
                if resp.status_code not in (200, 206):
                    msg_ref[0] = await safe_edit(
                        msg_ref[0], f"❌ HTTP {resp.status_code} when downloading file.",
                        c=c, chat_id=chat_id,
                    )
                    return
                total = int(resp.headers.get("content-length", 0))
                if total > MAX_TG_SIZE:
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"⚠️ File too large: <code>{humanbytes(total)}</code>",
                        c=c, chat_id=chat_id,
                    )
                    return
                with open(tmp_path, "wb") as f:
                    async for chunk in resp.aiter_bytes(65536):
                        f.write(chunk)

        if not os.path.exists(tmp_path) or os.path.getsize(tmp_path) == 0:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ Download failed (empty file).", c=c, chat_id=chat_id)
            return

        file_size = os.path.getsize(tmp_path)
        caption   = (
            f"<b>Post ID:</b> <code>{pid}</code>\n"
            f"<b>Type:</b>    <code>{media_type}</code>\n"
            f"<b>Size:</b>    <code>{humanbytes(file_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("• Rule34.xxx •", url=url),
        ]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 Uploading...", c=c, chat_id=chat_id)

        if media_type == "video":
            duration, width, height = await prepare_video_meta(tmp_path)
            thumb_path = await _get_best_thumb(tmp_path, duration, {})
            await c.send_video(
                chat_id, tmp_path,
                thumb=thumb_path,
                width=width, height=height, duration=duration,
                supports_streaming=True,
                caption=caption, reply_markup=markup,
                progress=upload_progress, progress_args=(msg_ref, chat_id, c),
            )
            if thumb_path and os.path.exists(thumb_path):
                try:
                    os.remove(thumb_path)
                except Exception:
                    pass
        elif media_type == "gif":
            await c.send_animation(
                chat_id, tmp_path,
                caption=caption, reply_markup=markup,
                progress=upload_progress, progress_args=(msg_ref, chat_id, c),
            )
        else:
            await c.send_document(
                chat_id, tmp_path,
                caption=caption, reply_markup=markup,
                progress=upload_progress, progress_args=(msg_ref, chat_id, c),
            )

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("r34x", user_id)
