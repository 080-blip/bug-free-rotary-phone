"""
Rule34.xxx — curl-cffi HTML scraper.
Extracts the original image/video/GIF from the post page.
"""
import re
from io import BytesIO

import httpx
from curl_cffi.requests import AsyncSession
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes
from PornHub.plugins.url_cache import cache_url

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_IMG_RE  = re.compile(
    r'src=["\']([^"\']+(?:gif|jpg|jpeg|png|webp)[^"\']*)["\'][^>]*id=["\']image["\']'
    r'|id=["\']image["\'][^>]*src=["\']([^"\']+(?:gif|jpg|jpeg|png|webp)[^"\']*)["\']',
    re.I,
)
_VID_SRC = re.compile(
    r'<source[^>]+src=["\']([^"\']+\.(?:mp4|webm)[^"\']*)["\']', re.I | re.S
)
_TITLE_RE = re.compile(r'<title>([^<]+)</title>', re.I)
_POST_ID  = re.compile(r'id=(\d+)', re.I)


def _clean_url(url: str) -> str:
    if url.startswith("//"):
        url = "https:" + url
    url = url.split("?")[0]
    # Normalize double slashes in path (e.g. wimg.rule34.xxx//images/...)
    if "://" in url:
        scheme, rest = url.split("://", 1)
        while "//" in rest:
            rest = rest.replace("//", "/")
        url = scheme + "://" + rest
    return url


def _get_url_from_match(m) -> str:
    """Extract URL from _IMG_RE match (group 1 or 2)."""
    return (m.group(1) or m.group(2) or "").strip()


async def get_r34x_file_url(page_url: str) -> tuple[str | None, str]:
    """Return (file_url, media_type) where media_type is 'video', 'gif', or 'image'."""
    try:
        async with AsyncSession() as s:
            r = await s.get(page_url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=20)
        body = r.text

        # Check for video first
        vm = _VID_SRC.search(body)
        if vm:
            return _clean_url(vm.group(1)), "video"

        # Check for img#image
        im = _IMG_RE.search(body)
        if im:
            url = _clean_url(_get_url_from_match(im))
            if url.lower().endswith(".gif"):
                return url, "gif"
            return url, "image"

        return None, "unknown"
    except Exception:
        return None, "unknown"


async def show_options(m: Message, url: str) -> None:
    key           = cache_url("r34x", url)
    callback_data = f"d_r34x_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 View on web", url=url)],
    ])

    try:
        async with AsyncSession() as s:
            r = await s.get(url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=15)
        body    = r.text
        title_m = _TITLE_RE.search(body)
        title   = title_m.group(1).strip() if title_m else "Rule34.xxx"
        caption = f"🎬 <b>{title}</b>"

        im = _IMG_RE.search(body)
        if im:
            thumb_url = _clean_url(_get_url_from_match(im))
            if thumb_url:
                try:
                    async with httpx.AsyncClient(timeout=12, follow_redirects=True,
                                                 headers={"User-Agent": UA}) as c:
                        raw = (await c.get(thumb_url)).content
                    if raw:
                        clean = await _process_thumb_bytes(raw)
                        await m.reply_photo(photo=BytesIO(clean), caption=caption,
                                            reply_markup=markup)
                        return
                except Exception:
                    pass

        await m.reply_text(caption, reply_markup=markup)
    except Exception:
        await m.reply_text("🎬 Rule34.xxx post", reply_markup=markup)
