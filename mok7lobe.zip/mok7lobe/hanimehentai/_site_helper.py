"""
HanimeHentai.tv — Playwright-based scraper with retry.
The player loads an AES-128 encrypted HLS stream via JavaScript.
We intercept network requests to capture the .m3u8 URL, then
yt-dlp handles AES-128 decryption natively.
"""
import re
import asyncio
from io import BytesIO

import httpx
from curl_cffi.requests import AsyncSession
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url
from _playwright_helper import get_chromium_path

_TITLE_RE  = re.compile(r'<title>([^<]+)</title>', re.I)
_THUMB_RE  = re.compile(
    r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)["\']', re.I
)
_IFRAME_RE = re.compile(
    r'<iframe[^>]+src=["\']([^"\']*player[^"\']*)["\']', re.I
)

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


async def _resolve_player_url(page_url: str) -> str:
    """Get the player.php iframe URL, falling back to page_url."""
    try:
        async with AsyncSession() as s:
            r = await s.get(page_url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=20)
        body = r.text
        iframe_m = _IFRAME_RE.search(body)
        if not iframe_m:
            return page_url
        player = iframe_m.group(1)
        if player.startswith("//"):
            player = "https:" + player
        elif player.startswith("/"):
            from urllib.parse import urlparse
            p = urlparse(page_url)
            player = f"{p.scheme}://{p.netloc}{player}"
        return player
    except Exception:
        return page_url


async def _try_capture_video(player_url: str, chromium: str) -> str | None:
    """Single Playwright attempt to capture a media URL from the player."""
    try:
        from playwright.async_api import async_playwright

        video_urls: list[str] = []

        async with async_playwright() as p:
            browser = await p.chromium.launch(
                executable_path=chromium,
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage",
                      "--disable-web-security"],
            )
            ctx = await browser.new_context(
                user_agent=UA,
                extra_http_headers={"Referer": "https://hanimehentai.tv/"},
            )
            pg = await ctx.new_page()

            def _on_req(request):
                u = request.url
                if ".m3u8" in u and u not in video_urls:
                    video_urls.append(u)
                elif (".mp4" in u
                      and "thumbnail" not in u.lower()
                      and "poster" not in u.lower()
                      and u not in video_urls):
                    video_urls.append(u)

            pg.on("request", _on_req)

            try:
                await pg.goto(player_url, timeout=30000, wait_until="domcontentloaded")
                await asyncio.sleep(6)
            except Exception:
                pass

            # Click a play button if present
            if not video_urls:
                for sel in [
                    ".vjs-big-play-button", "[data-plyr='play']",
                    ".jwplayer", "button.play", ".play-btn",
                ]:
                    try:
                        btn = await pg.query_selector(sel)
                        if btn:
                            await btn.click()
                            await asyncio.sleep(3)
                            break
                    except Exception:
                        pass

            # DOM fallback
            if not video_urls:
                try:
                    for el in await pg.query_selector_all("video source, video"):
                        src = await el.get_attribute("src")
                        if src and (".m3u8" in src or ".mp4" in src):
                            video_urls.append(src)
                except Exception:
                    pass

            # JS evaluate fallback
            if not video_urls:
                try:
                    found = await pg.evaluate("""() => {
                        const v = document.querySelector('video');
                        return v ? (v.src || v.currentSrc || null) : null;
                    }""")
                    if found and (".m3u8" in found or ".mp4" in found):
                        video_urls.append(found)
                except Exception:
                    pass

            await ctx.close()
            await browser.close()

        m3u8 = [u for u in video_urls if ".m3u8" in u]
        mp4  = [u for u in video_urls if ".mp4" in u]
        return (m3u8 or mp4 or [None])[0]

    except Exception:
        return None


async def get_hanim_video_url(page_url: str) -> str | None:
    """
    Use Playwright to intercept the video URL.
    Retries once with a short delay before giving up.
    """
    chromium = get_chromium_path()
    if not chromium:
        return None

    player_url = await _resolve_player_url(page_url)

    for attempt in range(2):
        result = await _try_capture_video(player_url, chromium)
        if result:
            return result
        if attempt == 0:
            await asyncio.sleep(3)

    return None


async def show_options(m: Message, url: str) -> None:
    key           = cache_url("hanim", url)
    callback_data = f"d_hanim_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    try:
        async with AsyncSession() as s:
            r = await s.get(url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=15)
        body    = r.text
        title_m = _TITLE_RE.search(body)
        thumb_m = _THUMB_RE.search(body)
        title   = title_m.group(1).strip() if title_m else "HanimeHentai"
        caption = f"🎬 <b>{title}</b>"

        if thumb_m:
            try:
                async with httpx.AsyncClient(timeout=10, follow_redirects=True) as c:
                    raw = (await c.get(thumb_m.group(1))).content
                if raw:
                    clean = await _process_thumb_bytes(raw)
                    await m.reply_photo(photo=BytesIO(clean), caption=caption,
                                        reply_markup=markup)
                    return
            except Exception:
                pass
        await m.reply_text(caption, reply_markup=markup)
    except Exception:
        await m.reply_text("🎬 HanimeHentai video", reply_markup=markup)
