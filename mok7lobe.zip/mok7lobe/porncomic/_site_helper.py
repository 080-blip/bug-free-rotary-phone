"""
porn-comic.com — curl_cffi scraper (browser impersonation to bypass TLS detection).
Handles two content types:
  /h/{id}.html   → manga/comic  → CBZ download
  /gif/{id}.html → video/gif   → MP4 via yt-dlp
"""
import re
import asyncio
import logging
from io import BytesIO

logger = logging.getLogger(__name__)

import httpx
from curl_cffi import requests as cffi_requests
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes
from PornHub.plugins.url_cache import cache_url

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

HEADERS = {
    "User-Agent": UA,
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.porn-comic.com/",
}

BASE_URL = "https://www.porn-comic.com"

_TITLE_RE       = re.compile(r'<title>([^<]+)</title>', re.I)
_OG_IMG_RE      = re.compile(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', re.I)
_PAGE_IMG_RE    = re.compile(r'class="manga-page"[^>]*>.*?<img[^>]+src=["\']([^"\']+)["\']', re.I | re.S)
_NEXT_RE        = re.compile(r'next_page_url\s*=\s*["\']([^"\']+)["\']', re.I)
_COMIC_ID_RE    = re.compile(r'/h/(\d+)(?:-\d+)?\.html', re.I)
_GIF_ID_RE      = re.compile(r'/gif/(\d+)\.html', re.I)
_CONTENT_URL_RE = re.compile(r'"contentUrl"\s*:\s*"([^"]+)"')
_THUMB_URL_RE   = re.compile(r'"thumbnailUrl"\s*:\s*\["([^"]+)"\]')
_JNAME_RE       = re.compile(r'"name"\s*:\s*"([^"]+)"')
_DURATION_RE    = re.compile(r'"duration"\s*:\s*"PT(\d+)S"')

IMPERSONATE = "chrome131"


def _normalize_url(url: str) -> str:
    url = url.strip()
    if url.startswith("http"):
        return url
    return BASE_URL + url


def _extract_comic_id(url: str) -> str | None:
    m = _COMIC_ID_RE.search(url)
    return m.group(1) if m else None


def _extract_gif_id(url: str) -> str | None:
    m = _GIF_ID_RE.search(url)
    return m.group(1) if m else None


# ──────────────────────────────────────────────
#  VIDEO (/gif/) helpers
# ──────────────────────────────────────────────

async def get_gif_info(page_url: str) -> dict | None:
    """
    Scrape a /gif/ page and return m3u8 URL + metadata from JSON-LD.
    Uses curl_cffi AsyncSession for browser-level TLS impersonation.
    """
    gif_id = _extract_gif_id(page_url)
    if not gif_id:
        return None

    canonical = _normalize_url(f"/gif/{gif_id}.html")

    try:
        async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as client:
            r = await client.get(canonical, headers=HEADERS, timeout=30)
            if r.status_code != 200:
                logger.debug("get_gif_info: status %d for %s", r.status_code, canonical)
                return None
            body = r.text
    except Exception as exc:
        logger.debug("get_gif_info: request failed for %s: %s", canonical, exc)
        return None

    m3u8_m  = _CONTENT_URL_RE.search(body)
    thumb_m = _THUMB_URL_RE.search(body)
    name_m  = _JNAME_RE.search(body)
    dur_m   = _DURATION_RE.search(body)

    if not m3u8_m:
        return None

    m3u8_url = m3u8_m.group(1)
    title    = name_m.group(1).strip() if name_m else f"Video #{gif_id}"
    thumb    = thumb_m.group(1) if thumb_m else None
    duration = int(dur_m.group(1)) if dur_m else 0

    return {
        "gif_id":    gif_id,
        "title":     title,
        "m3u8_url":  m3u8_url,
        "thumb_url": thumb,
        "duration":  duration,
        "page_url":  canonical,
    }


async def show_gif_options(m: Message, url: str) -> None:
    key           = cache_url("pgif", url)
    callback_data = f"d_pgif_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download Video", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Open on site", url=url)],
    ])

    try:
        info = await get_gif_info(url)
        if not info:
            await m.reply_text("⚠️ <b>Could not fetch video info.</b>", reply_markup=markup)
            return

        dur_str = f"{info['duration']}s" if info["duration"] else "—"
        caption = (
            f"🎬 <b>{info['title']}</b>\n"
            f"<b>Duration:</b> <code>{dur_str}</code>"
        )

        if info["thumb_url"]:
            try:
                async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as c:
                    raw = (await c.get(info["thumb_url"], headers=HEADERS, timeout=15)).content
                if raw:
                    clean = await _process_thumb_bytes(raw)
                    await m.reply_photo(photo=BytesIO(clean), caption=caption, reply_markup=markup)
                    return
            except Exception:
                pass

        await m.reply_text(caption, reply_markup=markup)

    except Exception:
        await m.reply_text("🎬 Porn-Comic Video", reply_markup=markup)


# ──────────────────────────────────────────────
#  COMIC (/h/) helpers
# ──────────────────────────────────────────────

def _fetch_page_body_sync(url: str, retries: int = 5) -> str | None:
    """
    Fetch a single page using a fresh curl_cffi request each time.
    Using per-request calls (not a shared Session) avoids connection-pool
    reuse issues where the server closes a keep-alive connection mid-scrape.
    """
    import time
    for attempt in range(retries):
        try:
            r = cffi_requests.get(
                url,
                impersonate=IMPERSONATE,
                headers=HEADERS,
                timeout=30,
                allow_redirects=True,
            )
            if r.status_code == 200:
                return r.text
            logger.warning(
                "_fetch_page_body: HTTP %d for %s (attempt %d/%d)",
                r.status_code, url, attempt + 1, retries,
            )
            if r.status_code in (429, 503):
                time.sleep(15 + attempt * 5)
            elif r.status_code == 404:
                return None  # page genuinely absent
            else:
                time.sleep(3)
        except Exception as exc:
            logger.warning(
                "_fetch_page_body attempt %d/%d exception for %s: %s",
                attempt + 1, retries, url, exc,
            )
        if attempt < retries - 1:
            time.sleep(1.5)
    return None


def _get_comic_info_sync(page_url: str) -> dict | None:
    """
    Synchronous scraper — runs in a thread pool so it never blocks the
    Pyrogram event loop and avoids all asyncio-interaction issues.

    Strategy:
      • Fetch each page independently (fresh curl_cffi request per page) to
        avoid connection-pool keep-alive drops that cause spurious failures.
      • Predict next-page URL (/h/{id}-{N}.html) so we don't depend on
        the previous page's body to keep going if one page fails.
      • A page with no `next_page_url` in its HTML doesn't truly exist
        (server returns 200 with dummy content) — treat as end-of-comic.
      • Stop after MAX_CONSEC_FAILS consecutive unreachable pages.
    """
    comic_id = _extract_comic_id(page_url)
    if not comic_id:
        return None

    title         = f"Comic #{comic_id}"
    thumbnail_url: str | None = None
    image_urls:   list[str]   = []

    MAX_PAGES        = 400
    MAX_CONSEC_FAILS = 4

    try:
        page_num    = 1
        consec_fail = 0

        while page_num <= MAX_PAGES:
            url = (
                _normalize_url(f"/h/{comic_id}.html")
                if page_num == 1
                else _normalize_url(f"/h/{comic_id}-{page_num}.html")
            )

            body = _fetch_page_body_sync(url)

            if body is None:
                consec_fail += 1
                logger.warning(
                    "comic %s page %d: fetch failed (consec=%d)",
                    comic_id, page_num, consec_fail,
                )
                if consec_fail >= MAX_CONSEC_FAILS:
                    break
                page_num += 1
                continue

            consec_fail = 0

            # Page 1: extract title + thumbnail
            if page_num == 1:
                tm = _TITLE_RE.search(body)
                if tm:
                    raw = re.sub(r'\s*\|.*$', '', tm.group(1)).strip()
                    if raw:
                        title = raw
                om = _OG_IMG_RE.search(body)
                if om:
                    thumbnail_url = om.group(1).strip()

            # Is this page real? Real pages always have next_page_url.
            next_m = _NEXT_RE.search(body)
            if not next_m:
                # Bogus page (server serves 200 with no navigation)
                break

            # Collect the image
            im = _PAGE_IMG_RE.search(body)
            if im:
                image_urls.append(im.group(1).strip())

            next_rel = next_m.group(1).strip()
            if re.match(rf'/h/{re.escape(comic_id)}(?:-\d+)?\.html$', next_rel):
                page_num += 1          # same comic → continue
            else:
                break                  # different comic → last page reached

    except Exception:
        logger.exception("_get_comic_info_sync failed for %s", page_url)
        return None

    if not image_urls:
        return None

    return {
        "comic_id":      comic_id,
        "title":         title,
        "thumbnail_url": thumbnail_url or image_urls[0],
        "image_urls":    image_urls,
        "page_count":    len(image_urls),
    }


async def get_comic_info(page_url: str) -> dict | None:
    """Async wrapper — delegates to the sync scraper via thread pool."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_comic_info_sync, page_url)


async def show_options(m: Message, url: str) -> None:
    key      = cache_url("pcomic", url)
    key_pdf  = cache_url("ppdf",   url)

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📄 Download PDF",  callback_data=f"d_ppdf_{key_pdf}"),
            InlineKeyboardButton("📦 Download CBZ",  callback_data=f"d_pcomic_{key}"),
        ],
        [InlineKeyboardButton("🌐 Open on site", url=url)],
    ])

    try:
        info = await get_comic_info(url)
        if not info:
            await m.reply_text("⚠️ <b>Could not load comic data.</b>", reply_markup=markup)
            return

        caption = (
            f"📖 <b>{info['title']}</b>\n"
            f"<b>Pages:</b> <code>{info['page_count']}</code>"
        )

        if info["thumbnail_url"]:
            try:
                async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as c:
                    raw = (await c.get(info["thumbnail_url"], headers=HEADERS, timeout=15)).content
                if raw:
                    clean = await _process_thumb_bytes(raw)
                    await m.reply_photo(photo=BytesIO(clean), caption=caption, reply_markup=markup)
                    return
            except Exception:
                pass

        await m.reply_text(caption, reply_markup=markup)

    except Exception:
        await m.reply_text("📖 Porn-Comic", reply_markup=markup)
