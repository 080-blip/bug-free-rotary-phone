import os
import glob
import asyncio
import zipfile
import subprocess
import json
import logging
from io import BytesIO

from curl_cffi import requests as cffi_requests
from PIL import Image as PILImage

from pyrogram import Client, filters
from pyrogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    InputMediaPhoto,
)
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import (
    show_options, get_comic_info, HEADERS, IMPERSONATE,
    show_gif_options, get_gif_info,
)
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, FFMPEG, _get_best_thumb, remove_file, remove_glob_files
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor

logger = logging.getLogger(__name__)

DOWNLOAD_DIR = "downloads/porncomic"
MAX_CBZ_SIZE = MAX_TG_SIZE


# ──────────────────────────────────────────────
#  Filters
# ──────────────────────────────────────────────

def _check_comic(_, __, m):
    return bool(m.text and "porn-comic.com/h/" in m.text)


def _check_gif(_, __, m):
    return bool(m.text and "porn-comic.com/gif/" in m.text)


porncomic_filter = filters.create(_check_comic, name="porncomic_filter")
porngif_filter   = filters.create(_check_gif,   name="porngif_filter")


# ──────────────────────────────────────────────
#  Message handlers → show options
# ──────────────────────────────────────────────

@Client.on_message(porncomic_filter)
async def porncomic_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


@Client.on_message(porngif_filter)
async def porngif_options(c: Client, m: Message):
    await show_gif_options(m, m.text.strip())


# ──────────────────────────────────────────────
#  Callback: download comic as CBZ
# ──────────────────────────────────────────────

@Client.on_callback_query(filters.regex(r"^d_pcomic_"), group=-1)
async def porncomic_download(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("porncomic", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching comic data...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching comic data...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("porncomic", user_id)
    clean_downloads()
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    cbz_path: str | None = None

    try:
        info = await get_comic_info(page_url)
        if not info:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ Could not fetch comic data from site.", c=c, chat_id=chat_id)
            return

        title      = info["title"]
        image_urls = info["image_urls"]
        comic_id   = info["comic_id"]
        page_count = info["page_count"]

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📖 <b>{title}</b>\n⏳ Downloading <b>{page_count}</b> pages...",
            c=c, chat_id=chat_id,
        )

        safe_title = "".join(
            ch for ch in title if ch.isalnum() or ch in " _-.()"
        ).strip()[:60] or f"comic_{comic_id}"
        cbz_path = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{comic_id}.cbz")

        downloaded = 0
        failed     = 0

        async def _dl_page(session: cffi_requests.AsyncSession, idx: int, url: str) -> tuple[int, bytes | None]:
            for attempt in range(6):
                try:
                    r = await session.get(url, headers=HEADERS, timeout=30)
                    if r.status_code == 200:
                        return idx, r.content
                    if r.status_code == 429:
                        wait = 15 + attempt * 10
                        logger.warning("image dl 429 (idx=%d attempt=%d) — waiting %ds", idx, attempt + 1, wait)
                        await asyncio.sleep(wait)
                        continue
                    if r.status_code == 404:
                        return idx, None
                    logger.warning("image dl HTTP %d (idx=%d attempt=%d)", r.status_code, idx, attempt + 1)
                    await asyncio.sleep(3)
                except Exception as exc:
                    logger.warning("image dl exception (idx=%d attempt=%d): %s", idx, attempt + 1, exc)
                    await asyncio.sleep(2)
            return idx, None

        async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as session:
            sem = asyncio.Semaphore(4)

            async def _bounded(idx, url):
                async with sem:
                    return await _dl_page(session, idx, url)

            tasks   = [_bounded(i, u) for i, u in enumerate(image_urls)]
            results = {}

            for coro in asyncio.as_completed(tasks):
                idx, data = await coro
                results[idx] = data
                downloaded += 1

                if downloaded % 5 == 0 or downloaded == page_count:
                    pct = downloaded * 100 // page_count
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"📖 <b>{title}</b>\n⏳ Downloading pages... {pct}%  ({downloaded}/{page_count})",
                        c=c, chat_id=chat_id,
                    )

        msg_ref[0] = await safe_edit(msg_ref[0], "📦 Packaging CBZ file...", c=c, chat_id=chat_id)

        with zipfile.ZipFile(cbz_path, "w", compression=zipfile.ZIP_STORED) as zf:
            for idx in sorted(results.keys()):
                data = results[idx]
                if data is None:
                    failed += 1
                    continue
                url = image_urls[idx]
                ext = url.rsplit(".", 1)[-1].split("?")[0].lower() if "." in url.rsplit("/", 1)[-1] else "webp"
                zf.writestr(f"{str(idx + 1).zfill(4)}.{ext}", data)

        cbz_size = os.path.getsize(cbz_path)
        if cbz_size > MAX_CBZ_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n<b>Size:</b> <code>{humanbytes(cbz_size)}</code>\n<i>Max: 2 GiB.</i>",
                c=c, chat_id=chat_id,
            )
            return

        ok_pages = page_count - failed
        caption  = (
            f"📖 <b>{title}</b>\n"
            f"<b>Pages:</b> <code>{ok_pages}</code>"
            + (f"  ⚠️ <i>({failed} failed)</i>" if failed else "") + "\n"
            f"<b>Size:</b> <code>{humanbytes(cbz_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• Porn-Comic •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading...</b>", c=c, chat_id=chat_id)
        await c.send_document(
            chat_id, cbz_path,
            caption=caption,
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=markup,
            file_name=os.path.basename(cbz_path),
        )

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if cbz_path and os.path.exists(cbz_path):
            try:
                os.remove(cbz_path)
            except Exception:
                pass
        remove_glob_files(f"{DOWNLOAD_DIR}/*")
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("porncomic", user_id)


# ──────────────────────────────────────────────
#  Callback: download comic pages as PDF
# ──────────────────────────────────────────────

@Client.on_callback_query(filters.regex(r"^d_ppdf_"), group=-1)
async def porncomic_pdf(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("porncomic", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching comic data...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching comic data...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("porncomic", user_id)
    clean_downloads()
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    pdf_path: str | None = None

    try:
        info = await get_comic_info(page_url)
        if not info:
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ Could not fetch comic data from site.",
                c=c, chat_id=chat_id,
            )
            return

        title      = info["title"]
        image_urls = info["image_urls"]
        comic_id   = info["comic_id"]
        page_count = info["page_count"]

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📄 <b>{title}</b>\n⏳ Downloading <b>{page_count}</b> pages...",
            c=c, chat_id=chat_id,
        )

        # ── Download all pages concurrently ──
        async def _dl_page(session: cffi_requests.AsyncSession, idx: int, img_url: str) -> tuple[int, bytes | None]:
            for attempt in range(6):
                try:
                    r = await session.get(img_url, headers=HEADERS, timeout=30)
                    if r.status_code == 200:
                        return idx, r.content
                    if r.status_code == 429:
                        wait = 15 + attempt * 10
                        logger.warning("image dl 429 (idx=%d attempt=%d) — waiting %ds", idx, attempt + 1, wait)
                        await asyncio.sleep(wait)
                        continue
                    if r.status_code == 404:
                        return idx, None
                    logger.warning("image dl HTTP %d (idx=%d attempt=%d)", r.status_code, idx, attempt + 1)
                    await asyncio.sleep(3)
                except Exception as exc:
                    logger.warning("image dl exception (idx=%d attempt=%d): %s", idx, attempt + 1, exc)
                    await asyncio.sleep(2)
            return idx, None

        results: dict[int, bytes | None] = {}
        downloaded = 0

        async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as session:
            sem = asyncio.Semaphore(4)

            async def _bounded(idx, img_url):
                async with sem:
                    return await _dl_page(session, idx, img_url)

            tasks = [_bounded(i, u) for i, u in enumerate(image_urls)]
            for coro in asyncio.as_completed(tasks):
                idx, data = await coro
                results[idx] = data
                downloaded += 1
                if downloaded % 5 == 0 or downloaded == page_count:
                    pct = downloaded * 100 // page_count
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"📄 <b>{title}</b>\n"
                        f"⏳ Downloading pages... {pct}% ({downloaded}/{page_count})",
                        c=c, chat_id=chat_id,
                    )

        # ── Convert pages to RGB PIL images (preserve original resolution) ──
        def _build_pdf(ordered_data: list[bytes], out_path: str) -> int:
            """
            Build a multi-page PDF from raw image bytes.
            Returns number of pages successfully added.
            """
            pil_pages: list[PILImage.Image] = []
            for raw in ordered_data:
                try:
                    img = PILImage.open(BytesIO(raw))
                    if img.mode not in ("RGB", "L"):
                        img = img.convert("RGB")
                    pil_pages.append(img)
                except Exception as exc:
                    logger.warning("porncomic PDF: skipping bad image: %s", exc)

            if not pil_pages:
                return 0

            pil_pages[0].save(
                out_path,
                format="PDF",
                save_all=True,
                append_images=pil_pages[1:],
            )
            return len(pil_pages)

        msg_ref[0] = await safe_edit(msg_ref[0], "📦 Building PDF...", c=c, chat_id=chat_id)

        # Collect pages in order, skip failed ones
        ordered_data: list[bytes] = []
        failed = 0
        for idx in range(page_count):
            data = results.get(idx)
            if data:
                ordered_data.append(data)
            else:
                failed += 1

        safe_title = "".join(
            ch for ch in title if ch.isalnum() or ch in " _-.()"
        ).strip()[:60] or f"comic_{comic_id}"
        pdf_path = os.path.join(os.path.abspath(DOWNLOAD_DIR), f"{safe_title}_{comic_id}.pdf")

        pages_ok = await run_in_executor(_build_pdf, ordered_data, pdf_path)

        if pages_ok == 0 or not os.path.exists(pdf_path):
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ Failed to build PDF.", c=c, chat_id=chat_id,
            )
            return

        pdf_size = os.path.getsize(pdf_path)
        if pdf_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>PDF too large:</b> <code>{humanbytes(pdf_size)}</code>",
                c=c, chat_id=chat_id,
            )
            return

        caption = (
            f"📄 <b>{title}</b>\n"
            f"<b>Pages:</b> <code>{pages_ok}</code>"
            + (f"  ⚠️ <i>({failed} failed)</i>" if failed else "") + "\n"
            f"<b>Size:</b> <code>{humanbytes(pdf_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• Porn-Comic •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading PDF...</b>", c=c, chat_id=chat_id)
        await c.send_document(
            chat_id,
            pdf_path,
            caption=caption,
            file_name=f"{safe_title}.pdf",
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=markup,
        )

    except Exception as e:
        logger.exception("porncomic PDF error")
        if msg_ref[0] is not None:
            await safe_edit(
                msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>",
                c=c, chat_id=chat_id,
            )
    finally:
        if pdf_path and os.path.exists(pdf_path):
            try:
                os.remove(pdf_path)
            except Exception:
                pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("porncomic", user_id)


# ──────────────────────────────────────────────
#  Helpers for /gif/ video download
# ──────────────────────────────────────────────

def _ffprobe_meta(path: str) -> tuple[int, int, int]:
    """Return (duration_secs, width, height) via ffprobe."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_streams", "-show_format", path],
            capture_output=True, text=True, timeout=30,
        )
        if out.returncode != 0:
            return 0, 0, 0
        meta = json.loads(out.stdout)
        w = h = 0
        for s in meta.get("streams", []):
            if s.get("codec_type") == "video":
                w = int(s.get("width", 0))
                h = int(s.get("height", 0))
                break
        dur = int(float(meta.get("format", {}).get("duration", "0")))
        return dur, w, h
    except Exception:
        return 0, 0, 0


def _ffmpeg_download_hls(m3u8_url: str, out_path: str) -> str | None:
    """
    Download an HLS stream with ffmpeg directly.
    Returns None on success, or an error string on failure.
    """
    cmd = [
        FFMPEG, "-y",
        "-headers", "Referer: https://www.porn-comic.com/\r\nUser-Agent: Mozilla/5.0 Chrome/131.0.0.0\r\n",
        "-i", m3u8_url,
        "-c", "copy",
        "-movflags", "+faststart",
        out_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode != 0:
            return result.stderr[-500:] if result.stderr else "ffmpeg failed"
        return None
    except subprocess.TimeoutExpired:
        return "Download timed out (10 min)"
    except Exception as e:
        return str(e)


# ──────────────────────────────────────────────
#  Callback: download /gif/ video
# ──────────────────────────────────────────────

@Client.on_callback_query(filters.regex(r"^d_pgif_"), group=-1)
async def porngif_download(client: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("porngif", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching video info...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await client.send_message(q.message.chat.id, "⏳ Fetching video info...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("porngif", user_id)
    clean_downloads()
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    chat_id         = q.message.chat.id
    msg_ref         = [msg]
    downloaded_file: str | None = None

    try:
        # Re-fetch page to get a fresh m3u8 URL (token may change)
        info = await get_gif_info(page_url)
        if not info:
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ Could not fetch video data from site.",
                c=client, chat_id=chat_id,
            )
            return

        title    = info["title"]
        m3u8_url = info["m3u8_url"]

        # Guard: make sure we have a real URL, not a key or junk
        if not m3u8_url or not m3u8_url.startswith("http"):
            logger.error("porncomic: bad m3u8_url=%r for page_url=%r", m3u8_url, page_url)
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ <b>Could not locate video stream URL.</b>\n"
                "The site may have changed its format. Please try again later.",
                c=client, chat_id=chat_id,
            )
            return

        safe_title = "".join(
            ch for ch in title if ch.isalnum() or ch in " _-.()"
        ).strip()[:60] or f"gif_{info['gif_id']}"
        downloaded_file = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{info['gif_id']}.mp4")

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"🎬 <b>{title}</b>\n⏳ Downloading video...",
            c=client, chat_id=chat_id,
        )

        # Download HLS with ffmpeg in a thread (non-blocking)
        err = await run_in_executor(_ffmpeg_download_hls, m3u8_url, downloaded_file)
        if err:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"❌ <b>Download failed:</b>\n<code>{err[:300]}</code>",
                c=client, chat_id=chat_id,
            )
            return

        if not os.path.exists(downloaded_file) or os.path.getsize(downloaded_file) == 0:
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ File not found after download.",
                c=client, chat_id=chat_id,
            )
            return

        file_size = os.path.getsize(downloaded_file)
        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large:</b> <code>{humanbytes(file_size)}</code>",
                c=client, chat_id=chat_id,
            )
            return

        duration, width, height = await run_in_executor(_ffprobe_meta, downloaded_file)
        thumb_path = await _get_best_thumb(downloaded_file, duration, {})

        caption = (
            f"🎬 <b>{title}</b>\n"
            f"<b>Duration:</b> <code>{duration}s</code>  "
            f"<b>Size:</b> <code>{humanbytes(file_size)}</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• Porn-Comic •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading...</b>", c=client, chat_id=chat_id)

        await client.send_video(
            chat_id,
            downloaded_file,
            thumb=thumb_path,
            width=width,
            height=height,
            duration=duration,
            supports_streaming=True,
            caption=caption,
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, client),
            reply_markup=markup,
        )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        logger.exception("porncomic gif download error")
        await safe_edit(
            msg_ref[0],
            f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>",
            c=client, chat_id=chat_id,
        )
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                remove_file(downloaded_file)
            except Exception:
                pass
        remove_glob_files(f"{DOWNLOAD_DIR}/*")
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("porngif", user_id)
