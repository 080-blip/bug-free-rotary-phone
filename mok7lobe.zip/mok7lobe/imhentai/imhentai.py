"""
imhentai.xxx plugin — Pyrogram handlers
Detects gallery URLs and downloads as CBZ or PDF.
No Cloudflare — works instantly.
"""
import os
import asyncio
import zipfile
import logging
import tempfile
from io import BytesIO

from curl_cffi import requests as cffi_requests
from PIL import Image as PILImage
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import (
    parse_url, show_gallery_options, get_gallery_info,
    get_gallery_images, IMPERSONATE, HEADERS, BASE_URL,
)
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, remove_file, remove_glob_files
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor

logger = logging.getLogger(__name__)

DOWNLOAD_DIR = "downloads/imhentai"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


def _is_gallery(_, __, m: Message) -> bool:
    return bool(m.text and re.search(r"imhentai\.xxx/gallery/\d+", m.text))


import re
imhentai_filter = filters.create(_is_gallery, name="imhentai_filter")


@Client.on_message(imhentai_filter)
async def imhentai_options(c: Client, m: Message):
    await show_gallery_options(m, m.text.strip())


async def _download_images(
    image_urls: list[str], title: str, page_count: int,
    msg_ref: list, c: Client, chat_id: int,
) -> dict[int, bytes | None]:
    async def _dl(session, idx: int, url: str):
        for attempt in range(5):
            try:
                r = await session.get(url, headers=HEADERS, timeout=30)
                if r.status_code == 200:
                    return idx, r.content
                if r.status_code == 429:
                    await asyncio.sleep(15 + attempt * 10)
                    continue
                if r.status_code == 404:
                    return idx, None
                await asyncio.sleep(3)
            except Exception as exc:
                logger.warning("imhentai img dl idx=%d attempt=%d: %s", idx, attempt + 1, exc)
                await asyncio.sleep(2)
        return idx, None

    results: dict[int, bytes | None] = {}
    downloaded = 0
    sem = asyncio.Semaphore(6)

    async with cffi_requests.AsyncSession(impersonate=IMPERSONATE) as session:
        async def _bounded(idx, url):
            async with sem:
                return await _dl(session, idx, url)

        for coro in asyncio.as_completed([_bounded(i, u) for i, u in enumerate(image_urls)]):
            idx, data = await coro
            results[idx] = data
            downloaded += 1
            if downloaded % 5 == 0 or downloaded == page_count:
                pct = downloaded * 100 // page_count
                msg_ref[0] = await safe_edit(
                    msg_ref[0],
                    f"📖 <b>{title}</b>\n⏳ صفحة {downloaded}/{page_count}  ({pct}%)",
                    c=c, chat_id=chat_id,
                )
    return results


def _build_cbz(cbz_path: str, image_urls: list[str], results: dict[int, bytes | None]) -> int:
    failed = 0
    with zipfile.ZipFile(cbz_path, "w", compression=zipfile.ZIP_STORED) as zf:
        for idx in sorted(results.keys()):
            data = results[idx]
            if data is None:
                failed += 1
                continue
            url = image_urls[idx]
            ext = url.rsplit(".", 1)[-1].split("?")[0].lower() if "." in url.rsplit("/", 1)[-1] else "jpg"
            zf.writestr(f"{str(idx + 1).zfill(4)}.{ext}", data)
    return failed


def _build_pdf(pdf_path: str, results: dict[int, bytes | None]) -> int:
    failed = 0
    pages: list = []
    first = None
    for idx in sorted(results.keys()):
        data = results[idx]
        if data is None:
            failed += 1
            continue
        try:
            img = PILImage.open(BytesIO(data)).convert("RGB")
            if first is None:
                first = img
            else:
                pages.append(img)
        except Exception:
            failed += 1
    if first:
        first.save(pdf_path, "PDF", save_all=True, append_images=pages)
    return failed


async def _do_download(
    c: Client, q: CallbackQuery, fmt: str
) -> None:
    page_url = resolve_url(q.data)
    if not page_url:
        await q.answer("⚠️ انتهت الجلسة، أعد إرسال الرابط.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("imhentai", user_id):
        await q.answer("⚠️ لديك تحميل قيد التشغيل.", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ جاري تحميل الغاليري...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ جاري تحميل الغاليري...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("imhentai", user_id)
    clean_downloads()

    chat_id  = q.message.chat.id
    msg_ref  = [msg]
    out_path = None
    sent_ok  = False

    try:
        gallery_id = parse_url(page_url)
        if not gallery_id:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ رابط غير صالح.", c=c, chat_id=chat_id)
            return

        msg_ref[0] = await safe_edit(
            msg_ref[0], "🔍 <b>جاري جلب معلومات الغاليري...</b>", c=c, chat_id=chat_id
        )
        loop = asyncio.get_event_loop()
        info = await loop.run_in_executor(None, get_gallery_info, gallery_id)
        if not info:
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ تعذّر جلب بيانات الغاليري.", c=c, chat_id=chat_id
            )
            return

        title      = info["title"]
        total      = info["total_pages"]

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"🖼️ <b>{title}</b>\n📊 {total} صفحة\n⏳ جاري بناء روابط الصور...",
            c=c, chat_id=chat_id,
        )

        image_urls = await loop.run_in_executor(None, get_gallery_images, info)
        if not image_urls:
            msg_ref[0] = await safe_edit(
                msg_ref[0], "❌ تعذّر جلب الصور.", c=c, chat_id=chat_id
            )
            return

        results = await _download_images(image_urls, title, len(image_urls), msg_ref, c, chat_id)

        safe_title = "".join(ch for ch in title if ch.isalnum() or ch in " _-()")[:50] or "gallery"

        if fmt == "cbz":
            msg_ref[0] = await safe_edit(msg_ref[0], "📦 جاري تجميع CBZ...", c=c, chat_id=chat_id)
            out_path = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{gallery_id}.cbz")
            failed   = await run_in_executor(_build_cbz, out_path, image_urls, results)
        else:
            msg_ref[0] = await safe_edit(msg_ref[0], "📄 جاري إنشاء PDF...", c=c, chat_id=chat_id)
            out_path = os.path.join(DOWNLOAD_DIR, f"{safe_title}_{gallery_id}.pdf")
            failed   = await run_in_executor(_build_pdf, out_path, results)

        out_size = os.path.getsize(out_path)
        if out_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0], f"⚠️ الملف كبير جداً: <code>{humanbytes(out_size)}</code>",
                c=c, chat_id=chat_id,
            )
            return

        ok = len(image_urls) - failed
        ext_label = "CBZ" if fmt == "cbz" else "PDF"
        caption = (
            f"🖼️ <b>{title}</b>\n"
            f"<b>الصفحات:</b> <code>{ok}</code>"
            + (f"  ⚠️ <i>({failed} فشلت)</i>" if failed else "") + "\n"
            f"<b>الحجم:</b> <code>{humanbytes(out_size)}</code>\n"
            f"<b>المصدر:</b> IMHentai"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("• IMHentai •", url=page_url)]])

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>جاري الرفع...</b>", c=c, chat_id=chat_id)
        await c.send_document(
            chat_id, out_path,
            caption=caption,
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=markup,
            file_name=os.path.basename(out_path),
        )
        sent_ok = True

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>خطأ:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if out_path and os.path.exists(out_path):
            remove_file(out_path)
        remove_glob_files(f"{DOWNLOAD_DIR}/*")
        clean_downloads()
        if sent_ok:
            try:
                await msg_ref[0].delete()
            except Exception:
                pass
        dl_state.remove_active("imhentai", user_id)


@Client.on_callback_query(filters.regex(r"^d_imh_cbz_"), group=-1)
async def imh_cbz(c: Client, q: CallbackQuery):
    await _do_download(c, q, "cbz")


@Client.on_callback_query(filters.regex(r"^d_imh_pdf_"), group=-1)
async def imh_pdf(c: Client, q: CallbackQuery):
    await _do_download(c, q, "pdf")
