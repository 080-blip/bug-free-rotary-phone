"""
imhentai.xxx — gallery image extractor
No Cloudflare, works with direct HTTP requests.

URL format:
  https://imhentai.xxx/gallery/{id}/

Image URL format:
  https://m{server}.imhentai.xxx/{folder}/{hash}/{page}.jpg
"""
import re
import logging
from urllib.parse import urlparse

from curl_cffi import requests as cffi_requests
from bs4 import BeautifulSoup
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.url_cache import cache_url

logger = logging.getLogger(__name__)

BASE_URL  = "https://imhentai.xxx"
IMPERSONATE = "chrome131"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": BASE_URL + "/",
}

_GALLERY_RE = re.compile(r"imhentai\.xxx/gallery/(\d+)/?", re.I)

# CDN fallback list — cover server is tried first, these are used only if it fails
_CDN_SERVERS = ["m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8", "m9", "m10", "m11", "m12", "m13", "m14", "m15"]


def parse_url(url: str) -> str | None:
    """Return gallery ID or None."""
    m = _GALLERY_RE.search(url)
    return m.group(1) if m else None


def _get(url: str, **kw) -> cffi_requests.Response:
    return cffi_requests.get(url, headers=HEADERS, impersonate=IMPERSONATE, timeout=15, **kw)


def _head(url: str, **kw) -> cffi_requests.Response:
    return cffi_requests.head(url, headers=HEADERS, impersonate=IMPERSONATE, timeout=8, **kw)


def _probe_server_and_ext(folder: str, img_hash: str, cover_server: str = "") -> tuple[str, str] | None:
    """
    Find which CDN server actually hosts this gallery AND which
    extension (jpg/png/webp/avif) page 1 uses.
    Tries the cover_server first, then falls back to _CDN_SERVERS.
    Returns (server_base, ext) or None if not found.
    """
    # Build probe order: cover server first, then the standard list (deduped)
    candidates = []
    if cover_server:
        candidates.append(cover_server)
    # Extract server label from cover_server URL (e.g. "m11") to skip duplicate
    cover_label = cover_server.replace("https://", "").split(".")[0] if cover_server else ""
    for s in _CDN_SERVERS:
        if s != cover_label:
            candidates.append(f"https://{s}.imhentai.xxx")

    for base in candidates:
        for ext in ("jpg", "png", "webp", "avif"):
            try:
                r = _head(f"{base}/{folder}/{img_hash}/1.{ext}")
                if r.status_code == 200:
                    logger.info("imhentai: found server=%s ext=%s", base, ext)
                    return base, ext
            except Exception:
                pass
    return None


def get_gallery_info(gallery_id: str) -> dict | None:
    """
    Fetch gallery page and extract:
      title, cover_url, total_pages, image_base_url
    """
    try:
        r = _get(f"{BASE_URL}/gallery/{gallery_id}/")
        if r.status_code != 200:
            logger.warning("imhentai gallery %s: HTTP %d", gallery_id, r.status_code)
            return None

        soup = BeautifulSoup(r.text, "html.parser")

        # ── Title ──
        title_tag = soup.find("h1") or soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else f"Gallery {gallery_id}"
        title = re.sub(r"\s*-\s*IMHentai\s*$", "", title, flags=re.I).strip()

        # ── Cover URL → extract server, folder, hash ──
        cover_url = ""
        for img in soup.find_all("img"):
            src = img.get("data-src") or img.get("src") or ""
            if "imhentai.xxx" in src and ("cover" in src or "thumb" in src):
                cover_url = src
                break

        # Fallback: any imhentai.xxx image in the page
        if not cover_url:
            for m in re.finditer(r"https://m\d+\.imhentai\.xxx/[^\s\"'<>]+", r.text):
                cover_url = m.group(0)
                break

        if not cover_url:
            logger.warning("imhentai %s: cover URL not found", gallery_id)
            return None

        # cover URL: https://m1.imhentai.xxx/001/8b7a63vwdj/cover.jpg
        # or:        https://m3.imhentai.xxx/033/xyzabc123/1t.jpg
        m = re.search(
            r"https://m\d+\.imhentai\.xxx/(\d+)/([a-z0-9]+)/",
            cover_url,
        )
        if not m:
            logger.warning("imhentai %s: can't parse cover URL: %s", gallery_id, cover_url)
            return None

        folder   = m.group(1)   # e.g. 001
        img_hash = m.group(2)   # e.g. 8b7a63vwdj

        # ── Total pages ──
        total_pages = 0
        for pat in [
            r'class="pages">\s*Pages:\s*(\d+)',
            r'id="load_pages"\s+value="(\d+)"',
            r'name="load_pages"[^>]+value="(\d+)"',
            r'"num_pages"\s*:\s*(\d+)',
            r'data-pages="(\d+)"',
            r'Pages:\s*(\d+)',
            r'(\d+)\s+pages',
        ]:
            pages_m = re.search(pat, r.text, re.I)
            if pages_m:
                total_pages = int(pages_m.group(1))
                break

        if not total_pages:
            logger.warning("imhentai %s: can't find total pages in HTML", gallery_id)
            return None

        # Extract the server base URL from cover for later probing
        cover_server_base = re.search(r"(https://m\d+\.imhentai\.xxx)", cover_url)
        cover_server = cover_server_base.group(1) if cover_server_base else ""

        return {
            "id":           gallery_id,
            "title":        title,
            "cover_url":    cover_url,
            "cover_server": cover_server,
            "folder":       folder,
            "hash":         img_hash,
            "total_pages":  total_pages,
            "url":          f"{BASE_URL}/gallery/{gallery_id}/",
        }

    except Exception as exc:
        logger.warning("imhentai get_gallery_info %s: %s", gallery_id, exc)
        return None


def get_gallery_images(info: dict) -> list[str]:
    """
    Build all image URLs from gallery info.
    Tries the cover server first, then falls back through the CDN list.
    """
    folder       = info["folder"]
    h            = info["hash"]
    total        = info["total_pages"]
    cover_server = info.get("cover_server", "")

    found = _probe_server_and_ext(folder, h, cover_server)
    if not found:
        logger.warning("imhentai %s: could not find working server/ext", info["id"])
        return []

    server, ext = found
    return [f"{server}/{folder}/{h}/{i}.{ext}" for i in range(1, total + 1)]


async def show_gallery_options(m: Message, url: str) -> None:
    gallery_id = parse_url(url)
    if not gallery_id:
        await m.reply_text("❌ الرابط غير صالح — تأكد أنه رابط gallery من imhentai.xxx")
        return

    key_cbz = cache_url("imh_cbz", url)
    key_pdf = cache_url("imh_pdf", url)

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📦 CBZ", callback_data=f"d_imh_cbz_{key_cbz}"),
            InlineKeyboardButton("📄 PDF", callback_data=f"d_imh_pdf_{key_pdf}"),
        ],
        [InlineKeyboardButton("🌐 Open Gallery", url=url)],
    ])
    await m.reply_text(
        f"🖼️ <b>IMHentai</b>\n<code>{url}</code>\n\nاختر صيغة التحميل:",
        reply_markup=markup,
    )
