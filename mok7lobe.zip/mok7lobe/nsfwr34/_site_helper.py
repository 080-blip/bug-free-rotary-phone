"""
NSFWR34 — improved scraper with WordPress REST API support.

URL formats supported:
  • Canonical slug  : https://nsfwr34.com/video/some-video-slug/
  • WP short link   : https://nsfwr34.com/?p=53530

Strategy:
  1. Extract post ID from URL (?p=ID) if present, else from page HTML.
  2. Use WordPress REST API to get clean title and metadata.
  3. Parse data-settings JSON for direct CDN video sources.
  4. Select best quality MP4 source.
  5. Cache CDN URL under a short 8-char key for the download button.
"""
import re
import json
import hashlib
import html as _html
from io import BytesIO
from urllib.parse import urlparse, parse_qs

from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

import httpx

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.downloader import _process_thumb_bytes

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)
_PAGE_HEADERS = {
    "User-Agent": _UA,
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


async def _fetch_page(url: str) -> str | None:
    """Fetch a page with browser-like headers (no PornHub Referer)."""
    try:
        async with httpx.AsyncClient(
            timeout=15, follow_redirects=True, headers=_PAGE_HEADERS
        ) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                return resp.text
    except Exception:
        pass
    return None

_SETTINGS_RE  = re.compile(r'data-settings="([^"]+)"')
_JSONLD_RE    = re.compile(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>', re.S)
_POSTID_RE    = re.compile(r'(?:postid|post-id)-(\d+)')
_SHORTLINK_RE = re.compile(r'<link[^>]+rel=["\']shortlink["\'][^>]+href=["\']([^"\']+)["\']', re.I)
_CANONICAL_RE = re.compile(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']', re.I)

# In-memory caches
_url_cache:  dict[str, str]  = {}   # 8-char key → CDN URL
_page_cache: dict[str, str]  = {}   # 8-char key → page URL
_info_cache: dict[str, dict] = {}   # 8-char key → {title, post_id}


def _make_key(cdn_url: str) -> str:
    return hashlib.md5(cdn_url.encode()).hexdigest()[:8]


def cache_url(cdn_url: str, page_url: str = "", title: str = "", post_id: str = "") -> str:
    key = _make_key(cdn_url)
    _url_cache[key]  = cdn_url
    _page_cache[key] = page_url
    _info_cache[key] = {"title": title, "post_id": post_id}
    return key


def get_cached_url(key: str) -> str | None:
    return _url_cache.get(key)


def get_page_url(key: str) -> str:
    return _page_cache.get(key, "https://nsfwr34.com")


def get_video_meta(key: str) -> dict:
    return _info_cache.get(key, {})


def _extract_post_id(url: str) -> str | None:
    """Extract WordPress post ID from ?p=ID in any URL."""
    try:
        qs = parse_qs(urlparse(url).query)
        return qs["p"][0] if "p" in qs else None
    except Exception:
        return None


def _clean_html(text: str) -> str:
    return _html.unescape(re.sub(r"<[^>]+>", "", text)).strip()


def _parse_settings(html: str) -> dict | None:
    m = _SETTINGS_RE.search(html)
    if not m:
        return None
    try:
        return json.loads(_html.unescape(m.group(1)))
    except Exception:
        return None


def _get_jsonld_video(html: str) -> dict:
    for block in _JSONLD_RE.findall(html):
        try:
            d = json.loads(block)
            if d.get("@type") == "VideoObject":
                return d
        except Exception:
            pass
    return {}


def _best_source(sources: list) -> str | None:
    """Return the best MP4 source URL (last entry is usually highest quality)."""
    if not sources:
        return None
    mp4 = [s for s in sources if ".mp4" in s.get("src", "").lower()]
    candidates = mp4 or sources
    src = candidates[-1].get("src") if candidates else None
    if not src or not src.startswith("http"):
        return None
    return src


async def _fetch_wp_api(post_id: str) -> dict:
    """Fetch post metadata via WordPress REST API, trying multiple post types."""
    for post_type in ("video", "posts", "post"):
        try:
            api_url = f"https://nsfwr34.com/wp-json/wp/v2/{post_type}/{post_id}"
            async with httpx.AsyncClient(
                timeout=10, follow_redirects=True, headers=_PAGE_HEADERS
            ) as client:
                resp = await client.get(api_url)
                if resp.status_code != 200:
                    continue
                post = resp.json()
            title = _clean_html(post.get("title", {}).get("rendered", "") or "")
            link  = post.get("link", "")
            if title or link:
                return {"title": title, "link": link}
        except Exception:
            continue
    return {}


async def scrape(url: str) -> dict | None:
    """
    Scrape video info from any nsfwr34.com URL.
    Supports /?p=ID short links and /video/slug/ canonical URLs.
    """
    post_id = _extract_post_id(url)

    # Fetch page HTML with browser-like headers (shared client uses PornHub Referer which is blocked)
    page_html = await _fetch_page(url)
    if not page_html:
        return None

    # Extract post ID from HTML if not found in URL
    if not post_id:
        m = _POSTID_RE.search(page_html)
        if m:
            post_id = m.group(1)

    if not post_id:
        m = _SHORTLINK_RE.search(page_html)
        if m:
            post_id = _extract_post_id(m.group(1))

    # Extract canonical page URL
    canonical_url = url
    m = _CANONICAL_RE.search(page_html)
    if m:
        canonical_url = m.group(1)

    # Parse video player data
    settings  = _parse_settings(page_html)
    ld        = _get_jsonld_video(page_html)
    sources   = (settings or {}).get("sources", [])
    video_url = _best_source(sources)

    if not video_url:
        return None

    # Thumbnail: prefer player poster, fallback to JSON-LD
    poster = (settings or {}).get("poster") or next(
        iter(ld.get("thumbnailUrl") or []), None
    )

    # Title: prefer WP REST API (clean), fallback to JSON-LD
    title = ""
    if post_id:
        api_data = await _fetch_wp_api(post_id)
        title = api_data.get("title", "")
        if not canonical_url and api_data.get("link"):
            canonical_url = api_data["link"]

    if not title:
        title = _clean_html(ld.get("name", "")) or "NSFWR34 Video"

    return {
        "title":     title,
        "thumbnail": poster,
        "video_url": video_url,
        "post_id":   post_id or "",
        "page_url":  canonical_url,
    }


async def extract_info(url: str) -> dict | None:
    """
    Return standardised info dict or None if extraction fails.
    download_url = direct CDN mp4 URL extracted from page.
    """
    try:
        info = await scrape(url)
    except Exception:
        return None
    if not info:
        return None
    return {
        "download_url": info["video_url"],
        "page_url":     info.get("page_url", url),
        "title":        info.get("title", ""),
        "thumbnail":    info.get("thumbnail"),
        "duration":     0,
        "post_id":      info.get("post_id", ""),
        "source":       "scraper",
    }


async def show_options(m: Message, url: str) -> None:
    info = None
    try:
        info = await scrape(url)
    except Exception:
        pass

    if info:
        key          = cache_url(
            info["video_url"],
            page_url=info.get("page_url", url),
            title=info.get("title", ""),
            post_id=info.get("post_id", ""),
        )
        callback_key = f"d_R34_{key}"
    else:
        callback_key = "d_nsfwr34_unavail"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_key)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    if not info:
        await m.reply_text("🎬 NSFWR34 video", reply_markup=markup)
        return

    post_id = info.get("post_id", "")
    lines   = [f"🎬 <b>{info['title']}</b>"]
    if post_id:
        lines.append(f"🔖 <b>ID:</b> <code>{post_id}</code>")
    caption = "\n".join(lines)

    thumb_url = info.get("thumbnail")
    if thumb_url:
        _tmp = None
        try:
            import os as _os
            from urllib.parse import urlparse, urlunparse, quote as _quote
            _parsed = urlparse(str(thumb_url))
            _safe_url = urlunparse(_parsed._replace(path=_quote(_parsed.path, safe="/")))
            hdrs = {**_PAGE_HEADERS, "Referer": url}
            async with httpx.AsyncClient(
                timeout=15, follow_redirects=True, headers=hdrs
            ) as client:
                resp = await client.get(_safe_url)
                raw_bytes = resp.content if resp.status_code == 200 else b""
            if raw_bytes and len(raw_bytes) > 1024:
                clean = await _process_thumb_bytes(raw_bytes)
                _tmp = f"downloads/_r34sh_prev_{id(raw_bytes) & 0xFFFFFF}.jpg"
                with open(_tmp, "wb") as _f:
                    _f.write(clean)
                await m.reply_photo(photo=_tmp, caption=caption, reply_markup=markup)
                return
        except BaseException:
            pass
        finally:
            if _tmp:
                try:
                    import os as _os2; _os2.remove(_tmp)
                except Exception:
                    pass

    await m.reply_text(caption, reply_markup=markup)
