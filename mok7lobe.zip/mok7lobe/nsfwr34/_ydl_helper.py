"""
NSFWR34 — yt-dlp based extractor (BunnyCDN iframe support).

Strategy:
  1. Use yt-dlp generic extractor → BunnyCdn extractor to get video URL.
  2. Fallback to JSON-LD on the page for title/thumbnail if yt-dlp lacks them.
  3. Cache the PAGE URL under a short key; download handler passes it to yt-dlp.
"""
import asyncio
import hashlib
import re
import json
import html as _html
from io import BytesIO

import yt_dlp as youtube_dl
from yt_dlp.utils import UnsupportedError, DownloadError

from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.downloader import _process_thumb_bytes
from PornHub.plugins.function import run_in_executor

_JSONLD_RE = re.compile(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>', re.S)

_url_store: dict[str, str] = {}


class _Silent:
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


_YDL_OPTS = {
    "logger":            _Silent(),
    "quiet":             True,
    "no_warnings":       True,
    "skip_download":     True,
    "socket_timeout":    25,
    "extractor_retries": 3,
}


def _make_key(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()[:8]


def cache_url(page_url: str) -> str:
    key = _make_key(page_url)
    _url_store[key] = page_url
    return key


def get_cached_url(key: str) -> str | None:
    return _url_store.get(key)


def _fmt_duration(seconds) -> str:
    try:
        s = int(seconds)
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        return f"{h}:{m:02d}:{sec:02d}" if h else f"{m}:{sec:02d}"
    except Exception:
        return ""


def _parse_iso_duration(dur: str) -> int:
    try:
        m = re.match(r'P.*?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', dur or "")
        if m:
            return int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + int(m.group(3) or 0)
    except Exception:
        pass
    return 0


def _get_jsonld(html: str) -> dict:
    for block in _JSONLD_RE.findall(html):
        try:
            d = json.loads(block)
            if d.get("@type") == "VideoObject":
                return d
        except Exception:
            pass
    return {}


async def _extract_ydl(url: str) -> dict | None:
    def _run():
        with youtube_dl.YoutubeDL(_YDL_OPTS) as ydl:
            return ydl.extract_info(url, download=False)
    try:
        return await asyncio.wait_for(run_in_executor(_run), timeout=40)
    except (UnsupportedError, DownloadError):
        return None
    except Exception:
        return None


async def extract_info(url: str) -> dict | None:
    """
    Return standardised info dict or None if extraction fails.
    download_url = page URL (yt-dlp handles BunnyCDN internally).
    """
    info      = await _extract_ydl(url)
    title     = ""
    duration  = 0
    thumb_url = None

    if info:
        title     = info.get("title") or ""
        duration  = int(info.get("duration") or 0)
        thumb_url = info.get("thumbnail") or (info.get("thumbnails") or [{}])[-1].get("url")

    if not title or not thumb_url:
        import httpx as _httpx
        _page_hdrs = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,*/*;q=0.8",
        }
        try:
            async with _httpx.AsyncClient(timeout=15, follow_redirects=True, headers=_page_hdrs) as _c:
                _resp = await _c.get(url)
                if _resp.status_code == 200:
                    ld = _get_jsonld(_resp.text)
                    if not title:
                        title = _html.unescape(re.sub(r"<[^>]+>", "", ld.get("name", ""))).strip()
                    if not duration:
                        duration = _parse_iso_duration(ld.get("duration", ""))
                    if not thumb_url:
                        thumbs = ld.get("thumbnailUrl") or []
                        thumb_url = thumbs[-1] if thumbs else None
        except Exception:
            pass

    if not title and not thumb_url:
        return None

    return {
        "download_url": url,
        "page_url":     url,
        "title":        title or "NSFWR34 Video",
        "thumbnail":    thumb_url,
        "duration":     duration,
        "post_id":      "",
        "source":       "ydl",
    }


async def show_options(m: Message, url: str) -> None:
    key          = cache_url(url)
    callback_key = f"d_R34_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_key)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    info      = await _extract_ydl(url)
    title     = ""
    duration  = 0
    thumb_url = None

    if info:
        title     = info.get("title") or ""
        duration  = int(info.get("duration") or 0)
        thumb_url = info.get("thumbnail") or (info.get("thumbnails") or [{}])[-1].get("url")

    if not title or not thumb_url:
        import httpx as _httpx
        _page_hdrs = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,*/*;q=0.8",
        }
        try:
            async with _httpx.AsyncClient(timeout=15, follow_redirects=True, headers=_page_hdrs) as _c:
                _resp = await _c.get(url)
                if _resp.status_code == 200:
                    ld = _get_jsonld(_resp.text)
                    if not title:
                        title = _html.unescape(re.sub(r"<[^>]+>", "", ld.get("name", ""))).strip()
                    if not duration:
                        duration = _parse_iso_duration(ld.get("duration", ""))
                    if not thumb_url:
                        thumbs = ld.get("thumbnailUrl") or []
                        thumb_url = thumbs[-1] if thumbs else None
        except Exception:
            pass

    title = title or "NSFWR34 Video"

    caption = f"🎬 <b>{title}</b>"
    if duration:
        caption += f"\n⏱ <b>Duration:</b> <code>{_fmt_duration(duration)}</code>"

    if thumb_url:
        _tmp = None
        try:
            import os as _os, httpx as _httpx
            from urllib.parse import urlparse, urlunparse, quote as _quote
            _parsed = urlparse(str(thumb_url))
            _safe_url = urlunparse(_parsed._replace(path=_quote(_parsed.path, safe="/")))
            _hdrs = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
                "Referer": url,
            }
            async with _httpx.AsyncClient(timeout=15, follow_redirects=True, headers=_hdrs) as _c:
                _resp = await _c.get(_safe_url)
                raw_bytes = _resp.content if _resp.status_code == 200 else b""
            if raw_bytes and len(raw_bytes) > 1024:
                clean = await _process_thumb_bytes(raw_bytes)
                _tmp = f"downloads/_r34ydl_prev_{id(raw_bytes) & 0xFFFFFF}.jpg"
                with open(_tmp, "wb") as _f:
                    _f.write(clean)
                await m.reply_photo(photo=_tmp, caption=caption, reply_markup=markup)
                return
        except BaseException:
            pass
        finally:
            if _tmp:
                try:
                    import os as _os2; _os2.remove(_tmp)
                except Exception:
                    pass

    await m.reply_text(caption, reply_markup=markup)
