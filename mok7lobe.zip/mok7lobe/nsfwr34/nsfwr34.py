import os
import re
import glob
import asyncio
import hashlib
from io import BytesIO

import yt_dlp as youtube_dl
from yt_dlp.utils import DownloadError

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import extract_info as scraper_extract
from ._ydl_helper  import extract_info as ydl_extract

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.downloader import _get_best_thumb, _process_thumb_bytes, FFMPEG, clean_downloads, safe_edit, remove_file
from PornHub.plugins import dl_state
from PornHub.plugins.function import (
    download_progress_hook, upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor
)

# Unified cache: 8-char key → full info dict
_cache: dict[str, dict] = {}


class _Silent:
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


def _make_key(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()[:8]


def _check(_, __, m):
    return bool(m.text and "nsfwr34.com" in m.text)


nsfwr34_filter = filters.create(_check, name="nsfwr34_filter")


async def _race_extract(url: str) -> dict | None:
    """
    Run both extractors in parallel.
    Return the first successful result and cancel the other.
    """
    loop = asyncio.get_event_loop()

    task_scraper = loop.create_task(scraper_extract(url))
    task_ydl     = loop.create_task(ydl_extract(url))

    pending = {task_scraper, task_ydl}

    result = None
    while pending:
        done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            try:
                res = task.result()
            except Exception:
                res = None
            if res:
                # Cancel remaining tasks
                for t in pending:
                    t.cancel()
                return res
            # This task failed, continue waiting for the other

    return None


@Client.on_message(nsfwr34_filter)
async def nsfwr34_options(c: Client, m: Message):
    url  = m.text.strip()
    info = await _race_extract(url)

    if not info:
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🌐 Watch on web", url=url)],
        ])
        await m.reply_text("🎬 NSFWR34 video\n\n⚠️ Could not extract video info.", reply_markup=markup)
        return

    # Store full info in unified cache
    key          = _make_key(info["download_url"])
    _cache[key]  = info
    callback_key = f"d_R34_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_key)],
        [InlineKeyboardButton("🌐 Watch on web", url=info["page_url"])],
    ])

    title    = info.get("title", "NSFWR34 Video")
    duration = info.get("duration", 0)
    caption  = f"🎬 <b>{title}</b>"
    if duration:
        h, rem = divmod(int(duration), 3600)
        mi, s  = divmod(rem, 60)
        dur_str = f"{h}:{mi:02d}:{s:02d}" if h else f"{mi}:{s:02d}"
        caption += f"\n⏱ <b>Duration:</b> <code>{dur_str}</code>"

    thumb_url = info.get("thumbnail")
    if thumb_url:
        _tmp_thumb = None
        try:
            import httpx as _httpx
            from urllib.parse import urlparse, urlunparse, quote as _quote
            _parsed = urlparse(str(thumb_url))
            _safe_url = urlunparse(_parsed._replace(path=_quote(_parsed.path, safe="/")))
            _hdrs = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
                "Referer": info.get("page_url", "https://nsfwr34.com/"),
            }
            async with _httpx.AsyncClient(timeout=15, follow_redirects=True, headers=_hdrs) as _c:
                _resp = await _c.get(_safe_url)
                raw_bytes = _resp.content if _resp.status_code == 200 else b""
            if raw_bytes and len(raw_bytes) > 1024:
                clean = await _process_thumb_bytes(raw_bytes)
                _tmp_thumb = f"downloads/_r34_prev_{id(raw_bytes) & 0xFFFFFF}.jpg"
                with open(_tmp_thumb, "wb") as _f:
                    _f.write(clean)
                await m.reply_photo(photo=_tmp_thumb, caption=caption, reply_markup=markup)
                return
        except BaseException:
            pass
        finally:
            if _tmp_thumb:
                try:
                    os.remove(_tmp_thumb)
                except Exception:
                    pass

    await m.reply_text(caption, reply_markup=markup)


@Client.on_callback_query(filters.regex("^d_R34_"), group=-1)
async def nsfwr34_download(c: Client, q: CallbackQuery):
    key    = q.data[len("d_R34_"):]
    cached = _cache.get(key)

    if not cached:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    url       = cached["download_url"]
    vid_title = cached.get("title", "") or ""
    vid_id    = cached.get("post_id", "") or ""

    user_id = q.from_user.id
    if dl_state.is_active("nsfwr34", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Preparing download...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Preparing download...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("nsfwr34", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    ydl_opts = {
        "outtmpl":                       "downloads/nsfwr34/%(title)s [%(id)s].%(ext)s",
        "format":                        "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "merge_output_format":           "mp4",
        "progress_hooks":                [lambda d: download_progress_hook(d, msg_ref, c, chat_id)],
        "noplaylist":                    True,
        "retries":                       10,
        "fragment_retries":              10,
        "skip_unavailable_fragments":    True,
        "socket_timeout":                30,
        "http_chunk_size":               10485760,
        "concurrent_fragment_downloads": 8,
        "buffersize":                    1024 * 16,
        "noprogress":                    True,
        "quiet":                         True,
        "no_warnings":                   True,
        "ignoreerrors":                  False,
        "logger":                        _Silent(),
        "ffmpeg_location":               FFMPEG,
        "writethumbnail":                True,
        "postprocessors":                [{"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}],
    }

    downloaded_file = None
    try:
        def _do_download():
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(url)

        try:
            info = await run_in_executor(_do_download)
        except DownloadError as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Download failed:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return
        except Exception as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return

        if not info:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ Could not extract video info.", c=c, chat_id=chat_id)
            return

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            fname = ydl.prepare_filename(info)
        base, _ = os.path.splitext(fname)
        for ext in [".mp4", ".mkv", ".webm"]:
            if os.path.exists(base + ext):
                downloaded_file = base + ext
                break

        if not downloaded_file:
            for ext in (".mp4", ".mkv", ".webm"):
                matches = glob.glob(f"downloads/nsfwr34/*{ext}")
                if matches:
                    downloaded_file = max(matches, key=os.path.getmtime)
                    break

        if not downloaded_file or not os.path.exists(downloaded_file):
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ File not found after download.", c=c, chat_id=chat_id)
            return

        file_size = os.path.getsize(downloaded_file)
        file_name = os.path.basename(downloaded_file)

        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n\n"
                f"<b>File:</b> <code>{file_name}</code>\n"
                f"<b>Size:</b> <code>{humanbytes(file_size)}</code>\n"
                f"<i>Maximum allowed: 2 GiB.</i>",
                c=c, chat_id=chat_id,
            )
            return

        width    = info.get("width")  or 1280
        height   = info.get("height") or 720
        duration = int(info.get("duration") or 0)

        thumb_path = await _get_best_thumb(downloaded_file, duration, info)

        # Use cached title/post_id from _site_helper or _ydl_helper
        # Only fall back to filename parsing if both are missing
        if not vid_title and not vid_id:
            _match    = re.match(r"^(.*?)\s*\[([^\]]+)\]\..*$", file_name)
            vid_title = _match.group(1).strip() if _match else file_name
            vid_id    = _match.group(2).strip() if _match else ""

        msg_ref[0] = await safe_edit(
            msg_ref[0],
            f"📤 <b>Uploading...</b>\n<code>{vid_title}</code>",
            c=c, chat_id=chat_id,
        )
        await c.send_video(
            chat_id,
            downloaded_file,
            thumb=thumb_path,
            width=width,
            height=height,
            duration=duration,
            supports_streaming=True,
            caption=(
                f"<b>Name:</b> <code>{vid_title}</code>\n"
                + (f"<b>ID:</b>   <code>{vid_id}</code>\n" if vid_id else "")
                + f"<b>Size:</b>  <code>{humanbytes(file_size)}</code>"
            ),
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("• NSFWR34 •", url=url),
            ]]),
        )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                remove_file(downloaded_file)
            except Exception:
                pass
        if downloaded_file:
            base = os.path.splitext(downloaded_file)[0]
            for ext in (".jpg", ".jpeg", ".webp", ".png", "_thumb.jpg"):
                leftover = base + ext
                if os.path.exists(leftover):
                    try:
                        os.remove(leftover)
                    except Exception:
                        pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("nsfwr34", user_id)
