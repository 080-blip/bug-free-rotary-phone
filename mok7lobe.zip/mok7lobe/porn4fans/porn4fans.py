import os
import re
import glob
import asyncio

import httpx
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import show_options, get_p4f_video_url
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, _get_best_thumb, prepare_video_meta, remove_file
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


def _check(_, __, m):
    return bool(m.text and "porn4fans.com/" in m.text)


porn4fans_filter = filters.create(_check, name="porn4fans_filter")


@Client.on_message(porn4fans_filter)
async def porn4fans_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


@Client.on_callback_query(filters.regex(r"^d_p4f_"), group=-1)
async def porn4fans_download(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("p4fans", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching fresh video URL from Porn4Fans...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching fresh video URL from Porn4Fans...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("p4fans", user_id)
    clean_downloads()

    chat_id  = q.message.chat.id
    msg_ref  = [msg]

    video_url = await get_p4f_video_url(page_url)
    if not video_url:
        msg_ref[0] = await safe_edit(
            msg_ref[0],
            "❌ Could not extract video URL from Porn4Fans.\n"
            "The page may have changed or the video was removed.",
            c=c, chat_id=chat_id,
        )
        dl_state.remove_active("p4fans", user_id)
        return

    os.makedirs("downloads/p4fans", exist_ok=True)
    downloaded_file = None

    try:
        msg_ref[0] = await safe_edit(msg_ref[0], "⏳ Downloading...", c=c, chat_id=chat_id)

        fname = "downloads/p4fans/porn4fans_video.mp4"
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30, read=300),
            follow_redirects=True,
            headers={"User-Agent": UA, "Referer": page_url},
        ) as client:
            async with client.stream("GET", video_url) as r:
                if r.status_code != 200:
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"❌ Download failed (HTTP {r.status_code}).",
                        c=c, chat_id=chat_id,
                    )
                    return
                total = int(r.headers.get("content-length", 0))
                downloaded = 0
                with open(fname, "wb") as f:
                    async for chunk in r.aiter_bytes(65536):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total and downloaded % (1024 * 1024 * 5) < 65536:
                            pct = downloaded * 100 // total
                            msg_ref[0] = await safe_edit(
                                msg_ref[0],
                                f"⏳ Downloading... {pct}%  ({humanbytes(downloaded)} / {humanbytes(total)})",
                                c=c, chat_id=chat_id,
                            )

        downloaded_file = fname
        file_size = os.path.getsize(downloaded_file)

        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n<b>Size:</b> <code>{humanbytes(file_size)}</code>\n"
                "<i>Maximum allowed: 2 GiB.</i>",
                c=c, chat_id=chat_id,
            )
            return

        duration, width, height = await prepare_video_meta(downloaded_file)
        thumb_path = await _get_best_thumb(downloaded_file, duration, {})
        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading...</b>", c=c, chat_id=chat_id)

        await c.send_video(
            chat_id,
            downloaded_file,
            thumb=thumb_path,
            width=width, height=height, duration=duration,
            supports_streaming=True,
            caption=(
                f"<b>Source:</b> Porn4Fans\n"
                f"<b>Size:</b>  <code>{humanbytes(file_size)}</code>"
            ),
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("• Porn4Fans •", url=page_url),
            ]]),
        )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>",
                        c=c, chat_id=chat_id)
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                remove_file(downloaded_file)
            except Exception:
                pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("p4fans", user_id)
