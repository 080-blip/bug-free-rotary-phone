"""
Porn4Fans — HTML scraper.
The get_file URLs require a fresh v-acctoken from the page; we store
the page URL in cache and re-scrape at download time.
"""
import re
import asyncio
from io import BytesIO

import httpx
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_VIDEO_URL_RE = re.compile(
    r'(https?://[^\s"\'<>\\]*porn4fans\.[^/\s"\'<>\\]+/get_file/[^\s"\'<>\\]+\.mp4[^\s"\'<>\\]{0,200})',
    re.I,
)
_TITLE_RE = re.compile(r'<title>([^<]+)</title>', re.I)
_THUMB_RE = re.compile(
    r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)["\']',
    re.I,
)


async def _fetch_page(url: str) -> str | None:
    try:
        from curl_cffi.requests import AsyncSession
        async with AsyncSession() as s:
            r = await s.get(url, impersonate="chrome124",
                            headers={"User-Agent": UA}, timeout=15)
            return r.text if r.status_code == 200 else None
    except Exception:
        return None


async def get_p4f_video_url(page_url: str) -> str | None:
    """Re-scrape a fresh video URL from the page. Prefers stable hash-based URLs."""
    page = await _fetch_page(page_url)
    if not page:
        return None
    urls = _VIDEO_URL_RE.findall(page)
    # Filter out previews/trailers
    main = [u for u in urls if "_preview" not in u and "preview_" not in u and "trailer" not in u]
    if not main:
        main = urls
    return main[0] if main else None


async def show_options(m: Message, url: str) -> None:
    key           = cache_url("p4f", url)
    callback_data = f"d_p4f_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    page = await _fetch_page(url)
    if not page:
        await m.reply_text("🎬 Porn4Fans video", reply_markup=markup)
        return

    title_m = _TITLE_RE.search(page)
    thumb_m = _THUMB_RE.search(page)
    title   = title_m.group(1).strip() if title_m else "Porn4Fans"
    caption = f"🎬 <b>{title}</b>"

    if thumb_m:
        try:
            async with httpx.AsyncClient(timeout=10, follow_redirects=True,
                                         headers={"User-Agent": UA}) as c:
                raw = (await c.get(thumb_m.group(1))).content
            if raw:
                clean = await _process_thumb_bytes(raw)
                await m.reply_photo(photo=BytesIO(clean), caption=caption,
                                    reply_markup=markup)
                return
        except Exception:
            pass

    await m.reply_text(caption, reply_markup=markup)
