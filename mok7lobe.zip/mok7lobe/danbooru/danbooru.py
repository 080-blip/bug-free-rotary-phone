import os
import re
import glob
import json
import asyncio
import subprocess

from curl_cffi import requests as cffi_sync

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import MessageIdInvalid, MessageNotModified

from ._site_helper import show_options, get_danbooru_file
from PornHub.plugins.url_cache import resolve_url
from PornHub.plugins.downloader import clean_downloads, safe_edit, _get_best_thumb, remove_file, remove_glob_files
from PornHub.plugins import dl_state
from PornHub.plugins.function import upload_progress, humanbytes, MAX_TG_SIZE


def _check(_, __, m):
    return bool(m.text and "danbooru.donmai.us/posts/" in m.text)


danbooru_filter = filters.create(_check, name="danbooru_filter")


@Client.on_message(danbooru_filter)
async def danbooru_options(c: Client, m: Message):
    await show_options(m, m.text.strip())


@Client.on_callback_query(filters.regex(r"^d_dbn_"), group=-1)
async def danbooru_download(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("danbooru", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching post from Danbooru...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching post from Danbooru...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("danbooru", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    try:
        info = await get_danbooru_file(page_url)
        if not info:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not fetch post info from Danbooru.\n"
                "The site may be temporarily blocking access.",
                c=c, chat_id=chat_id,
            )
            return

        file_url = info["file_url"]
        file_ext = info["file_ext"]
        is_video = info["is_video"]

        msg_ref[0] = await safe_edit(
            msg_ref[0], "⏳ Downloading...", c=c, chat_id=chat_id
        )

        os.makedirs("downloads/danbooru", exist_ok=True)
        fname = f"downloads/danbooru/danbooru_{info['post_id']}.{file_ext}"

        # Run download in a thread so it never blocks pyrogram's event loop
        progress = {"downloaded": 0, "total": 0, "done": False, "status": 200}

        def _sync_dl():
            with cffi_sync.Session(impersonate="chrome131") as s:
                with s.stream(
                    "GET", file_url,
                    headers={"Referer": "https://danbooru.donmai.us/"},
                    timeout=600,
                ) as r:
                    progress["status"] = r.status_code
                    if r.status_code != 200:
                        return
                    progress["total"] = int(r.headers.get("content-length", 0))
                    with open(fname, "wb") as f:
                        for chunk in r.iter_content(65536):
                            f.write(chunk)
                            progress["downloaded"] += len(chunk)
            progress["done"] = True

        dl_task = asyncio.get_event_loop().run_in_executor(None, _sync_dl)

        # Poll progress every 2 seconds while download runs in background thread
        last_pct = -1
        while not progress["done"]:
            await asyncio.sleep(2)
            if progress["status"] != 200:
                await dl_task
                msg_ref[0] = await safe_edit(
                    msg_ref[0],
                    f"❌ Download failed (HTTP {progress['status']}).",
                    c=c, chat_id=chat_id,
                )
                return
            dl = progress["downloaded"]
            tot = progress["total"]
            if tot:
                pct = dl * 100 // tot
                if pct != last_pct:
                    last_pct = pct
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"⏳ Downloading... {pct}%  "
                        f"({humanbytes(dl)} / {humanbytes(tot)})",
                        c=c, chat_id=chat_id,
                    )

        await dl_task  # ensure thread finished and re-raise any exception

        file_size = os.path.getsize(fname)
        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n"
                f"<b>Size:</b> <code>{humanbytes(file_size)}</code>\n"
                "<i>Maximum allowed: 2 GiB.</i>",
                c=c, chat_id=chat_id,
            )
            return

        # ── Extract metadata & thumbnail (videos only) ───────────────────────
        vid_duration = 0
        vid_width  = info.get("width")  or 0
        vid_height = info.get("height") or 0
        thumb_path: str | None = None

        if is_video:
            # ffprobe: accurate duration + dimensions
            try:
                probe = await asyncio.to_thread(
                    subprocess.run,
                    [
                        "ffprobe", "-v", "quiet",
                        "-print_format", "json",
                        "-show_streams", "-show_format",
                        fname,
                    ],
                    capture_output=True, text=True, timeout=30,
                )
                if probe.returncode == 0:
                    meta = json.loads(probe.stdout)
                    for stream in meta.get("streams", []):
                        if stream.get("codec_type") == "video":
                            vid_width  = int(stream.get("width")  or vid_width)
                            vid_height = int(stream.get("height") or vid_height)
                            break
                    dur_str = meta.get("format", {}).get("duration", "0")
                    vid_duration = int(float(dur_str))
            except Exception:
                pass
            # Multi-frame thumbnail — picks the least-dark frame
            thumb_path = await _get_best_thumb(fname, vid_duration, {})
        rating = {"g": "General", "s": "Sensitive", "q": "Questionable",
                  "e": "Explicit"}.get(info["rating"], info["rating"])
        caption = (
            f"🖼 <b>Danbooru #{info['post_id']}</b>\n"
            f"<b>Rating:</b> <code>{rating}</code>  "
            f"<b>Type:</b> <code>{file_ext.upper()}</code>\n"
            f"<b>Size:</b> <code>{humanbytes(file_size)}</code>"
        )

        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading...</b>", c=c, chat_id=chat_id)
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("• Danbooru •", url=page_url)
        ]])

        PHOTO_EXTS = {"jpg", "jpeg", "png", "webp"}

        if is_video:
            await c.send_video(
                chat_id, fname,
                thumb=thumb_path,
                width=vid_width,
                height=vid_height,
                duration=vid_duration,
                supports_streaming=True,
                caption=caption,
                progress=upload_progress,
                progress_args=(msg_ref, chat_id, c),
                reply_markup=markup,
            )
        elif file_ext in PHOTO_EXTS:
            # send_photo: Telegram generates its own high-quality thumbnail
            await c.send_photo(
                chat_id, fname,
                caption=caption,
                progress=upload_progress,
                progress_args=(msg_ref, chat_id, c),
                reply_markup=markup,
            )
        else:
            await c.send_document(
                chat_id, fname,
                thumb=thumb_path,
                caption=caption,
                progress=upload_progress,
                progress_args=(msg_ref, chat_id, c),
                reply_markup=markup,
            )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(
            msg_ref[0],
            f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>",
            c=c, chat_id=chat_id,
        )
    finally:
        remove_glob_files("downloads/danbooru/danbooru_*")
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("danbooru", user_id)
