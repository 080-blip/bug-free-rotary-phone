"""
Danbooru — curl_cffi scraper (bypasses Cloudflare via browser impersonation).
Uses the official JSON API:
  GET https://danbooru.donmai.us/posts/{id}.json
curl_cffi with chrome131 impersonation passes Cloudflare's TLS/JA3 checks.
Reference: https://github.com/danbooru/danbooru
"""
import re
from io import BytesIO

from curl_cffi.requests import AsyncSession
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url

_POST_ID_RE = re.compile(r'donmai\.us/posts/(\d+)', re.I)

VIDEO_EXTS = {"mp4", "webm", "gif"}

HEADERS = {
    "Accept": "application/json",
    "Referer": "https://danbooru.donmai.us/",
    "Accept-Language": "en-US,en;q=0.9",
}

IMPERSONATE = "chrome131"

# Module-level persistent session — avoids TLS handshake overhead on every call
_SESSION: AsyncSession | None = None


def _get_session() -> AsyncSession:
    global _SESSION
    if _SESSION is None or not getattr(_SESSION, "_closed", False) is False:
        _SESSION = AsyncSession(impersonate=IMPERSONATE)
    return _SESSION


def _extract_post_id(url: str) -> str | None:
    m = _POST_ID_RE.search(url)
    return m.group(1) if m else None


async def get_danbooru_file(page_url: str) -> dict | None:
    post_id = _extract_post_id(page_url)
    if not post_id:
        return None

    api_url = f"https://danbooru.donmai.us/posts/{post_id}.json"

    try:
        s = _get_session()
        r = await s.get(api_url, headers=HEADERS, timeout=30)
        if r.status_code != 200:
            return None
        data = r.json()
    except Exception:
        # Session might be dead — reset and retry once
        global _SESSION
        _SESSION = None
        try:
            s = _get_session()
            r = await s.get(api_url, headers=HEADERS, timeout=30)
            if r.status_code != 200:
                return None
            data = r.json()
        except Exception:
            return None

    file_url = (
        data.get("file_url")
        or data.get("large_file_url")
    )
    if not file_url:
        return None

    preview_url = (
        data.get("preview_file_url")
        or data.get("large_file_url")
        or file_url
    )

    file_ext = (data.get("file_ext") or "").lower()
    if not file_ext and "." in file_url:
        file_ext = file_url.rsplit(".", 1)[-1].split("?")[0].lower()

    return {
        "post_id":    post_id,
        "file_url":   file_url,
        "preview_url": preview_url,
        "file_ext":   file_ext,
        "is_video":   file_ext in VIDEO_EXTS,
        "width":      data.get("image_width", 0),
        "height":     data.get("image_height", 0),
        "rating":     data.get("rating", ""),
    }


async def show_options(m: Message, url: str) -> None:
    key           = cache_url("dbn", url)
    callback_data = f"d_dbn_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_data)],
        [InlineKeyboardButton("🌐 View on Danbooru", url=url)],
    ])

    try:
        info = await get_danbooru_file(url)
        if not info:
            await m.reply_text(
                "⚠️ <b>Could not load this Danbooru post.</b>\n"
                "<i>The post may be gold-only or temporarily unavailable.</i>",
                reply_markup=markup,
            )
            return

        post_id = info["post_id"]
        ext     = info["file_ext"].upper()
        rating  = {"g": "General", "s": "Sensitive", "q": "Questionable",
                   "e": "Explicit"}.get(info["rating"], info["rating"])
        caption = (
            f"🖼 <b>Danbooru #{post_id}</b>\n"
            f"<b>Type:</b> <code>{ext}</code>  "
            f"<b>Rating:</b> <code>{rating}</code>"
        )

        if info["preview_url"]:
            try:
                s = _get_session()
                r = await s.get(info["preview_url"], headers=HEADERS, timeout=15)
                raw = r.content
                if raw:
                    clean = await _process_thumb_bytes(raw)
                    await m.reply_photo(
                        photo=BytesIO(clean), caption=caption, reply_markup=markup
                    )
                    return
            except Exception:
                pass

        await m.reply_text(caption, reply_markup=markup)
    except Exception:
        await m.reply_text("🖼 Danbooru post", reply_markup=markup)
