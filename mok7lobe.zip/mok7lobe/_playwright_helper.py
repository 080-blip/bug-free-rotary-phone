"""
Shared Playwright utility — uses system Chromium discovered via shutil.which().
All site helpers that need JS execution import from here.
"""
import shutil

def get_chromium_path() -> str | None:
    return shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
