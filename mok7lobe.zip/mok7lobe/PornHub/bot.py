import time
import importlib
import logging
import pyrogram

from pyrogram import Client
from pyrogram.errors import BadRequest, RPCError
from pyrogram.raw.all import layer
from pyrogram.types import BotCommand

from . import __version__, __version_code__
from .config import API_HASH, API_ID, TOKEN, log_chat

logger = logging.getLogger(__name__)

_BOT_COMMANDS = [
    BotCommand("start", "Start the bot"),
    BotCommand("restart", "Restart the welcome flow"),
    BotCommand("help", "Show commands and help"),
    BotCommand("search", "Search for videos"),
    BotCommand("autovideo", "Start periodic auto-video"),
    BotCommand("auto", "Alias for autovideo"),
    BotCommand("stopautovideo", "Stop periodic auto-video"),
    BotCommand("ping", "Check the bot response"),
    BotCommand("stats", "Show bot statistics"),
    BotCommand("gcast", "Broadcast a message"),
    BotCommand("broadcast", "Alias for gcast"),
]

_EXTERNAL_PLUGINS = [
    "xvideos.xvideos",
    "xnxx.xnxx",
    "nsfwr34.nsfwr34",
    "hentai_sites.hentai_sites",
    "danbooru.danbooru",
    "cartoonvideos247.cartoonvideos247",
    "xvv1deos.xvv1deos",
    "saradahentai.saradahentai",
    "xhamster.xhamster",
    "rule34xyz.rule34xyz",
    "realbooru.realbooru",
    "porn4fans.porn4fans",
    "thatpervert.thatpervert",
    "hentaifox.hentaifox",
    "hanimehentai.hanimehentai",
    "hentaibalo.hentaibalo",
    "rule34video.rule34video",
    "thisvid.thisvid",
    "phfamily.phfamily",
    "rule34xxx.rule34xxx",
    "thumbzilla.thumbzilla",
    "xvideosred.xvideosred",
    "youporn.youporn",
    "sakuhentai.sakuhentai",
    "porncomic.porncomic",
    "arabshentai.arabshentai",
    "imhentai.imhentai",
    "ehentai.ehentai",
]


def _load_external_plugins(client: Client) -> None:
    """
    Import each external site module and register any @Client.on_message
    decorated handlers onto this client instance.
    """
    for module_path in _EXTERNAL_PLUGINS:
        try:
            module = importlib.import_module(module_path)
            for attr_name in dir(module):
                func = getattr(module, attr_name)
                if callable(func) and hasattr(func, "handlers"):
                    for handler, group in func.handlers:
                        client.add_handler(handler, group)
            logger.info("Loaded external plugin: %s", module_path)
        except Exception as e:
            logger.warning("Failed to load external plugin %s: %s", module_path, e)


class PornHub(Client):
    def __init__(self):
        self.start_time = None
        name = self.__class__.__name__.lower()

        super().__init__(
            name=name,
            app_version=f"PornHub v{__version__}",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=TOKEN,
            plugins=dict(root="PornHub.plugins"),
            in_memory=True,
            workers=16,
            sleep_threshold=60,
        )

    async def start(self):
        await super().start()
        self.start_time = time.time()

        try:
            await self.set_bot_commands(_BOT_COMMANDS)
            logger.info("Registered Telegram bot commands")
        except Exception:
            logger.warning("Unable to register Telegram bot commands", exc_info=True)

        _load_external_plugins(self)

        logger.info(
            "PornHub running with Pyrogram v%s (Layer %s) started on %s. Hello!",
            pyrogram.__version__,
            layer,
            self.me.username,
        )

        start_message = (
            "<b>PornHub started!</b>\n\n"
            f"<b>Version:</b> <code>v{__version__} ({__version_code__})</code>\n"
            f"<b>Pyrogram:</b> <code>v{pyrogram.__version__}</code>"
        )

        try:
            await self.send_message(chat_id=log_chat, text=start_message)
        except (BadRequest, RPCError):
            logger.warning("Unable to send message to log_chat!")
        except Exception:
            pass

    async def stop(self):
        try:
            await super().stop()
        except ConnectionError:
            pass
        except Exception as e:
            logger.warning("Error stopping client: %s", e)
        finally:
            logger.warning("PornHub stopped, Bye!")
