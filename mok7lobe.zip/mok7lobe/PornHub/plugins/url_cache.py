"""
Shared short-key URL cache used by xnxx, xvideos and any future plugin
that needs to store a long URL behind a ≤64-byte Telegram callback_data.

Persisted to disk so callbacks survive bot restarts.

Usage:
    from PornHub.plugins.url_cache import cache_url, resolve_url

    key           = cache_url("xnxx", "https://...")   # returns 8-char hex
    callback_data = f"d_xnxx_{key}"                    # safe for Telegram

    url = resolve_url("d_xnxx_" + key)                 # back to full URL
"""
import os
import json
import hashlib
import logging

logger = logging.getLogger(__name__)

_CACHE_FILE = "url_cache.json"
_store: dict[str, str] = {}


def _load() -> None:
    global _store
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                _store = json.load(f)
    except Exception as e:
        logger.warning("url_cache: failed to load cache file: %s", e)
        _store = {}


def _save() -> None:
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(_store, f, ensure_ascii=False)
    except Exception as e:
        logger.warning("url_cache: failed to save cache file: %s", e)


# Load on import
_load()


def cache_url(prefix: str, url: str) -> str:
    """Store url and return an 8-char hex key. prefix is e.g. 'xnxx'."""
    key      = hashlib.md5(url.encode()).hexdigest()[:8]
    full_key = f"d_{prefix}_{key}"
    _store[full_key] = url
    _save()
    return key


def resolve_url(full_callback_key: str) -> str | None:
    """Return the original URL for a callback key, or None if not found."""
    return _store.get(full_callback_key)
