"""Periodic video delivery from the supported public video sites.

The scheduler is started per chat with /autovideo.  It discovers public video
links from each site's landing page, remembers previously selected links, and
downloads/uploads one fresh video per site every ten minutes.
"""

from __future__ import annotations

import asyncio
import glob
import html
import json
import logging
import os
import random
import re
import time
from dataclasses import dataclass
from urllib.parse import urljoin, urldefrag, urlparse

import httpx
import yt_dlp as youtube_dl
from pyrogram import Client, filters
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from ..config import DELETE_DOWNLOADS, prefixs
from .downloader import FFMPEG, MAX_TG_SIZE, _get_best_thumb, remove_file
from .function import humanbytes, run_in_executor
from .http_client import get_client

logger = logging.getLogger(__name__)

INTERVAL_SECONDS = 10 * 60
MAX_PARALLEL_DOWNLOADS = 3
STATE_FILE = "auto_video_seen.json"
VIDEO_EXTENSIONS = (".mp4", ".mkv", ".webm", ".mov")


@dataclass(frozen=True)
class VideoSite:
    key: str
    label: str
    homepage: str
    video_pattern: str


# These are the video-capable sites already supported by the imported bot.
# Image boards, galleries, and comic sites are intentionally not included.
VIDEO_SITES = (
    VideoSite("pornhub", "PornHub", "https://www.pornhub.com/video", r"view_video\.php\?viewkey="),
    VideoSite("xvideos", "XVideos", "https://www.xvideos.com/", r"/video\."),
    VideoSite("xnxx", "XNXX", "https://www.xnxx.com/", r"/video[-/]"),
    VideoSite("nsfwr34", "NSFWr34", "https://nsfwr34.com/", r"/(video|post)/"),
    VideoSite("cv247", "CartoonVideos247", "https://cartoonvideos247.com/", r"/(video|watch)/"),
    VideoSite("xvv1deos", "XVV1DEOS", "https://xvv1deos.com/", r"/video"),
    VideoSite("saradahentai", "SaradaHentai", "https://saradahentai.com/", r"/video"),
    VideoSite("xhamster", "xHamster", "https://xhamster.com/", r"/videos?[/\-]"),
    VideoSite("rule34xyz", "Rule34.xyz", "https://rule34.xyz/", r"/(video|post)/"),
    VideoSite("porn4fans", "Porn4Fans", "https://porn4fans.com/", r"/videos?[/\-]"),
    VideoSite("thatpervert", "ThatPervert", "https://thatpervert.com/", r"/post/"),
    VideoSite("hentaifox", "HentaiFox", "https://hentaifox.tv/", r"/video/"),
    VideoSite("hanimehentai", "HanimeHentai", "https://hanimehentai.tv/", r"/video/"),
    VideoSite("hentaibalo", "HentaiBalo", "https://hentaibalo.com/", r"/video"),
    VideoSite("rule34video", "Rule34Video", "https://rule34video.com/", r"/video"),
    VideoSite("thisvid", "ThisVid", "https://thisvid.com/", r"/(video|watch)[/\-]"),
    VideoSite("youporn", "YouPorn", "https://www.youporn.com/", r"/(watch|embed)/"),
    VideoSite("tube8", "Tube8", "https://www.tube8.com/", r"/video"),
    VideoSite("redtube", "RedTube", "https://www.redtube.com/", r"/videos?[/\-]"),
    VideoSite("thumbzilla", "ThumbZilla", "https://www.thumbzilla.com/", r"/video/"),
    VideoSite("xvideosred", "XVideos.red", "https://xvideos.red/", r"/video\."),
    VideoSite("hentaigem", "HentaiGem", "https://hentaigem.com/", r"/(video|watch)/"),
    VideoSite("xhentai", "XHentai", "https://xhentai.tv/", r"/(video|watch|hentai)/"),
    VideoSite("3dporndude", "3DPorndude", "https://www.3dporndude.com/", r"/(video|watch)/"),
)

_SITE_BY_KEY = {site.key: site for site in VIDEO_SITES}
_jobs: dict[int, asyncio.Task] = {}
_seen: dict[str, set[str]] = {}
_seen_lock = asyncio.Lock()


def _load_seen() -> None:
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as stream:
            raw = json.load(stream)
        if isinstance(raw, dict):
            _seen.update({
                key: set(values[-500:])
                for key, values in raw.items()
                if key in _SITE_BY_KEY and isinstance(values, list)
            })
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass


def _save_seen() -> None:
    try:
        payload = {key: sorted(values)[-500:] for key, values in _seen.items()}
        with open(STATE_FILE, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
    except OSError:
        logger.warning("Could not save auto-video history", exc_info=True)


_load_seen()


def _is_same_site(url: str, site: VideoSite) -> bool:
    host = (urlparse(url).hostname or "").lower().removeprefix("www.")
    homepage_host = (urlparse(site.homepage).hostname or "").lower().removeprefix("www.")
    return host == homepage_host or host.endswith("." + homepage_host)


def _candidate_urls(page: str, site: VideoSite) -> list[str]:
    """Extract likely video-page links from a site's HTML landing page."""
    found: list[str] = []
    seen: set[str] = set()
    page = page.replace("\\/", "/")

    hrefs = re.findall(r"""(?:href|data-href)=["']([^"']+)["']""", page, re.I)
    hrefs += re.findall(r"""https?://[^\s"'<>\\]+""", page, re.I)

    for raw_url in hrefs:
        raw_url = html.unescape(raw_url).strip()
        if raw_url.startswith(("javascript:", "mailto:", "#", "data:")):
            continue
        url = urldefrag(urljoin(site.homepage, raw_url))[0]
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not _is_same_site(url, site):
            continue
        if not re.search(site.video_pattern, parsed.path + "?" + parsed.query, re.I):
            continue
        if re.search(r"/(?:login|signup|register|search|category|tag|page)/?", parsed.path, re.I):
            continue
        if re.search(r"\.(?:jpg|jpeg|png|gif|webp|css|js|xml)(?:$|\?)", url, re.I):
            continue
        if url not in seen:
            seen.add(url)
            found.append(url)

    random.shuffle(found)
    return found[:30]


async def _flat_candidates(site: VideoSite) -> list[str]:
    """Use a yt-dlp listing extractor when the landing page has no links."""
    options = {
        "extract_flat": True,
        "skip_download": True,
        "playlistend": 20,
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": True,
    }

    def _extract():
        with youtube_dl.YoutubeDL(options) as ydl:
            return ydl.extract_info(site.homepage, download=False)

    try:
        info = await asyncio.wait_for(run_in_executor(_extract), timeout=35)
    except Exception:
        return []

    entries = info.get("entries", []) if isinstance(info, dict) else []
    candidates = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        candidate = entry.get("webpage_url") or entry.get("original_url")
        if candidate and _is_same_site(candidate, site):
            candidates.append(candidate)
    return candidates


async def _discover(site: VideoSite) -> list[str]:
    try:
        client: httpx.AsyncClient = await get_client()
        response = await client.get(site.homepage, timeout=20)
        if response.status_code == 200:
            candidates = _candidate_urls(response.text, site)
            if candidates:
                return candidates
    except Exception:
        logger.debug("HTML discovery failed for %s", site.label, exc_info=True)
    return await _flat_candidates(site)


def _video_key(url: str) -> str:
    """Normalize a URL enough to recognize the same video on later rounds."""
    parsed = urlparse(url)
    return f"{parsed.netloc.lower()}{parsed.path}?{parsed.query}".rstrip("?").lower()


async def _pick_new(site: VideoSite, candidates: list[str]) -> str | None:
    if not candidates:
        return None
    async with _seen_lock:
        history = _seen.setdefault(site.key, set())
        for candidate in candidates:
            key = _video_key(candidate)
            if key not in history:
                history.add(key)
                _save_seen()
                return candidate

        # Once all currently visible links have been sent, start a new cycle.
        history.clear()
        candidate = candidates[0]
        history.add(_video_key(candidate))
        _save_seen()
        return candidate


def _downloaded_file(directory: str, prepared_name: str | None, started_at: float) -> str | None:
    possible: list[str] = []
    if prepared_name:
        base, _ = os.path.splitext(prepared_name)
        possible.extend(base + extension for extension in VIDEO_EXTENSIONS)
        possible.append(prepared_name)

    for path in possible:
        if os.path.isfile(path):
            return path

    matches = [
        path for path in glob.glob(os.path.join(directory, "*"))
        if path.lower().endswith(VIDEO_EXTENSIONS)
        and os.path.isfile(path)
        and os.path.getmtime(path) >= started_at - 2
    ]
    return max(matches, key=os.path.getmtime) if matches else None


async def _download_and_send(client: Client, chat_id: int, site: VideoSite, url: str) -> bool:
    directory = os.path.join("downloads", "autovideo", site.key)
    os.makedirs(directory, exist_ok=True)
    options = {
        "outtmpl": os.path.join(directory, "%(title).120B [%(id)s].%(ext)s"),
        "format": "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "merge_output_format": "mp4",
        "noplaylist": True,
        "retries": 3,
        "fragment_retries": 3,
        "skip_unavailable_fragments": True,
        "socket_timeout": 30,
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": False,
        "ffmpeg_location": FFMPEG,
    }
    started_at = time.time()
    downloaded: str | None = None
    thumb: str | None = None

    try:
        def _download():
            with youtube_dl.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=True)
                prepared = ydl.prepare_filename(info) if info else None
                return info, prepared

        info, prepared = await asyncio.wait_for(run_in_executor(_download), timeout=300)
        if not info:
            return False
        downloaded = _downloaded_file(directory, prepared, started_at)
        if not downloaded or not os.path.exists(downloaded):
            return False

        size = os.path.getsize(downloaded)
        if size > MAX_TG_SIZE:
            logger.warning("Skipping %s: file is too large (%s)", site.label, humanbytes(size))
            return False

        duration = int(info.get("duration") or 0)
        thumb = await _get_best_thumb(downloaded, duration, info)
        title = html.escape(str(info.get("title") or site.label))
        source_url = html.escape(str(info.get("webpage_url") or url), quote=True)
        caption = (
            f"🎬 <b>{title}</b>\n"
            f"🌐 <b>Source:</b> {html.escape(site.label)}\n"
            f"💾 <code>{humanbytes(size)}</code>"
        )
        await client.send_video(
            chat_id,
            downloaded,
            thumb=thumb,
            width=int(info.get("width") or 1280),
            height=int(info.get("height") or 720),
            duration=duration,
            supports_streaming=True,
            caption=caption,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(f"• {site.label} •", url=source_url),
            ]]),
        )
        return True
    except Exception:
        logger.warning("Auto-video failed for %s (%s)", site.label, url, exc_info=True)
        return False
    finally:
        if thumb:
            remove_file(thumb)
        if downloaded:
            remove_file(downloaded)
        if DELETE_DOWNLOADS:
            for path in glob.glob(os.path.join(directory, "*.part*")):
                remove_file(path)


async def _send_round(client: Client, chat_id: int) -> None:
    try:
        status = await client.send_message(
            chat_id,
            "⏳ أبحث عن فيديو مختلف من مواقع الفيديو المدعومة...",
        )
    except Exception:
        logger.warning("Could not start auto-video round in chat %s", chat_id, exc_info=True)
        return

    discovered = await asyncio.gather(
        *(_discover(site) for site in VIDEO_SITES),
        return_exceptions=True,
    )
    choices: list[tuple[VideoSite, str]] = []
    for site, result in zip(VIDEO_SITES, discovered):
        if isinstance(result, Exception):
            continue
        url = await _pick_new(site, result)
        if url:
            choices.append((site, url))

    semaphore = asyncio.Semaphore(MAX_PARALLEL_DOWNLOADS)

    async def send_one(site: VideoSite, url: str) -> bool:
        async with semaphore:
            return await _download_and_send(client, chat_id, site, url)

    results = await asyncio.gather(
        *(send_one(site, url) for site, url in choices),
        return_exceptions=True,
    )
    sent = sum(result is True for result in results)
    failed = len(results) - sent
    try:
        await status.edit_text(
            f"✅ اكتملت الجولة\n"
            f"📤 تم إرسال: <code>{sent}</code>\n"
            f"⚠️ تعذر إرسال: <code>{failed}</code>\n"
            f"⏰ الجولة التالية بعد 10 دقائق"
        )
    except Exception:
        pass


async def _schedule(client: Client, chat_id: int) -> None:
    try:
        while True:
            await _send_round(client, chat_id)
            await asyncio.sleep(INTERVAL_SECONDS)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("Auto-video scheduler crashed for chat %s", chat_id)
    finally:
        current = asyncio.current_task()
        if _jobs.get(chat_id) is current:
            _jobs.pop(chat_id, None)


async def _stop_for_chat(chat_id: int) -> bool:
    task = _jobs.pop(chat_id, None)
    if not task:
        return False
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    return True


@Client.on_message(filters.command(["autovideo", "auto"], prefixs))
async def start_auto_video(client: Client, message: Message):
    if (message.text or "").split(maxsplit=1)[-1].lower() == "stop":
        stopped = await _stop_for_chat(message.chat.id)
        await message.reply_text("🛑 تم إيقاف الإرسال الدوري." if stopped else "ℹ️ لا يوجد إرسال دوري يعمل.")
        return

    task = _jobs.get(message.chat.id)
    if task and not task.done():
        await message.reply_text("ℹ️ الإرسال الدوري يعمل أصلًا في هذه المحادثة.")
        return

    await message.reply_text(
        "✅ بدأ الإرسال الدوري.\n"
        "سيتم إرسال فيديو مختلف من كل موقع فيديو مدعوم الآن، ثم تكرار الجولة كل 10 دقائق.\n"
        "للإيقاف استخدم /stopautovideo"
    )
    _jobs[message.chat.id] = asyncio.create_task(
        _schedule(client, message.chat.id),
        name=f"auto-video-{message.chat.id}",
    )


@Client.on_message(filters.command("stopautovideo", prefixs))
async def stop_auto_video(_, message: Message):
    stopped = await _stop_for_chat(message.chat.id)
    await message.reply_text("🛑 تم إيقاف الإرسال الدوري." if stopped else "ℹ️ لا يوجد إرسال دوري يعمل.")