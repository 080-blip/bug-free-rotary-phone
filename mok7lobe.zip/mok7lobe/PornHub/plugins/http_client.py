"""
Shared async HTTP client with connection pooling, HTTP/2, brotli, and retry logic.
One client instance is reused across all plugin requests.
"""
import asyncio
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

_client: httpx.AsyncClient | None = None
_lock = asyncio.Lock()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.pornhub.com/",
    "Accept-Encoding": "br, gzip, deflate",
}

LIMITS = httpx.Limits(
    max_connections=64,
    max_keepalive_connections=32,
    keepalive_expiry=30,
)

TIMEOUT = httpx.Timeout(connect=10.0, read=20.0, write=10.0, pool=5.0)


async def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        async with _lock:
            if _client is None or _client.is_closed:
                _client = httpx.AsyncClient(
                    http2=True,
                    headers=HEADERS,
                    limits=LIMITS,
                    timeout=TIMEOUT,
                    follow_redirects=True,
                )
    return _client


async def close_client():
    global _client
    if _client and not _client.is_closed:
        await _client.aclose()
        _client = None


@retry(
    retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
    reraise=True,
)
async def fetch_bytes(url: str) -> bytes | None:
    """Fetch URL and return bytes, with automatic retry on timeout/connection errors."""
    try:
        client = await get_client()
        resp = await client.get(str(url))
        if resp.status_code == 200 and resp.content:
            return resp.content
    except Exception:
        pass
    return None
