import re
import time
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor
from pyrogram.errors import MessageNotModified, FloodWait, MessageIdInvalid

_last_edit_time: dict = {}
_ANSI_ESCAPE = re.compile(r'\x1b\[[0-9;]*m')

MAX_TG_SIZE = 2 * 1024 * 1024 * 1024

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.pornhub.com/",
    "Accept-Encoding": "br, gzip, deflate",
}

_executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="ph_worker")


def get_executor() -> ThreadPoolExecutor:
    return _executor


def run_in_executor(func, *args):
    loop = asyncio.get_running_loop()
    return loop.run_in_executor(_executor, func, *args)


def strip_ansi(text) -> str:
    if text is None:
        return "N/A"
    return _ANSI_ESCAPE.sub("", str(text)).strip()


def humanbytes(size: int) -> str:
    if not size:
        return "0B"
    power = 2 ** 10
    raised = 0
    units = {0: "B", 1: "KiB", 2: "MiB", 3: "GiB", 4: "TiB"}
    while size > power:
        size /= power
        raised += 1
    return f"{round(size, 2)} {units[raised]}"


def _split_filename(file_name: str):
    m = re.match(r"^(.*?)\s*(\[[^\]]+\]\..*?)$", file_name)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return file_name, ""


async def _do_edit_coro(client, msg_ref: list, text: str, chat_id=None):
    try:
        await msg_ref[0].edit(text)
    except MessageIdInvalid:
        if chat_id:
            try:
                new_msg = await client.send_message(chat_id, text)
                msg_ref[0] = new_msg
            except Exception:
                pass
    except (FloodWait, MessageNotModified, AttributeError, Exception):
        pass


def _do_edit(client, msg_ref: list, text: str, chat_id=None):
    try:
        asyncio.run_coroutine_threadsafe(
            _do_edit_coro(client, msg_ref, text, chat_id),
            client.loop
        )
    except Exception:
        pass


def download_progress_hook(d: dict, msg_ref: list, client, chat_id=None):
    if d["status"] == "downloading":
        msg_id = msg_ref[0].id
        now = time.time()
        if now - _last_edit_time.get(msg_id, 0) < 3:
            return
        _last_edit_time[msg_id] = now

        downloaded_str = strip_ansi(d.get("_downloaded_bytes_str", "N/A"))
        total_str = strip_ansi(
            d.get("_total_bytes_str") or d.get("_total_bytes_estimate_str") or "N/A"
        )
        speed_str   = strip_ansi(d.get("_speed_str", "Unknown B/s"))
        eta_str     = strip_ansi(d.get("_eta_str", "Unknown"))
        percent_str = strip_ansi(d.get("_percent_str", "N/A"))

        file_name = d.get("filename", "N/A")
        if file_name != "N/A":
            file_name = file_name.split("/")[-1]

        title, cache = _split_filename(file_name)

        lines = ["📥 <b>Downloading...</b>"]
        if title:
            lines.append(f"<b>File :</b> <code>{title}</code>")
        if cache:
            lines.append(f"<b>Cache:</b> <code>{cache}</code>")
        lines += [
            f"<b>Size :</b> <code>{downloaded_str}</code> / <code>{total_str}</code>",
            f"<b>Speed:</b> <code>{speed_str}</code>",
            f"<b>ETA  :</b> <code>{eta_str}</code>",
            f"<b>Done :</b> <code>{percent_str}</code>",
        ]

        threading.Thread(
            target=_do_edit, args=(client, msg_ref, "\n".join(lines), chat_id), daemon=True
        ).start()

    elif d["status"] == "finished":
        msg_id = msg_ref[0].id
        _last_edit_time.pop(msg_id, None)
        file_name = d.get("filename", "")
        if file_name:
            file_name = file_name.split("/")[-1]
        threading.Thread(
            target=_do_edit,
            args=(client, msg_ref,
                  f"✅ <b>Download complete!</b>\n<code>{file_name}</code>\n\n⏳ <b>Processing & uploading...</b>",
                  chat_id),
            daemon=True,
        ).start()


async def upload_progress(current: int, total: int, msg_ref: list, chat_id=None, client=None):
    msg_id = msg_ref[0].id
    now = time.time()
    if now - _last_edit_time.get(f"up_{msg_id}", 0) < 3:
        return
    _last_edit_time[f"up_{msg_id}"] = now
    percent     = current * 100 / total if total else 0
    current_str = humanbytes(current)
    total_str   = humanbytes(total) if total else "N/A"
    text = (
        f"📤 <b>Uploading to Telegram...</b>\n"
        f"<b>Progress:</b> <code>{current_str}</code> / "
        f"<code>{total_str}</code> (<code>{percent:.1f}%</code>)"
    )
    try:
        await msg_ref[0].edit(text)
    except MessageIdInvalid:
        if client and chat_id:
            try:
                new_msg = await client.send_message(chat_id, text)
                msg_ref[0] = new_msg
            except Exception:
                pass
    except (MessageNotModified, FloodWait, Exception):
        pass
