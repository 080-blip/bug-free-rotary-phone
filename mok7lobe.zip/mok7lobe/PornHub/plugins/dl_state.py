"""Per-site active download tracking.

Each site has its own set, so a user can download from XVideos and XNXX
at the same time without one blocking the other.
"""
from collections import defaultdict

_active: dict[str, set] = defaultdict(set)


def is_active(site: str, user_id: int) -> bool:
    return user_id in _active[site]


def add_active(site: str, user_id: int) -> None:
    _active[site].add(user_id)


def remove_active(site: str, user_id: int) -> None:
    _active[site].discard(user_id)
