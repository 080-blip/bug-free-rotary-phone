"""
Search plugin — parallel thumbnail pre-fetching, shared HTTP client, TTL caches.
"""
import re
import asyncio
from io import BytesIO

from pyrogram import Client, filters
from pyrogram.types import (
    Message, CallbackQuery,
    InlineKeyboardButton, InlineKeyboardMarkup,
)
from pyrogram.errors import MessageNotModified, BadRequest
from pornhub_api import PornhubApi
from pornhub_api.backends.aiohttp import AioHttpBackend
from cachetools import TTLCache

from ..config import prefixs
from .http_client import fetch_bytes
from .downloader import _process_thumb_bytes

RESULTS_PER_PAGE = 8

_search_cache: TTLCache = TTLCache(maxsize=256, ttl=300)
_video_cache: TTLCache = TTLCache(maxsize=512, ttl=600)
_thumb_url_cache: dict[str, str] = {}
_thumb_bytes_cache: dict[str, bytes] = {}
_prefetch_tasks: dict[str, asyncio.Task] = {}


async def _search_videos(query: str, page: int) -> list:
    cache_key = f"{query.lower().strip()}:{page}"
    if cache_key in _search_cache:
        return _search_cache[cache_key]
    backend = AioHttpBackend()
    api = PornhubApi(backend=backend)
    try:
        result = await api.search.search_videos(query, page=page)
        videos = list(result)
        _search_cache[cache_key] = videos
        for v in videos:
            if v.thumb:
                _thumb_url_cache[v.video_id] = str(v.thumb)
        return videos
    except Exception:
        return []
    finally:
        await backend.close()


async def _get_video_by_id(video_id: str):
    if video_id in _video_cache:
        return _video_cache[video_id]
    backend = AioHttpBackend()
    api = PornhubApi(backend=backend)
    try:
        vid = await api.video.get_by_id(video_id)
        _video_cache[video_id] = vid
        if vid.thumb:
            _thumb_url_cache[video_id] = str(vid.thumb)
        return vid
    finally:
        await backend.close()


def _prefetch_thumbs(video_ids: list[str]):
    """
    Launch background tasks to pre-fetch thumbnail bytes for all video_ids.
    Results land in _thumb_bytes_cache so clicks are near-instant.
    """
    async def _fetch_one(vid_id: str):
        if vid_id in _thumb_bytes_cache:
            return
        url = _thumb_url_cache.get(vid_id)
        if not url:
            return
        data = await fetch_bytes(url)
        if data:
            # Process during pre-fetch so clicks are instant and clean
            _thumb_bytes_cache[vid_id] = await _process_thumb_bytes(data)

    async def _run_all():
        await asyncio.gather(*[_fetch_one(vid_id) for vid_id in video_ids])

    loop = asyncio.get_event_loop()
    task = loop.create_task(_run_all())
    for vid_id in video_ids:
        _prefetch_tasks[vid_id] = task


def _build_results_text(query: str, total: int, page: int) -> str:
    return (
        f"🔍 <b>Results for:</b> <code>{query}</code>\n"
        f"📄 Page <b>{page}</b>  ·  <b>{total}</b> videos on this page\n\n"
        f"Tap a title to see details:"
    )


def _build_results_keyboard(videos: list, query: str, page: int) -> InlineKeyboardMarkup:
    q_safe = query[:30]
    buttons = []
    for i, v in enumerate(videos[:RESULTS_PER_PAGE]):
        label = f"{i + 1}. {v.title[:38]} [{v.duration}]"
        buttons.append([InlineKeyboardButton(
            label,
            callback_data=f"svid_{v.video_id}_{q_safe}_{page}"
        )])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("◀ Prev", callback_data=f"srch_{page - 1}_{q_safe}"))
    nav.append(InlineKeyboardButton(f"📄 {page}", callback_data="noop"))
    if len(videos) >= RESULTS_PER_PAGE:
        nav.append(InlineKeyboardButton("Next ▶", callback_data=f"srch_{page + 1}_{q_safe}"))
    if nav:
        buttons.append(nav)

    return InlineKeyboardMarkup(buttons)


async def _send_results(c: Client, chat_id: int, query: str, page: int, edit_msg=None):
    """
    Fetch results, display them, then kick off background thumbnail pre-fetching.
    Handles both text and photo messages gracefully.
    """
    videos = await _search_videos(query, page=page)

    if not videos:
        text = f"❌ No results for <b>{query}</b> on page {page}."
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("◀ Prev", callback_data=f"srch_{page - 1}_{query[:30]}")
        ]]) if page > 1 else None
    else:
        text = _build_results_text(query, len(videos), page)
        keyboard = _build_results_keyboard(videos, query, page)
        # Kick off background pre-fetch for all visible thumbnails
        _prefetch_thumbs([v.video_id for v in videos[:RESULTS_PER_PAGE]])

    if edit_msg is not None:
        try:
            await edit_msg.edit_text(text, reply_markup=keyboard)
            return
        except BadRequest:
            try:
                await edit_msg.delete()
            except Exception:
                pass
        except MessageNotModified:
            return

    await c.send_message(chat_id=chat_id, text=text, reply_markup=keyboard)


@Client.on_message(
    filters.incoming & filters.private &
    filters.command("search", prefixes=prefixs)
)
async def search_command(c: Client, m: Message):
    query = " ".join(m.command[1:]).strip() if len(m.command) > 1 else ""
    if not query:
        await m.reply_text(
            "🔍 Send a search term:\n"
            "<code>/search video name</code>"
        )
        return

    status = await m.reply_text(f"🔍 Searching: <b>{query}</b>...")
    try:
        await _send_results(c, m.chat.id, query, page=1, edit_msg=status)
    except Exception as e:
        try:
            await status.edit_text(f"❌ Error: <code>{str(e)[:200]}</code>")
        except Exception:
            pass


@Client.on_callback_query(filters.regex(r"^srch_(\d+)_(.+)$"))
async def search_page(c: Client, q: CallbackQuery):
    match = re.match(r"^srch_(\d+)_(.+)$", q.data)
    if not match:
        await q.answer("Invalid data.", show_alert=True)
        return

    page = int(match.group(1))
    query = match.group(2)
    await q.answer(f"📄 Page {page}...")

    try:
        await _send_results(c, q.from_user.id, query, page=page, edit_msg=q.message)
    except Exception as e:
        try:
            await q.message.edit_text(f"❌ Error: <code>{str(e)[:200]}</code>")
        except Exception:
            await c.send_message(q.from_user.id, f"❌ Error: <code>{str(e)[:200]}</code>")


@Client.on_callback_query(filters.regex(r"^svid_([^_]+)_(.+)_(\d+)$"))
async def search_video_selected(c: Client, q: CallbackQuery):
    match = re.match(r"^svid_([^_]+)_(.+)_(\d+)$", q.data)
    video_id = match.group(1)
    back_query = match.group(2)
    back_page = int(match.group(3))

    await q.answer("⏳ Loading...")

    # Check if thumbnail bytes are already pre-fetched
    thumb_bytes = _thumb_bytes_cache.get(video_id)
    cached_thumb_url = _thumb_url_cache.get(video_id)

    try:
        if thumb_bytes:
            # Thumbnail already cached — just fetch video info
            vid = await _get_video_by_id(video_id)
        elif cached_thumb_url:
            # URL known — fetch video info and thumbnail in parallel
            vid, thumb_bytes = await asyncio.gather(
                _get_video_by_id(video_id),
                fetch_bytes(cached_thumb_url),
            )
        else:
            vid = await _get_video_by_id(video_id)
            thumb_url = str(vid.thumb) if vid.thumb else None
            thumb_bytes = await fetch_bytes(thumb_url) if thumb_url else None

        title = vid.title or "Unknown"
        duration_str = str(vid.duration or "")
        video_url = str(vid.url)

        caption = (
            f"🎬 <b>{title}</b>\n"
            f"⏱ <b>Duration:</b> <code>{duration_str}</code>"
        )

        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("⬇️ Download", callback_data=f"d_{video_url}")],
            [InlineKeyboardButton("🌐 Watch on web", url=video_url)],
            [InlineKeyboardButton("◀ Back to results", callback_data=f"srch_{back_page}_{back_query}")],
        ])

        try:
            await q.message.delete()
        except Exception:
            pass

        if thumb_bytes:
            # If these bytes weren't pre-processed (cache miss path), clean them now
            if not _thumb_bytes_cache.get(video_id):
                thumb_bytes = await _process_thumb_bytes(thumb_bytes)
            await c.send_photo(
                chat_id=q.from_user.id,
                photo=BytesIO(thumb_bytes),
                caption=caption,
                reply_markup=markup,
            )
        else:
            await c.send_message(
                chat_id=q.from_user.id,
                text=caption,
                reply_markup=markup,
            )

    except Exception as e:
        try:
            await q.message.edit_text(f"❌ Error: <code>{str(e)[:200]}</code>")
        except Exception:
            await c.send_message(q.from_user.id, f"❌ Error: <code>{str(e)[:200]}</code>")


@Client.on_callback_query(filters.regex(r"^noop$"))
async def noop_callback(c: Client, q: CallbackQuery):
    await q.answer()
