import os
import re
import glob
import shutil
import asyncio
import yt_dlp as youtube_dl
from io import BytesIO

import httpx

from ..config import log_chat, sub_chat, DELETE_DOWNLOADS
from .function import download_progress_hook, upload_progress, humanbytes, MAX_TG_SIZE, run_in_executor
from .http_client import fetch_bytes
from pornhub_api import PornhubApi
from pornhub_api.backends.aiohttp import AioHttpBackend
from yt_dlp.utils import DownloadError
from .url_cache import cache_url, resolve_url as _resolve_url

from pyrogram import Client, filters
from pyrogram.types import (
    Message, InlineQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    CallbackQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
)
from pyrogram.errors import ChatAdminRequired, UserNotParticipant, ChatWriteForbidden, MessageIdInvalid, MessageNotModified


os.makedirs("downloads", exist_ok=True)
for _s in (
    "pornhub", "xvideos", "xnxx", "nsfwr34", "hentai", "danbooru", "cv247",
    "xvv1deos", "saradahentai", "xhamster", "rule34xyz", "realbooru",
    "p4fans", "thatpervert", "hentaifox", "hanimehentai", "hentaibalo",
    "phfamily", "thumbzilla", "rule34video", "rule34xxx", "thisvid", "xvideosred",
    "arabshentai",
):
    os.makedirs(f"downloads/{_s}", exist_ok=True)

active: set = set()
FFMPEG = shutil.which("ffmpeg") or "ffmpeg"

from PornHub.plugins import dl_state


async def safe_edit(msg, text, c=None, chat_id=None, **kwargs):
    try:
        return await msg.edit(text, **kwargs)
    except MessageIdInvalid:
        if c and chat_id:
            try:
                return await c.send_message(chat_id, text)
            except Exception:
                pass
    except MessageNotModified:
        pass
    except Exception:
        pass
    return msg


def remove_file(path: str) -> None:
    """حذف ملف فقط إذا كان DELETE_DOWNLOADS مفعّلاً."""
    if not DELETE_DOWNLOADS:
        return
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def remove_glob_files(pattern: str) -> None:
    """حذف مجموعة ملفات بنمط glob فقط إذا كان DELETE_DOWNLOADS مفعّلاً."""
    if not DELETE_DOWNLOADS:
        return
    for f in glob.glob(pattern):
        try:
            os.remove(f)
        except Exception:
            pass


def clean_downloads():
    _sites = (
        "pornhub", "xvideos", "xnxx", "nsfwr34", "hentai", "danbooru", "cv247",
        "xvv1deos", "saradahentai", "xhamster", "rule34xyz", "realbooru",
        "p4fans", "thatpervert", "hentaifox", "hanimehentai", "hentaibalo",
        "phfamily", "thumbzilla", "rule34video", "rule34xxx", "thisvid", "xvideosred",
    )
    _exts  = ("*.part", "*.ytdl", "*.part-Frag*", "*.tmp")
    patterns = [f"downloads/{e}" for e in _exts]
    for site in _sites:
        patterns += [f"downloads/{site}/{e}" for e in _exts]
    for pattern in patterns:
        for f in glob.glob(pattern):
            try:
                os.remove(f)
            except Exception:
                pass


def url_check(_, __, update):
    return bool(update.text and "www.pornhub" in update.text)


url_filter = filters.create(url_check, name="url_filter")


def _extract_viewkey(url: str) -> str | None:
    match = re.search(r'viewkey=([a-zA-Z0-9]+)', url)
    return match.group(1) if match else None


async def _is_dark_image(path: str) -> bool:
    """Return True if the image is mostly black (file too small = dark frame)."""
    try:
        return os.path.getsize(path) < 4096  # < 4 KB → almost certainly black
    except Exception:
        return True


async def _detect_crop(path: str) -> str | None:
    """
    Run cropdetect on a static image to find the largest non-black region.
    Returns a ffmpeg crop filter string like 'crop=W:H:X:Y', or None.
    Only returns a crop if it actually cuts something meaningful (>5%).
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            FFMPEG, "-i", path,
            "-vf", "cropdetect=limit=24:round=2:reset=1",
            "-vframes", "1",
            "-f", "null", "-",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
        matches = re.findall(r'crop=(\d+:\d+:\d+:\d+)', stderr.decode(errors="ignore"))
        if not matches:
            return None
        crop_str = matches[-1]
        cw, ch, cx, cy = map(int, crop_str.split(":"))
        # Get original dimensions
        probe = await asyncio.create_subprocess_exec(
            FFMPEG, "-i", path, "-f", "null", "-",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, probe_err = await asyncio.wait_for(probe.communicate(), timeout=10)
        dim_match = re.search(r'(\d{2,5})x(\d{2,5})', probe_err.decode(errors="ignore"))
        if dim_match:
            ow, oh = int(dim_match.group(1)), int(dim_match.group(2))
            # Only crop if we're actually removing more than 5% of the image
            if oh > 0 and (oh - ch) / oh > 0.05:
                return f"crop={cw}:{ch}:{cx}:{cy}"
        return None
    except Exception:
        return None


async def _to_jpeg(src: str, dst: str, autocrop: bool = False) -> bool:
    """
    Convert any image (JPG/WebP/PNG) to a clean JPEG.
    - autocrop=True: auto-detect and remove black bars (for CDN thumbnails)
    - No padding, no zoom — only corrects dimensions to even numbers.
    """
    vf_parts: list[str] = []

    if autocrop:
        crop = await _detect_crop(src)
        if crop:
            vf_parts.append(crop)

    # Ensure even dimensions without changing aspect ratio or adding any padding
    vf_parts.append("scale=trunc(iw/2)*2:trunc(ih/2)*2")

    try:
        proc = await asyncio.create_subprocess_exec(
            FFMPEG, "-i", src,
            "-vf", ",".join(vf_parts),
            "-q:v", "1",
            "-pix_fmt", "yuvj420p",
            dst, "-y", "-loglevel", "quiet",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.communicate(), timeout=20)
        return os.path.exists(dst) and os.path.getsize(dst) > 2048
    except Exception:
        return False


async def _process_thumb_bytes(data: bytes) -> bytes:
    """
    Process raw thumbnail bytes (from CDN): auto-crop black bars → clean JPEG.
    Returns cleaned bytes, or original data if processing fails.
    """
    uid = id(data) & 0xFFFFFF
    raw = f"downloads/_tr_{uid}.img"
    out = f"downloads/_tj_{uid}.jpg"
    try:
        with open(raw, "wb") as f:
            f.write(data)
        if await _to_jpeg(raw, out, autocrop=True):
            with open(out, "rb") as f:
                return f.read()
    except Exception:
        pass
    finally:
        for p in (raw, out):
            try:
                os.remove(p)
            except Exception:
                pass
    return data


async def reply_photo_file(m, clean: bytes, caption: str, markup, prefix: str = "prev") -> bool:
    """
    Save clean JPEG bytes to a temp file and send via reply_photo.
    Returns True on success. Temp file is always deleted.
    Using a file path is more reliable than BytesIO with Pyrogram.
    """
    tmp = f"downloads/_{prefix}_{id(clean) & 0xFFFFFF}.jpg"
    try:
        with open(tmp, "wb") as f:
            f.write(clean)
        await m.reply_photo(photo=tmp, caption=caption, reply_markup=markup)
        return True
    except BaseException:
        return False
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass


async def _ffmpeg_frame(video_path: str, timestamp: int, out_path: str) -> bool:
    """
    Extract one frame at `timestamp` seconds from the video at native resolution.
    Maximum JPEG quality (-q:v 1), no scaling, no padding.
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            FFMPEG,
            "-ss", str(timestamp),
            "-i", video_path,
            "-vframes", "1",
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-q:v", "1",
            "-pix_fmt", "yuvj420p",
            out_path, "-y", "-loglevel", "quiet",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.communicate(), timeout=25)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 0
    except Exception:
        return False


async def prepare_video_meta(video_path: str, info: dict | None = None) -> tuple[int, int, int]:
    """
    Extract (duration, width, height) from a video file using ffprobe.
    Falls back to info dict values, then sensible defaults.
    """
    duration = 0
    width = 0
    height = 0

    try:
        ffprobe = shutil.which("ffprobe") or "ffprobe"
        proc = await asyncio.create_subprocess_exec(
            ffprobe,
            "-v", "quiet",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height,duration",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1",
            video_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
        text = stdout.decode(errors="ignore")
        for line in text.splitlines():
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            try:
                if k == "width" and not width:
                    width = int(v)
                elif k == "height" and not height:
                    height = int(v)
                elif k == "duration" and not duration:
                    duration = int(float(v))
            except (ValueError, TypeError):
                pass
    except Exception:
        pass

    if info:
        if not duration:
            try:
                duration = int(float(info.get("duration") or 0))
            except (ValueError, TypeError):
                pass
        if not width:
            width = int(info.get("width") or 0)
        if not height:
            height = int(info.get("height") or 0)

    return duration or 0, width or 1280, height or 720


async def _get_best_thumb(video_path: str, duration: int, info: dict) -> str | None:
    """
    3-layer thumbnail strategy — highest quality first:
      Layer 1 — ffmpeg frame extracted from the video at native resolution
                 (25% / 50% / 10% / 75% timestamps, skips dark frames)
      Layer 2 — yt-dlp writethumbnail (CDN image, often low-res 180x135)
      Layer 3 — info['thumbnail'] URL download
    """
    base = os.path.splitext(video_path)[0]
    tmp_jpg = base + "_thumb.jpg"

    # ── Layer 1: ffmpeg frame at native video resolution ──────────────────────
    # This is the highest-quality source — extracted from the actual video file.
    dur = max(duration, 10)
    timestamps = [
        max(1, int(dur * 0.25)),   # 25% — usually active scene
        max(1, int(dur * 0.50)),   # 50% — middle
        max(1, int(dur * 0.10)),   # 10% — early
        max(1, int(dur * 0.75)),   # 75% — late
    ]
    best: str | None = None
    for ts in timestamps:
        if await _ffmpeg_frame(video_path, ts, tmp_jpg):
            if not await _is_dark_image(tmp_jpg):
                return tmp_jpg
            if best is None:
                best = tmp_jpg

    if best and os.path.exists(best):
        return best

    # ── Layer 2: yt-dlp saved CDN thumbnail (fallback) ───────────────────────
    for ext in (".jpg", ".jpeg", ".webp", ".png"):
        candidate = base + ext
        if not (os.path.exists(candidate) and os.path.getsize(candidate) > 2048):
            continue
        if await _to_jpeg(candidate, tmp_jpg, autocrop=True):
            try:
                os.remove(candidate)
            except Exception:
                pass
            return tmp_jpg
        if ext in (".jpg", ".jpeg"):
            return candidate

    # ── Layer 3: download from yt-dlp thumbnail URL ───────────────────────────
    thumb_url = (
        info.get("thumbnail")
        or (info.get("thumbnails") or [{}])[-1].get("url")
    )
    if thumb_url:
        data = await fetch_bytes(str(thumb_url))
        if data and len(data) > 2048:
            raw = base + "_thumb_raw"
            with open(raw, "wb") as f:
                f.write(data)
            if await _to_jpeg(raw, tmp_jpg):
                try:
                    os.remove(raw)
                except Exception:
                    pass
                return tmp_jpg
            try:
                os.remove(raw)
            except Exception:
                pass

    return None


@Client.on_message(filters.incoming & filters.private, group=-1)
@Client.on_edited_message(filters.incoming & filters.private, group=-1)
async def subscribe_channel(c: Client, u: Message):
    if not sub_chat:
        return
    try:
        try:
            await c.get_chat_member(sub_chat, u.from_user.id)
        except UserNotParticipant:
            link = (
                "https://t.me/" + sub_chat
                if sub_chat.isalpha()
                else (await c.get_chat(sub_chat)).invite_link
            )
            try:
                await u.reply_text(
                    f"Hi {u.from_user.first_name}!\n\n"
                    "You must join the channel to use this bot.\n"
                    "Use /start after joining.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("📢 Join Channel", url=link),
                    ]]),
                )
                await u.stop_propagation()
            except ChatWriteForbidden:
                pass
    except ChatAdminRequired:
        try:
            await c.send_message(log_chat, "⚠️ Can't manage channel — make me an admin!")
        except Exception:
            pass


@Client.on_inline_query()
async def inline_search(c: Client, q: InlineQuery):
    query = q.query
    if not query:
        return

    backend = AioHttpBackend()
    api = PornhubApi(backend=backend)
    results = []
    try:
        src = await api.search.search_videos(query)
        videos = list(src)
    except Exception:
        results.append(
            InlineQueryResultArticle(
                title="No results found!",
                description="Try a different search term.",
                input_message_content=InputTextMessageContent(message_text="Video not found!"),
            )
        )
        await q.answer(results, switch_pm_text="• Results •", switch_pm_parameter="start")
        return
    finally:
        await backend.close()

    for vid in videos:
        try:
            results.append(
                InlineQueryResultArticle(
                    title=vid.title,
                    input_message_content=InputTextMessageContent(
                        message_text=str(vid.url), disable_web_page_preview=True,
                    ),
                    description=f"Duration: {vid.duration} | Views: {vid.views}",
                    thumb_url=vid.thumb,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("Watch on web", url=str(vid.url)),
                    ]]),
                )
            )
        except Exception:
            continue

    await q.answer(results, switch_pm_text="• Results •", switch_pm_parameter="start")


_PH_GIF_MP4_RE = re.compile(
    r'(https://[^\s"\'<>]*phncdn\.com/pics/gifs/[^\s"\'<>]+\.mp4'
    r'\?[^\s"\'<>]+)',
    re.I,
)
_PH_GIF_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


async def _get_ph_gif_url(page_url: str) -> str | None:
    """Re-scrape a fresh signed MP4 URL from a PornHub GIF page."""
    try:
        async with httpx.AsyncClient(
            timeout=15,
            follow_redirects=True,
            headers={
                "User-Agent": _PH_GIF_UA,
                "Cookie": "accessAgeDisclaimerPH=1; rd=us",
            },
        ) as c:
            r = await c.get(page_url)
        m = _PH_GIF_MP4_RE.search(r.text)
        return m.group(1) if m else None
    except Exception:
        return None


@Client.on_message(url_filter)
async def options(c: Client, m: Message):
    url = m.text.strip()

    if "/gif/" in url:
        key = cache_url("phg", url)
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("⬇️ Download GIF", callback_data=f"d_phg_{key}")],
            [InlineKeyboardButton("🌐 Watch on web", url=url)],
        ])
        await m.reply_text("🎬 PornHub GIF", reply_markup=markup)
        return

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=f"d_{url}")],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    viewkey = _extract_viewkey(url)
    if not viewkey:
        await m.reply_text("🎬", reply_markup=markup)
        return

    backend = AioHttpBackend()
    api = PornhubApi(backend=backend)
    try:
        vid, _ = await asyncio.gather(
            api.video.get_by_id(viewkey),
            asyncio.sleep(0),
        )
        title = vid.title or "Unknown"
        duration_str = str(vid.duration or "")
        thumb_url = str(vid.thumb) if vid.thumb else None

        caption = (
            f"🎬 <b>{title}</b>\n"
            f"⏱ <b>Duration:</b> <code>{duration_str}</code>"
        )

        raw_bytes = await fetch_bytes(thumb_url) if thumb_url else None
        if raw_bytes:
            clean = await _process_thumb_bytes(raw_bytes)
            await m.reply_photo(photo=BytesIO(clean), caption=caption, reply_markup=markup)
        else:
            await m.reply_text(caption, reply_markup=markup)

    except Exception:
        await m.reply_text("🎬", reply_markup=markup)
    finally:
        await backend.close()


@Client.on_callback_query(filters.regex(r"^d_phg_"), group=-1)
async def ph_gif_download(c: Client, q: CallbackQuery):
    full_key = q.data
    page_url = _resolve_url(full_key)

    if not page_url:
        await q.answer("⚠️ Session expired, please resend the link.", show_alert=True)
        return

    user_id = q.from_user.id
    if dl_state.is_active("pornhub", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Fetching GIF from PornHub...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Fetching GIF from PornHub...")
    else:
        try:
            await q.answer()
        except Exception:
            pass

    dl_state.add_active("pornhub", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    try:
        video_url = await _get_ph_gif_url(page_url)
        if not video_url:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                "❌ Could not extract GIF video URL from PornHub.\n"
                "The token may have expired — please resend the link.",
                c=c, chat_id=chat_id,
            )
            return

        msg_ref[0] = await safe_edit(msg_ref[0], "⏳ Downloading GIF...", c=c, chat_id=chat_id)
        fname = "downloads/pornhub/ph_gif.mp4"

        downloaded = 0
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30, read=300),
            follow_redirects=True,
            headers={"User-Agent": _PH_GIF_UA, "Referer": "https://www.pornhub.com/"},
        ) as client:
            async with client.stream("GET", video_url) as r:
                if r.status_code != 200:
                    msg_ref[0] = await safe_edit(
                        msg_ref[0],
                        f"❌ Download failed (HTTP {r.status_code}).",
                        c=c, chat_id=chat_id,
                    )
                    return
                total = int(r.headers.get("content-length", 0))
                with open(fname, "wb") as f:
                    async for chunk in r.aiter_bytes(65536):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total and downloaded % (1024 * 1024 * 2) < 65536:
                            pct = downloaded * 100 // total
                            msg_ref[0] = await safe_edit(
                                msg_ref[0],
                                f"⏳ Downloading GIF... {pct}% ({humanbytes(downloaded)} / {humanbytes(total)})",
                                c=c, chat_id=chat_id,
                            )

        file_size = os.path.getsize(fname)
        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n<b>Size:</b> <code>{humanbytes(file_size)}</code>",
                c=c, chat_id=chat_id,
            )
            return

        thumb_path = await _get_best_thumb(fname, 0, {})
        msg_ref[0] = await safe_edit(msg_ref[0], "📤 <b>Uploading GIF...</b>", c=c, chat_id=chat_id)

        await c.send_video(
            chat_id, fname,
            thumb=thumb_path,
            supports_streaming=True,
            caption=(
                f"<b>Source:</b> PornHub GIF\n"
                f"<b>Size:</b>  <code>{humanbytes(file_size)}</code>"
            ),
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("• PornHub GIF •", url=page_url),
            ]]),
        )

        if thumb_path and os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except Exception:
                pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        remove_glob_files("downloads/pornhub/ph_gif*")
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("pornhub", user_id)


@Client.on_callback_query(filters.regex(
    r"^d_(?!xnxx_|xv_|R34_|nsfwr34_|hs_|dbn_|cv247_"
    r"|xvv_|sara_|xh_|r34xyz_|rbooru_|p4f_|tperv_"
    r"|hfox_|hanim_|hbalo_|phg_"
    r"|r34v_|tsv_|phf_|r34x_|itch_"
    r"|pgif_|pcomic_|pimg_|ppdf_"
    r"|ash_cbz_|ash_pdf_"
    r"|eh_cbz_|eh_pdf_|imh_cbz_|imh_pdf_)"
))
async def get_video(c: Client, q: CallbackQuery):
    url = q.data.split("_", 1)[1]
    user_id = q.from_user.id

    if dl_state.is_active("pornhub", user_id):
        await q.answer("⚠️ You already have an active download!", show_alert=True)
        return

    try:
        msg = await q.message.edit("⏳ Preparing download...")
    except (MessageIdInvalid, MessageNotModified):
        try:
            await q.answer()
        except Exception:
            pass
        msg = await c.send_message(q.message.chat.id, "⏳ Preparing download...")
    dl_state.add_active("pornhub", user_id)
    clean_downloads()

    chat_id = q.message.chat.id
    msg_ref = [msg]

    ydl_opts = {
        "outtmpl": "downloads/pornhub/%(title)s [%(id)s].%(ext)s",
        "format": "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "merge_output_format": "mp4",
        "progress_hooks": [lambda d: download_progress_hook(d, msg_ref, c, chat_id)],
        "noplaylist": True,
        "retries": 10,
        "fragment_retries": 10,
        "skip_unavailable_fragments": True,
        "socket_timeout": 30,
        "http_chunk_size": 10485760,
        "concurrent_fragment_downloads": 8,
        "buffersize": 1024 * 16,
        "noprogress": False,
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": False,
        "ffmpeg_location": FFMPEG,
        "writethumbnail": True,
        "postprocessors": [
            {
                "key": "FFmpegVideoConvertor",
                "preferedformat": "mp4",
            },
        ],
    }

    downloaded_file = None
    try:
        def _do_download():
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(url)

        try:
            info = await run_in_executor(_do_download)
        except DownloadError as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Download failed:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return
        except Exception as e:
            msg_ref[0] = await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
            return

        if not info:
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ Could not extract video info.", c=c, chat_id=chat_id)
            return

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            fname = ydl.prepare_filename(info)
        base, _ = os.path.splitext(fname)
        for ext in [".mp4", ".mkv", ".webm"]:
            if os.path.exists(base + ext):
                downloaded_file = base + ext
                break

        if not downloaded_file:
            for ext in (".mp4", ".mkv", ".webm"):
                matches = glob.glob(f"downloads/pornhub/*{ext}")
                if matches:
                    downloaded_file = max(matches, key=os.path.getmtime)
                    break

        if not downloaded_file or not os.path.exists(downloaded_file):
            msg_ref[0] = await safe_edit(msg_ref[0], "❌ File not found after download.", c=c, chat_id=chat_id)
            return

        file_size = os.path.getsize(downloaded_file)
        file_name = os.path.basename(downloaded_file)

        if file_size > MAX_TG_SIZE:
            msg_ref[0] = await safe_edit(
                msg_ref[0],
                f"⚠️ <b>File too large!</b>\n\n"
                f"<b>File:</b> <code>{file_name}</code>\n"
                f"<b>Size:</b> <code>{humanbytes(file_size)}</code>\n"
                f"<i>Maximum allowed: 2 GiB.</i>",
                c=c, chat_id=chat_id
            )
            return

        width = info.get("width") or 1280
        height = info.get("height") or 720
        duration = int(info.get("duration") or 0)

        thumb_path = await _get_best_thumb(downloaded_file, duration, info)

        _match = re.match(r"^(.*?)\s*\[([^\]]+)\]\..*$", file_name)
        if _match:
            vid_title = _match.group(1).strip()
            vid_id = _match.group(2).strip()
        else:
            vid_title = file_name
            vid_id = ""

        msg_ref[0] = await safe_edit(msg_ref[0], f"📤 <b>Uploading...</b>\n<code>{file_name}</code>", c=c, chat_id=chat_id)
        await c.send_video(
            chat_id,
            downloaded_file,
            thumb=thumb_path,
            width=width,
            height=height,
            duration=duration,
            supports_streaming=True,
            caption=(
                f"<b>Name:</b> <code>{vid_title}</code>\n"
                + (f"<b>ID:</b> <code>{vid_id}</code>\n" if vid_id else "")
                + f"<b>Size:</b> <code>{humanbytes(file_size)}</code>"
            ),
            progress=upload_progress,
            progress_args=(msg_ref, chat_id, c),
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("• PornHub •", url=url),
            ]]),
        )

        for thumb_file in [thumb_path]:
            if thumb_file and os.path.exists(thumb_file):
                try:
                    os.remove(thumb_file)
                except Exception:
                    pass

    except Exception as e:
        await safe_edit(msg_ref[0], f"❌ <b>Error:</b>\n<code>{str(e)[:300]}</code>", c=c, chat_id=chat_id)
    finally:
        if downloaded_file and os.path.exists(downloaded_file):
            try:
                os.remove(downloaded_file)
            except Exception:
                pass
        if downloaded_file:
            base = os.path.splitext(downloaded_file)[0]
            for ext in (".jpg", ".jpeg", ".webp", ".png", "_thumb.jpg"):
                leftover = base + ext
                if os.path.exists(leftover):
                    try:
                        os.remove(leftover)
                    except Exception:
                        pass
        clean_downloads()
        try:
            await msg_ref[0].delete()
        except Exception:
            pass
        dl_state.remove_active("pornhub", user_id)


