import os
import asyncio
import aiofiles
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from ..config import prefixs, sub_chat, sudoers

sudofilter = filters.user(sudoers)
USERS_FILE = "users.txt"

_search_btn = InlineKeyboardMarkup([
    [InlineKeyboardButton("🔍 Search here", switch_inline_query_current_chat="")],
    [InlineKeyboardButton("📤 Search in chat", switch_inline_query="")],
])


async def _save_user(user_id: str):
    try:
        known: list[str] = []
        if os.path.exists(USERS_FILE):
            async with aiofiles.open(USERS_FILE, "r") as f:
                known = (await f.read()).splitlines()
        if user_id not in known:
            async with aiofiles.open(USERS_FILE, "a") as f:
                await f.write(user_id + "\n")
    except Exception:
        pass


async def _read_users() -> list[str]:
    if not os.path.exists(USERS_FILE):
        return []
    async with aiofiles.open(USERS_FILE, "r") as f:
        return [l.strip() for l in (await f.read()).splitlines() if l.strip()]


def _start_text(name: str) -> str:
    return (
        f"👋 <b>Hey, {name}!</b>\n\n"
        "Welcome to <b>PornHub Bot</b> — your fast Telegram downloader "
        "for adult videos from multiple sites.\n\n"
        "<b>Supported sites:</b>\n"
        "• <a href=\"https://www.pornhub.com\">PornHub</a>\n"
        "• <a href=\"https://www.xvideos.com\">XVideos</a> / <a href=\"https://www.xvideos-ar.com\">XVideos AR</a>\n"
        "• <a href=\"https://www.xnxx.com\">XNXX</a>\n"
        "• <a href=\"https://nsfwr34.com\">NSFWr34</a>\n\n"
        "<b>What can I do?</b>\n"
        "• Send a link from any supported site - I'll download it for you\n"
        "• /search <code>keyword</code> - find videos by name\n"
        "• Inline mode - search from any chat\n\n"
        "<i>By continuing you confirm you are 18+ and accept the terms of use.</i>"
    )


def _start_markup() -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton("📋 Terms of Use", callback_data="terms")],
        [InlineKeyboardButton("❓ Help & Commands", callback_data="help_cb")],
    ]
    if sub_chat:
        buttons.insert(0, [InlineKeyboardButton("📢 Channel", url=f"https://t.me/{sub_chat}")])
    return InlineKeyboardMarkup(buttons)


@Client.on_message(filters.command(["start", "restart"], prefixs) & filters.private)
async def intro_msg(_, m: Message):
    await asyncio.gather(
        _save_user(str(m.chat.id)),
        m.reply_text(_start_text(m.from_user.first_name), reply_markup=_start_markup()),
    )


@Client.on_callback_query(filters.regex("^home_intro$"))
async def home_page(_, q: CallbackQuery):
    await q.answer()
    await q.edit_message_text(
        _start_text(q.from_user.first_name),
        reply_markup=_start_markup(),
    )


@Client.on_callback_query(filters.regex("^terms$"))
async def terms_panel(_, q: CallbackQuery):
    await q.answer()
    text = (
        "📜 <b>Terms of Use</b>\n\n"
        "⚠️ <b>18+ Content Warning</b>\n"
        "This bot provides access to adult content. By using it you confirm "
        "that you are at least <b>18 years old</b> and that adult content "
        "is legal in your jurisdiction.\n\n"
        "🔐 <b>Privacy</b>\n"
        "We do not store, share, or sell your search queries or download history. "
        "All processing happens on-the-fly.\n\n"
        "🚫 <b>Prohibited use</b>\n"
        "Do not redistribute downloaded content commercially or without permission. "
        "This bot is for personal use only.\n\n"
        "By pressing <b>Agree</b> you accept these terms and may proceed."
    )
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Agree", callback_data="final_page"),
         InlineKeyboardButton("❌ Cancel", callback_data="home_intro")],
    ])
    await q.edit_message_text(text, reply_markup=markup)


@Client.on_callback_query(filters.regex("^final_page$"))
async def greets(_, q: CallbackQuery):
    await q.answer("Welcome! You're all set.")
    text = (
        f"✅ <b>You're good to go, {q.from_user.first_name}!</b>\n\n"
        "Here's how to get started:\n\n"
        "🔗 <b>Download by link</b> — paste any PornHub URL directly\n"
        "🔍 <b>/search</b> <code>keyword</code> — search and pick a video\n"
        "📤 <b>Inline mode</b> — search from any chat\n\n"
        "<i>Tip: Inline mode works without switching chats.</i>"
    )
    await q.edit_message_text(text, reply_markup=_search_btn)


@Client.on_callback_query(filters.regex("^help_cb$"))
async def help_callback(_, q: CallbackQuery):
    await q.answer()
    text = (
        "❓ <b>Commands & Usage</b>\n\n"
        "<b>General:</b>\n"
        "• /start — Welcome & bot info\n"
        "• /help — This message\n"
        "• /search <code>keyword</code> — Search for a video\n"
        "• /autovideo — Send a different video from each video site every 10 minutes\n"
        "• /ping — Check bot response time\n\n"
        "<b>How to download:</b>\n"
        "1️⃣ Send a PornHub link directly\n"
        "2️⃣ Or use /search and pick from results\n"
        "3️⃣ Or use inline mode: <code>@botname query</code>\n\n"
        "<b>Limits:</b>\n"
        "• Max file size: <code>2 GiB</code>\n"
        "• One active download per user"
    )
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Search", switch_inline_query_current_chat="")],
        [InlineKeyboardButton("🏠 Home", callback_data="home_intro")],
    ])
    await q.edit_message_text(text, reply_markup=markup)


@Client.on_message(filters.command("help", prefixs))
async def command_list(_, m: Message):
    is_sudo = m.from_user.id in sudoers
    text = (
        "❓ <b>Commands & Usage</b>\n\n"
        "<b>General:</b>\n"
        "• /start — Welcome & bot info\n"
        "• /help — This message\n"
        "• /search <code>keyword</code> — Search for a video\n"
        "• /autovideo — Send a different video from each video site every 10 minutes\n"
        "• /stopautovideo — Stop periodic video delivery\n"
        "• /ping — Check bot response time\n\n"
        "<b>How to download:</b>\n"
        "1️⃣ Send a PornHub link directly\n"
        "2️⃣ Or use /search and pick from results\n"
        "3️⃣ Inline mode: type <code>@botname query</code> in any chat\n\n"
        "<b>Limits:</b>\n"
        "• Max file size: <code>2 GiB</code>\n"
        "• One active download per user at a time"
    )
    if is_sudo:
        text += (
            "\n\n<b>Admin:</b>\n"
            "• /stats — Total bot users\n"
            "• /gcast — Broadcast a message"
        )
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Search inline", switch_inline_query_current_chat="")],
    ])
    await m.reply_text(text, reply_markup=markup)


@Client.on_message(filters.command("ping", prefixs))
async def ping(_, m: Message):
    t1 = datetime.now()
    sent = await m.reply_text("⏱ Pinging...")
    t2 = datetime.now()
    ms = round((t2 - t1).microseconds / 1000, 2)
    await sent.edit_text(f"🏓 <b>Pong!</b>  —  <code>{ms} ms</code>")


@Client.on_message(filters.command("stats", prefixs) & sudofilter)
async def bot_statistic(c: Client, m: Message):
    users = await _read_users()
    if not users:
        await m.reply_text("No users recorded yet.")
        return
    await c.send_document(
        m.chat.id,
        USERS_FILE,
        caption=f"📊 <b>Total users:</b> <code>{len(users)}</code>",
    )


@Client.on_message(filters.command(["gcast", "broadcast"], prefixs) & sudofilter)
async def broadcast(c: Client, m: Message):
    if not m.reply_to_message:
        await m.reply_text("↩️ Reply to the message you want to broadcast.")
        return

    rows = await _read_users()
    if not rows:
        await m.reply_text("No users to broadcast to.")
        return

    status = await m.reply_text(f"📡 Broadcasting to <code>{len(rows)}</code> users...")

    async def _send_one(uid: str):
        try:
            await m.reply_to_message.copy(int(uid))
            return True
        except Exception:
            return False

    results = await asyncio.gather(*[_send_one(uid) for uid in rows])
    sent = sum(results)
    failed = len(results) - sent

    await status.edit_text(
        f"📡 <b>Broadcast complete!</b>\n\n"
        f"✅ Sent: <code>{sent}</code>\n"
        f"❌ Failed: <code>{failed}</code>"
    )
