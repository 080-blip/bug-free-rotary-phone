from typing import List

API_ID: int = 1104537
API_HASH: str = "036f9721fcdc73f19b954aafe4b7f94b"
TOKEN: str = "8515908624:AAEiuZD0FdRpsmVVFmju5XLsDNBpZki-Yx0"

log_chat: int = -1003853900742
sub_chat: str = "cbd135phub"
sudoers: List[int] = [8606113119]
prefixs: List[str] = ["/", "!", ".", "$", "-"]

# True  → حذف الملفات بعد رفعها على تيليغرام (السلوك الافتراضي)
# False → إبقاء الملفات في مجلد downloads/ بعد الرفع
DELETE_DOWNLOADS: bool = True
