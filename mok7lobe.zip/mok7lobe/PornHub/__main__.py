import sys
import asyncio
import logging

try:
    import uvloop
    loop = uvloop.new_event_loop()
    asyncio.set_event_loop(loop)
except ImportError:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

from .bot import PornHub
from pyrogram import idle
from pyrogram.errors import FloodWait

logging.basicConfig(
    level=logging.INFO,
    format="%(name)s.%(funcName)s | %(levelname)s | %(message)s",
    datefmt="[%X]",
)
logging.getLogger("pyrogram.syncer").setLevel(logging.WARNING)
logging.getLogger("pyrogram.client").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


async def main():
    pornhub = PornHub()

    try:
        await pornhub.start()

        if "test" not in sys.argv:
            await idle()

    except FloodWait as e:
        logger.warning("FloodWait: waiting %d seconds...", e.value)
        await asyncio.sleep(e.value)
        await main()

    except KeyboardInterrupt:
        logger.warning("Forced stop, Bye!")

    finally:
        from .plugins.http_client import close_client
        await close_client()
        try:
            await pornhub.stop()
        except Exception as e:
            logger.warning("Error during stop: %s", e)


if __name__ == "__main__":
    loop.run_until_complete(main())
