"""
CartoonVideos247 — extract direct MP4 URL from video page.
Supports: cartoonvideos247.com
"""
import re
import html as _html
from io import BytesIO

from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from PornHub.plugins.http_client import fetch_bytes
from PornHub.plugins.downloader import _process_thumb_bytes, reply_photo_file
from PornHub.plugins.url_cache import cache_url

_MP4_RE = re.compile(
    r'["\']?(https?://(?:www\.)?cartoonvideos247\.com/get_file/[^\s"\'<>]+\.mp4)[/\'"]?',
    re.I
)
_THUMB_RE = re.compile(
    r'["\']?(https?://(?:www\.)?cartoonvideos247\.com/[^\s"\'<>]+preview[^\s"\'<>]+\.jpg)["\']?',
    re.I
)


async def get_video_info(url: str) -> dict | None:
    raw = await fetch_bytes(url)
    if not raw:
        return None
    page = raw.decode("utf-8", errors="ignore")

    vm = _MP4_RE.search(page)
    if not vm:
        return None
    video_url = vm.group(1).rstrip("/'")

    m_title = re.search(r'<title>([^<]+)</title>', page, re.I)
    title = _html.unescape(m_title.group(1)).strip() if m_title else "CartoonVideos247"
    title = re.sub(r'\s*[-|].*$', '', title).strip()

    tm = _THUMB_RE.search(page)
    thumb = tm.group(1) if tm else None

    return {
        "download_url": video_url,
        "title":        title,
        "thumbnail":    thumb,
        "duration":     0,
    }


async def show_options(m: Message, url: str) -> None:
    info = await get_video_info(url)

    if not info:
        await m.reply_text(
            "⚠️ <b>Could not access CartoonVideos247.</b>\n\n"
            "The site is currently unreachable from the server.\n"
            "Open the page directly in your browser to download it.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🌐 Watch on web", url=url)
            ]]),
        )
        return

    key          = cache_url("cv247", info["download_url"])
    callback_key = f"d_cv247_{key}"

    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬇️ Download", callback_data=callback_key)],
        [InlineKeyboardButton("🌐 Watch on web", url=url)],
    ])

    caption = f"🎬 <b>{info['title']}</b>"

    thumb_url = info.get("thumbnail")
    if thumb_url:
        try:
            raw = await fetch_bytes(thumb_url)
            if raw:
                clean = await _process_thumb_bytes(raw)
                await m.reply_photo(photo=BytesIO(clean), caption=caption, reply_markup=markup)
                return
        except Exception:
            pass

    await m.reply_text(caption, reply_markup=markup)
